package com.unfi.cbk.controller.chargeback;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.bo.CreateNewUserBO;
import com.unfi.cbk.controller.ChargebackBaseController;
import com.unfi.cbk.controller.PageAccessResolver;
import com.unfi.cbk.delegates.ChargebackCreateDelegate;
import com.unfi.cbk.delegates.ChargebackSearchDelegate;
import com.unfi.cbk.email.ChargebackMailer;
import com.unfi.cbk.forms.ChargebackSearchForm;
import com.unfi.cbk.forms.ChargebackUpdateForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.Constants;
import com.unfi.cbk.util.DateFunctions;
import com.unfi.cbk.util.StringFunctions;
import com.unfi.cbk.utilcore.ApplicationProperties;

/**
 * The ChargebackUpdateController class is the struts action called when
 * retrieving the search results. The action simply determines the user type and
 * forwards the request to a secondary struts action specific to the user type.
 * <p>
 * This is to accommodate the struts Validator. Since all three versions of the
 * search form use the same ActionForm, the different validations that need to
 * be done specific to the type of form used are accomplished by having the
 * validator use the actions to determine which rules to use.<br>
 * This action, then, makes the user type transparent to the user by always
 * having the same action called when searching, regardless of user type.
 *
 * @author vpil001
 * @since 1.0
 */
@Controller("chargebackUpdateAction_updateChargeback")
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ChargebackUpdateController extends ChargebackBaseController {
	static Logger log = Logger.getLogger(ChargebackSearchResultsController.class);
	@Autowired
	private ChargebackSearchDelegate chargebackSearchDelegate;
	@Autowired
	private ChargebackCreateDelegate chargebackCreateDelegate;
	@Autowired
	private ChargebackMailer chargebackMailer;

	private static String TEST_EMAIL = ApplicationProperties.getDummyEMail();

//	
	public ChargebackUpdateController(ChargebackSearchDelegate chargebackSearchDelegate,
			ChargebackCreateDelegate chargebackCreateDelegate) {
		this.chargebackSearchDelegate = chargebackSearchDelegate;
		this.chargebackCreateDelegate = chargebackCreateDelegate;
	}

	@Autowired
	ActionMessages messages;
	@Autowired
	Environment env;
	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	@RequestMapping(value = "/updateChargeback", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView update(@ModelAttribute("chargebackUpdateForm") ChargebackUpdateForm chargebackUpdateForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***** CHARGEBACK update-  *****");
		chargebackUpdateForm.setFormParameterMap(request);
		boolean exceptionOccurred = false;
		String invoiceNumber = null;
		String vendorId = null;

		List<ChargebackBO> fileNames = null;
		String attachmentName = null;
		String attachmentType = null;
		boolean isEditable = false;
		HttpSession session = request.getSession();
        String SmUserId = (String) session.getAttribute("SmUserId");
        String editableInvoiceStatus = null;

		try {

			String dateCriteria = request.getParameter("dateCriteria") ;
			if (request.getParameter("invoiceNbr") != null) {
				invoiceNumber = request.getParameter("invoiceNbr");
			}

			if (request.getParameter("vendorId") != null) {
				vendorId = request.getParameter("vendorId");
			}

			String locationNumber = request.getParameter("locationNumber");
			Map<String, Comparable> updateParametersFromForm = chargebackUpdateForm.getMap();
			updateParametersFromForm.put("locationNumber", locationNumber);
			updateParametersFromForm.put("vendorId", vendorId);
			updateParametersFromForm.put("invoiceNumber", invoiceNumber);


			// Get the ChargebackType list
			List<ChargebackBO> chargebackTypes = chargebackSearchDelegate.getChargebackTypes();
			chargebackUpdateForm.setChargebackTypes(chargebackTypes);

			// Get the Reasons list
			List<ChargebackBO> reasons = chargebackSearchDelegate.getReasons();
			chargebackUpdateForm.setReasons(reasons);

			// Get the Product group list
			List<ChargebackBO> productGroup = chargebackSearchDelegate.getProductGroup();
			ChargebackBO cbk = new ChargebackBO();
			cbk.setPrdGrpCode("");
			cbk.setProductGrp("");
			productGroup.add(0, cbk);
			chargebackUpdateForm.setProductGroups(productGroup);

			// Get the locations list
			List<ChargebackBO> locations = chargebackSearchDelegate.getLocations();
			chargebackUpdateForm.setLocations(locations);

			// Get the sub Funds list
			List<ChargebackBO> subFunds = chargebackCreateDelegate.getSubFunds();
			chargebackUpdateForm.setSubFunds(subFunds);

			// Get the vendor informaton
			ChargebackBO vendorInfo = chargebackSearchDelegate.getChargebackVendor(updateParametersFromForm);
			if (vendorInfo != null) {
				chargebackUpdateForm.populateFormFromObjectVendor(chargebackUpdateForm, vendorInfo);
			}

			ChargebackBO cbkBo = chargebackSearchDelegate.getChargebackInfo(updateParametersFromForm);
			chargebackUpdateForm.populateFormFromObject(cbkBo);
			updateParametersFromForm.put("locationNumber", cbkBo.getLocationNumber());
			// Get the search results based on the parameters in the form
			ResultList searchResults = chargebackSearchDelegate.getCbkDetTable(updateParametersFromForm);
			// Populate the 'searchResults' property in the ActionForm
			// chargebackUpdateForm.setDetailResults(searchResults.getList());
			chargebackUpdateForm.setGlItems(searchResults.getList());
			// Get the search results based on the parameters in the form
			ResultList distibutionResults = chargebackSearchDelegate
					.getChargebackDistribution(updateParametersFromForm);
			chargebackUpdateForm.setSlItems(distibutionResults.getList());

			fileNames = chargebackSearchDelegate.getAttachmentName(chargebackUpdateForm.getInvoiceNumber());

			for (ChargebackBO fileName : fileNames) {

				chargebackUpdateForm.setAttachmentName(String.valueOf(fileName.getAttachmentName()));
				chargebackUpdateForm.setAttachmentType(String.valueOf(fileName.getAttachmentType()));

			}

			// showing approval history
			ResultList approvalHistory = chargebackSearchDelegate
					.getApprovalHistory(chargebackUpdateForm.getInvoiceNumber());
			chargebackUpdateForm.setApprovalHistoryList(approvalHistory.getList());

			// Get the user roles based on decide he is admin or not
			String adminUser = chargebackSearchDelegate.getAdminUser(SmUserId, "-5");

			// Get approval status
			ResultList approverStatusResults = chargebackSearchDelegate.getChargebackApprovalStatus(invoiceNumber,
					SmUserId);
			List approverStatusList = (List) approverStatusResults.getList();// DELETE IT
			ChargebackBO cbkApproverStatusBO = new ChargebackBO();
			// DELETE IT
			for (int i = 0; i < approverStatusList.size(); i++) {
				cbkApproverStatusBO = (ChargebackBO) approverStatusList.get(i);
			}

			// String maxStepNumber = null;
			boolean isApproved;
			// maxStepNumber =
			// chargebackSearchDelegate.getMaxStepNumber(cbkApproverStatusBO.getStepNumber(),
			// cbkBo.getTotal());

			if (approverStatusList.size() == 0) {
				// not received any approval as of now
				isApproved = false;

			} else {
				// has at least one approval
				isApproved = true;

			}

	
			// Role ID -1 is admin
			if (adminUser != null) {
				isEditable = true;
				log.debug("--********Admin Editable*******--");
			}
			// Creator of the Chargeback
			else if (cbkBo.getCreatorId().equals(SmUserId)) {

				if (isApproved) {
					isEditable = false;
					log.debug("--********Creator not Editable*******--" + cbkBo.getCreatorId()
							+ " default user id" + SmUserId);
				} else {
					isEditable = true;
					log.debug("--********Creator Editable*******--");
				}

			} // Approver of the Chargeback
			else if (cbkBo.getApprover() != null && cbkBo.getApprover().equals(SmUserId)) {
				isEditable = true;
				log.debug("--********Approver Editable*******--");
			} else {
				isEditable = false;
				log.debug("--********others not Editable*******--");
			}

			request.setAttribute("chargebackUpdateForm", chargebackUpdateForm);

		} catch (Exception e) {
			exceptionOccurred = true;
			e.printStackTrace();
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);
		}

		PageAccessResolver resolver = new PageAccessResolver(request);
		
		editableInvoiceStatus = chargebackSearchDelegate.getInvoiceEditableStatus(invoiceNumber);
		
		
		
		mav.setViewName(ActionUrlMapping.CHARGEBACKUPDATEACTIONS.get(Constants.ACTION_SUCCESS));
		request.setAttribute("actionMessages", messages);
		return mav;

	}

	/**
	 * submit method
	 * 
	 * @param chargebackUpdateForm
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/updateChargeback", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=submit" })
	public ModelAndView submit(@ModelAttribute("chargebackUpdateForm") ChargebackUpdateForm chargebackUpdateForm,
			ChargebackSearchForm chargebackSearchForm, @RequestParam("file") MultipartFile file,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();

		log.debug("***** Chargeback update  submit *****");
		Map<String, Comparable> updateParametersFromForm = chargebackUpdateForm.getMap();
		boolean exceptionOccurred = false;
		HttpSession session = request.getSession();
        String SmUserId = (String) session.getAttribute("SmUserId");
		List<ChargebackBO> fileNames = null;
		String attachmentName = null;
		String attachmentType = null;
		String amountChanged = null;
		String approverChanged = null;
		String creatorId = null;

		if (request.getParameter("creatorId") != null) {
			creatorId = request.getParameter("creatorId");
		}

		if (request.getParameter("amountChanged") != null) {
			amountChanged = request.getParameter("amountChanged");
		}
		
		if (request.getParameter("approverChanged") != null) {
			approverChanged = request.getParameter("approverChanged");
		}
		

		try {

			// Get the Company code
			String companyCode = null;
			companyCode = chargebackSearchDelegate.getCompanyCode(chargebackUpdateForm.getLocationNumber());
			chargebackUpdateForm.setCompanyCode(companyCode);
			updateParametersFromForm.put("companyCode", companyCode);
			// Insert Data in to Chargeback details
			chargebackSearchDelegate.updateChargeback(populateObjectFromForm(chargebackUpdateForm), false);

			updateParametersFromForm.put("invoiceNumber", chargebackUpdateForm.getInvoiceNumber());
			updateParametersFromForm.put("vendorId", chargebackUpdateForm.getVendorId());
			updateParametersFromForm.put("locationNumber", chargebackUpdateForm.getLocationNumber());
			updateParametersFromForm.put("attachmentType", chargebackUpdateForm.getAttachmentType());

			ChargebackBO chargebackBO = new ChargebackBO();
			fileNames = chargebackSearchDelegate.getAttachmentName(chargebackUpdateForm.getInvoiceNumber());
			for (ChargebackBO fName : fileNames) {
				attachmentName = fName.getAttachmentName();
				attachmentType = fName.getAttachmentType();
			}
			if (attachmentName != null && !file.isEmpty()) {

				chargebackSearchDelegate.deleteAttachment(chargebackUpdateForm.getInvoiceNumber());
			}
			if (!file.isEmpty()) {
				byte[] bytes = file.getBytes();

				String fileExtention = file.getOriginalFilename();
				int lastIndexOf = fileExtention.lastIndexOf(".");
				if (lastIndexOf != -1) {
					fileExtention = fileExtention.substring(lastIndexOf);
				} else {
					fileExtention = "";
				}
				String fileName = StringFunctions.fileNameGenration(chargebackUpdateForm, fileExtention);
				chargebackUpdateForm.setAttachmentDate(DateFunctions.formatDate(new Date()));
				chargebackBO.setInvoiceNumber(chargebackUpdateForm.getInvoiceNumber());
				chargebackBO.setLocationNumber(chargebackUpdateForm.getLocationNumber());
				chargebackBO.setAttachmentType(chargebackUpdateForm.getAttachmentType());
				chargebackBO.setAttachmentDate(new Date());
				chargebackBO.setFilename(fileName);
				chargebackBO.setAttachmentFile(bytes);
				chargebackSearchDelegate.updateAttachment(chargebackBO);
			}

			// if Amount changed in the Edit screen then we are removing all the rows from
			// Approval table
			if ((amountChanged != null && amountChanged.equals("true")) || (approverChanged != null && approverChanged.equals("true"))) {
				//chargebackSearchDelegate.deleteAllApprovalsForInvoice(chargebackUpdateForm.getInvoiceNumber(), chargebackUpdateForm.getLocationNumber());
				chargebackSearchDelegate.deleteApprovals(chargebackUpdateForm.getInvoiceNumber(), chargebackUpdateForm.getLocationNumber());
			}
			

			// Delete before inserting the data
			chargebackSearchDelegate.deleteCbkItem(updateParametersFromForm);

			List<ChargebackBO> detailList = chargebackUpdateForm.getGlItemList(); // DetailList
			chargebackSearchDelegate.createCbkItem(getItemDetailList(detailList, chargebackUpdateForm));

			// Delete before inserting the data
			chargebackSearchDelegate.deleteCbkDistribution(updateParametersFromForm);
			// Insert data in to distribution table
			List<ChargebackBO> distributionList = chargebackUpdateForm.getSlItemList(); // DistributionList
			chargebackSearchDelegate.createCbkDistribution(getDistributionList(distributionList, chargebackUpdateForm));

			// Get the Email address of the Approver
			
			if (!chargebackUpdateForm.getApprover().equals("") && chargebackUpdateForm.getApprover() != null) {
				CreateNewUserBO UserBODetails = chargebackSearchDelegate
						.getUserDetails(chargebackUpdateForm.getApprover());
				// Send email only when user finally confirmed on the approver and notification
				if (UserBODetails.getUseremailId() != null) {
					UserBODetails.setUseremailId(TEST_EMAIL); // need to remove this line when we are at actual environment. 
					chargebackMailer.updateSendEmail(chargebackUpdateForm, UserBODetails.getUseremailId(), SmUserId);
				}
			} else {
				CreateNewUserBO UserBODetails = chargebackSearchDelegate.getUserDetails(creatorId);
				// Send email only when user finally confirmed on the approver and notification
				if (UserBODetails.getUseremailId() != null) {
					UserBODetails.setUseremailId(TEST_EMAIL); //// need to remove this line when we are at actual environment. 
					chargebackMailer.updateSendEmail(chargebackUpdateForm, UserBODetails.getUseremailId(), SmUserId);
				}
			}

			Map<String, Comparable> searchParametersFromForm = chargebackSearchForm.getMap();
			searchParametersFromForm.put("userId", SmUserId);

			// Define the display parameters
			int maxRows = 20;
			chargebackSearchForm.setDisplayCount(maxRows);

			if (chargebackSearchForm.isShowAll()) {
				searchParametersFromForm.put("showAll", "true");
			} else {
				searchParametersFromForm.put("rowStart", new Integer(chargebackSearchForm.getCurrentRecord()));
				searchParametersFromForm.put("rowEnd",
						new Integer(chargebackSearchForm.getCurrentRecord() + maxRows - 1));
			}
			ResultList searchResults = chargebackSearchDelegate.getAvailableChargebacks(searchParametersFromForm);
	
			// Populate the 'searchResults' property in the ActionForm
			chargebackSearchForm.setSearchResults(searchResults.getList());
			chargebackSearchForm.setTotalRecords(searchResults.getTotalCount().intValue());

		} catch (Exception e) {
			exceptionOccurred = true;
			e.printStackTrace();
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);
		}

		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess() && !exceptionOccurred) {
			mav.setViewName(ActionUrlMapping.CHARGEBACKGETRESULTSACTION.get(Constants.ACTION_SUCCESS));
			request.setAttribute("actionMessages", messages);
			// return mapping.findForward("success");
			request.setAttribute("chargebackSearchForm", chargebackSearchForm);
			return mav;
		}
		mav.setViewName(ActionUrlMapping.AVAILABLECHARGEBACKACTION.get("other"));
		// return mapping.findForward("other");


		request.setAttribute("actionMessages", messages);
		request.setAttribute("chargebackUpdateForm", chargebackUpdateForm);
		return mav;

	}

	@RequestMapping(value = "/updateChargeback", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=save" })
	public ModelAndView save(@ModelAttribute("chargebackUpdateForm") ChargebackUpdateForm chargebackUpdateForm,
			ChargebackSearchForm chargebackSearchForm, @RequestParam("file") MultipartFile file,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();

		log.debug("***** Chargeback update  submit *****");
		Map<String, Comparable> updateParametersFromForm = chargebackUpdateForm.getMap();
		boolean exceptionOccurred = false;
		boolean sendNotification = true;
		List<ChargebackBO> fileNames = null;
		String attachmentName = null;
		String attachmentType = null;
		HttpSession session = request.getSession();
        String SmUserId = (String) session.getAttribute("SmUserId");
		String creatorId = null;
		if (request.getParameter("creatorId") != null) {
			creatorId = request.getParameter("creatorId");
		}

		try {

			// Get the Company code
			String companyCode = null;
			companyCode = chargebackSearchDelegate.getCompanyCode(chargebackUpdateForm.getLocationNumber());
			chargebackUpdateForm.setCompanyCode(companyCode);
			updateParametersFromForm.put("companyCode", companyCode);
			// Insert Data in to Chargeback details
			chargebackSearchDelegate.updateChargeback(populateObjectFromForm(chargebackUpdateForm), false);

			updateParametersFromForm.put("invoiceNumber", chargebackUpdateForm.getInvoiceNumber());
			updateParametersFromForm.put("vendorId", chargebackUpdateForm.getVendorId());
			updateParametersFromForm.put("locationNumber", chargebackUpdateForm.getLocationNumber());
			updateParametersFromForm.put("attachmentType", chargebackUpdateForm.getAttachmentType());

			ChargebackBO chargebackBO = new ChargebackBO();

			fileNames = chargebackSearchDelegate.getAttachmentName(chargebackUpdateForm.getInvoiceNumber());
			for (ChargebackBO fName : fileNames) {
				attachmentName = fName.getAttachmentName();
				attachmentType = fName.getAttachmentType();
			}

			if (attachmentName != null && !file.isEmpty()) {
				chargebackSearchDelegate.deleteAttachment(chargebackUpdateForm.getInvoiceNumber());
			}

			if (!file.isEmpty()) {
				byte[] bytes = file.getBytes();
				String fileExtention = file.getOriginalFilename();
				int lastIndexOf = fileExtention.lastIndexOf(".");
				if (lastIndexOf != -1) {
					fileExtention = fileExtention.substring(lastIndexOf);
				} else {
					fileExtention = "";
				}
				String fileName = StringFunctions.fileNameGenration(chargebackUpdateForm, fileExtention);
				chargebackUpdateForm.setAttachmentDate(DateFunctions.formatDate(new Date()));
				chargebackBO.setInvoiceNumber(chargebackUpdateForm.getInvoiceNumber());
				chargebackBO.setLocationNumber(chargebackUpdateForm.getLocationNumber());
				chargebackBO.setAttachmentType(chargebackUpdateForm.getAttachmentType());
				chargebackBO.setAttachmentDate(new Date());
				chargebackBO.setFilename(fileName);
				chargebackBO.setAttachmentFile(bytes);
				fileNames = chargebackSearchDelegate.getAttachmentName(chargebackUpdateForm.getInvoiceNumber());
				chargebackSearchDelegate.updateAttachment(chargebackBO);
			}

			// Delete before inserting the data
			chargebackSearchDelegate.deleteCbkItem(updateParametersFromForm);

			List<ChargebackBO> detailList = chargebackUpdateForm.getGlItemList(); // DetailList
			chargebackSearchDelegate.createCbkItem(getItemDetailList(detailList, chargebackUpdateForm));

			// Delete before inserting the data
			chargebackSearchDelegate.deleteCbkDistribution(updateParametersFromForm);
			// Insert data in to distribution table
			List<ChargebackBO> distributionList = chargebackUpdateForm.getSlItemList(); // DistributionList
			chargebackSearchDelegate.createCbkDistribution(getDistributionList(distributionList, chargebackUpdateForm));

			Map<String, Comparable> searchParametersFromForm = chargebackSearchForm.getMap();
			searchParametersFromForm.put("userId", SmUserId);
			// Define the display parameters
			int maxRows = 20;
			chargebackSearchForm.setDisplayCount(maxRows);

			if (chargebackSearchForm.isShowAll()) {
				searchParametersFromForm.put("showAll", "true");
			} else {
				searchParametersFromForm.put("rowStart", new Integer(chargebackSearchForm.getCurrentRecord()));
				searchParametersFromForm.put("rowEnd",
						new Integer(chargebackSearchForm.getCurrentRecord() + maxRows - 1));
			}
			ResultList searchResults = chargebackSearchDelegate.getAvailableChargebacks(searchParametersFromForm);
		
			// Populate the 'searchResults' property in the ActionForm
			chargebackSearchForm.setSearchResults(searchResults.getList());
			chargebackSearchForm.setTotalRecords(searchResults.getTotalCount().intValue());

		} catch (Exception e) {
			exceptionOccurred = true;
			e.printStackTrace();
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);
		}

		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess() && !exceptionOccurred) {
			mav.setViewName(ActionUrlMapping.AVAILABLECHARGEBACKACTION.get(Constants.ACTION_SUCCESS));
			request.setAttribute("actionMessages", messages);
			// return mapping.findForward("success");
			request.setAttribute("chargebackSearchForm", chargebackSearchForm);
			return mav;
		}
		mav.setViewName(ActionUrlMapping.AVAILABLECHARGEBACKACTION.get("other"));
		// return mapping.findForward("other");


		request.setAttribute("actionMessages", messages);
		request.setAttribute("chargebackUpdateForm", chargebackUpdateForm);
		return mav;

	}

	
	public List getItemDetailList(List detailList, ChargebackUpdateForm chargebackUpdateForm) {

		List saveDetailList = new ArrayList();
		Iterator i = detailList.iterator();
		Integer j = 1;
		while (i.hasNext()) {
			ChargebackBO itemLine = (ChargebackBO) i.next();

			if (itemLine != null) {
				if (itemLine.getItemDesc() != null && itemLine.getItemPriceFormat() != null) {
					itemLine.setLineNumber(j++);
					itemLine.setLocationNumber(chargebackUpdateForm.getLocationNumber());
					itemLine.setInvoiceNumber(chargebackUpdateForm.getInvoiceNumber());
					saveDetailList.add(itemLine);
				}
			}
		}
		return saveDetailList;

	}

	public List getDistributionList(List distributionList, ChargebackUpdateForm chargebackUpdateForm) {

		// Get Item Details
		List saveDistributionList = new ArrayList();
		Iterator i = distributionList.iterator();
		Integer j = 1;
		while (i.hasNext()) {
			ChargebackBO distributionLine = (ChargebackBO) i.next();

			if (distributionLine != null) {
				if (distributionLine.getDistLocNumber() != null && distributionLine.getAccountNumber() != null
						&& distributionLine.getProductGrp() != null && distributionLine.getDistributionAmt() != null) {
					distributionLine.setLineNumber(j++);
					distributionLine.setLocationNumber(chargebackUpdateForm.getLocationNumber());
					distributionLine.setInvoiceNumber(chargebackUpdateForm.getInvoiceNumber());
					distributionLine.setCompanyCode(chargebackUpdateForm.getCompanyCode());

					saveDistributionList.add(distributionLine);
				}
			}
		}

		return saveDistributionList;

	}

	/**
	 * @param cbk
	 */
	public ChargebackBO populateObjectFromForm(ChargebackUpdateForm updateForm) {
		ChargebackBO cbk = new ChargebackBO();
		cbk.setLocationNumber(updateForm.getLocationNumber());
		cbk.setInvoiceNumber(updateForm.getInvoiceNumber());
		cbk.setInvoiceDate(new Date());
		cbk.setDueDate(new Date());
		cbk.setVendorId(updateForm.getVendorId());
		cbk.setVendorInvoice(updateForm.getVendorInvoice());
		cbk.setAttachment(updateForm.getAttachment());
		cbk.setTypeId(updateForm.getTypeId());
		cbk.setCreatorId(updateForm.getCreatorId());
		cbk.setBarCode(updateForm.getBarCode());
		cbk.setShortDesc(updateForm.getShortDesc());
		cbk.setExported(updateForm.getExported());
		cbk.setCancelled(updateForm.getCancelled());
		cbk.setNextAproverId(updateForm.getApprover());
		cbk.setInterInstr(updateForm.getInterInstr());
		cbk.setReasonCode(updateForm.getReasonCode());
		cbk.setInProcess(updateForm.getInProcess());
		cbk.setReferenceNumber(updateForm.getReferenceNumber());
		cbk.setPrdGrpCode(updateForm.getPrdGrpCode());
		cbk.setCompanyCode(updateForm.getCompanyCode());
		cbk.setAccountNumber(updateForm.getAccountNumber());
		cbk.setDistributionAmt(updateForm.getDistributionAmt());
		cbk.setDistLocNumber(updateForm.getDistLocNumber());
		cbk.setProductGrp(updateForm.getProductGrp());
		cbk.setLineNumber(updateForm.getLineNumber());
		cbk.setItemNumber(updateForm.getItemNumber());
		cbk.setItemPack(updateForm.getItemPack());
		cbk.setItemSize(updateForm.getItemSize());
		cbk.setItemDesc(updateForm.getItemDesc());
		cbk.setItemUpc(updateForm.getItemUpc());
		cbk.setItemSlot(updateForm.getItemSlot());
		cbk.setItemQuantity(updateForm.getItemQuantity());
		cbk.setItemPriceFormat(updateForm.getItemPriceFormat());
		cbk.setProductCode(updateForm.getProductCode());
		cbk.setDcNumber(updateForm.getDcNumber());
		cbk.setRegion(updateForm.getRegion());
		cbk.setDivision(updateForm.getDivision());
		cbk.setSubFund(updateForm.getSubFund());
		cbk.setAttachmentType(updateForm.getAttachmentType());
		return cbk;
	}

}