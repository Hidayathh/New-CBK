package com.unfi.cbk.controller.chargeback;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.bo.PlAccrualsBO;
import com.unfi.cbk.delegates.AdminDelegate;
import com.unfi.cbk.forms.ChargebackAdminForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.DateFunctions;
import com.unfi.cbk.util.ESAPIUtil;
import com.unfi.cbk.util.StringFunctions;

@Controller("plAccrualsReportController")
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class PlAccrualsReportController {

	static Logger log = Logger.getLogger(PlAccrualsReportController.class);
	@Autowired
	ActionMessages errors;
	@Autowired
	ActionMessages messages;

	@Autowired
	private AdminDelegate adminDelegate;

	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	@RequestMapping(value = "/chargebackAdmin", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=plAccruals" })
	public ModelAndView plAccruals(@ModelAttribute("chargebackAdminForm") ChargebackAdminForm chargebackAdminForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		chargebackAdminForm.setFormParameterMap(request);
		ServletOutputStream out = null;

		try {
			log.debug("***** CHARGEBACKAdmin  plAccurals *****");
			Map searchParametersFrom = chargebackAdminForm.getMap();

			HttpSession session = request.getSession();
			String SmUserId = (String) session.getAttribute("SmUserId");
			searchParametersFrom.put("userId", SmUserId);

			List l1 = (List) adminDelegate.getAccrualsList(searchParametersFrom);

			List<String> slist = new ArrayList<String>();
			for(int i = 0; i < l1.size(); i++)
			{
				PlAccrualsBO b1 =  (PlAccrualsBO) l1.get(i);
				slist.add(b1.getLocationNumber().trim());
			}
			Set<String> hashSet = new LinkedHashSet(slist);
	        ArrayList<String> locationNumbers = new ArrayList(hashSet);

			List  finalList = new ArrayList();
			for(int j=0; j< locationNumbers.size(); j++)
			{
				String locationNumb = locationNumbers.get(j).trim();
				List<PlAccrualsBO> groupList  = new ArrayList<PlAccrualsBO>();
				for(int k = 0; k < l1.size(); k++)
				{
					PlAccrualsBO b2 =  (PlAccrualsBO) l1.get(k);
					if(locationNumb.equals(b2.getLocationNumber().trim()))
					{
						groupList.add(b2);
					}
				}
				finalList.add(groupList);
			}
			
			List finalPopulateList = new ArrayList();
				for(int l = 0; l < finalList.size(); l++)
				{
					 List insideList   = (List) finalList.get(l);
					for(int m =0 ; m < insideList.size() ; m++)
					{	
						PlAccrualsBO b3 = (PlAccrualsBO) insideList.get(m);
						if(b3!=null && b3.getCompanyCode()!=null)
						{
						String company_code = b3.getCompanyCode();
						String acc_number = b3.getAccount();
						String location = b3.getLocationNumber();
						String rName = b3.getrName();
						String distAcc = b3.getDistAccount();
					
						List<PlAccrualsBO> insideFinallist = new ArrayList<PlAccrualsBO>();
						for (int n =0; n < insideList.size(); n++)
						{
							PlAccrualsBO b4 = (PlAccrualsBO) insideList.get(n);
							if(b4!=null && b4.getCompanyCode()!=null)
							{
								if(b4.getCompanyCode().equals(company_code) && b4.getAccount().equals(acc_number) && b4.getLocationNumber().equals(location) 
										&& b4.getrName().equals(rName) && b4.getDistAccount().equals(distAcc))
									{
										insideFinallist.add(b4);
										insideList.set(n, new PlAccrualsBO());
									}
							}
						}
						finalPopulateList.add(insideFinallist);	
					}
				}
			}
			
				for(int r =0; r < finalPopulateList.size(); r++)
				{
					List  s = (List) finalPopulateList.get(r);
					for( int  t =0; t < s.size(); t++)
					{
						PlAccrualsBO b5 = (PlAccrualsBO) s.get(t);
					}
				}
			out = response.getOutputStream();

			// The response headers must be set in the following order, or else IE
			// won't handle things properly.

			response.setHeader("Content-disposition", "attachment; filename=PlAccuralsResults.csv");
			response.setContentType("text/comma-separated-values");
			response.setHeader("Pragma", "public");
			response.setHeader("Cache-control", "must-revalidate");

			out.println();
			out.println();
			out.println("  ,,,,,                                                " + "   CHARGEBACK PL ACCRUALS  ");
			out.println("  ,,,,,,         									     " + DateFunctions.getTodayTime());
		//	out.println("  ,,,,,                                               " + "       CHARGEBACK ACCRUALS  ");
			String locationNo = null;
			for (int i = 0; i < finalPopulateList.size(); i++) 
			{
				List  s = (List) finalPopulateList.get(i);
				// Calculation of amount--PlAccrualsBO
				PlAccrualsBO bo = new PlAccrualsBO();
				Double total = 0.00;
				for (int k = 0; k < s.size(); k++) {
					bo = (PlAccrualsBO) s.get(k);
					total = total + Double.parseDouble(bo.getAmount());
				}
				
				for( int j =0; j < s.size(); j++)
				{
					PlAccrualsBO pBO = (PlAccrualsBO) s.get(j);
					if(j==0) 
					{
						out.println();
						out.print("  ,,,,, ,           " + pBO.getLocationNumber());
						out.print(",,");
						out.print( pBO.getrName());
						out.println();
						if(!pBO.getLocationNumber().equals(locationNo)) {
							out.println(",,,,, Chargeback #: , Date:, Vendor #: , Creator:,  Amount:  ");
							locationNo = pBO.getLocationNumber();
						}
					
						out.print(",");
						out.print(pBO.getCompanyCode());
						out.print(",");
						out.print(pBO.getAccount());
						out.print(",");
						out.print(pBO.getDistAccount());
						out.println(" , , , ,,,  " +"$ "+  total);
					}
					// Put a '=' and quotes around the document number to avoid
					// Excel dropping any leading zeros in the value.
					out.print(",");
					out.print(",");
					out.print(",");
					out.print(",");
					out.print(",");
					out.print("=\"" + ESAPIUtil.encodeforXSS(StringFunctions.convertNull(pBO.getInvoiceNumber()))	+ "\"");
					out.print(",");
					out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(pBO.getInvoiceDateString())));
					out.print(",");
					out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(pBO.getVendorNumber())));
					out.print(",");
					out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(pBO.getCreatorId())));
					out.print(",");
					out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull("$   "+   pBO.getAmount())));
					out.print(",");
					out.print("\n");
				}
			}
				
		} catch (Exception e) {
			e.printStackTrace();
			// Report the error using the appropriate name and ID.
			log.error("Exception in execute():" + e);
		} finally {
			if (out != null) {
				out.close();
			}
			response.flushBuffer();
		}

		return null;
	}

}
