package com.unfi.cbk.forms;

import java.util.List;

import org.apache.log4j.Logger;

/**
 * The ApproverSelectorForm class is the struts action form used for the user
 * selector pop up. It extends the ValidatorActionForm class in order to utilize
 * built-in struts validation.
 *
 * @author vpil001
 * @version 1.0
 */
public class ChargebackApproverReasonForm {// extends ValidatorActionForm {

	static Logger log = Logger.getLogger(ChargebackApproverReasonForm.class);

	private String denyReason = null;

	public String getDenyReason() {
		return denyReason;
	}

	public void setDenyReason(String denyReason) {
		this.denyReason = denyReason;
	}

	private String lastStepNumber = null;

	public String getLastStepNumber() {
		return lastStepNumber;
	}

	public void setLastStepNumber(String lastStepNumber) {
		this.lastStepNumber = lastStepNumber;
	}

	private List searchResults = null;
	private Integer results = null;
	private String selectedResult = null;

	/**
	 * @return
	 */
	public Integer getResults() {
		return results;
	}

	/**
	 * @return
	 */
	public List getSearchResults() {
		return searchResults;
	}

	/**
	 * @param i
	 */
	public void setResults(Integer i) {
		results = i;
	}

	/**
	 * @param list
	 */
	public void setSearchResults(List list) {
		searchResults = list;
	}

	/**
	 * @return
	 */
	public String getSelectedResult() {
		return selectedResult;
	}

	/**
	 * @param string
	 */
	public void setSelectedResult(String string) {
		selectedResult = string;
	}

}