package com.unfi.cbk.config;

import javax.servlet.http.Cookie;

/**
 * Class which provides functions to manipulate cookies.
 *
 * Creation date: (01/31/2002 10:11:08 AM)
 * 
 * @author: Bill Rossman
 */
public final class CookieUtil {
	/**
	 * Constructor is private to prevent anyone from instantiating this object.
	 *
	 * Creation date: (02/04/2002 5:23:44 PM)
	 */
	private CookieUtil() {
	}

	/**
	 * Reads the specified value from the cookie. Returns the specified value or
	 * null if the value isn't found.
	 *
	 * Creation date: (01/31/2002 11:20:21 AM)
	 * 
	 * @return java.lang.String
	 * @param request javax.servlet.http.HttpServletRequest
	 * @param name    java.lang.String
	 */
	public static String readCookie(javax.servlet.http.HttpServletRequest request, String name) {
		Cookie[] cookieArray = request.getCookies();
		String value = null;

		if (cookieArray != null) {
			for (int x = 0; x < cookieArray.length; x++) {
				if (cookieArray[x].getName().equalsIgnoreCase(name)) {
					value = cookieArray[x].getValue();
					break;
				}
			}
		}

		return (value);
	}

	/**
	 * Inserts the specified name and value into a cookie on the client.
	 *
	 * Pass null for value to remove the cookie from the client.
	 *
	 * Creation date: (01/31/2002 11:26:11 AM)
	 * 
	 * @param response javax.servlet.http.HttpServletResponse
	 * @param name     java.lang.String
	 * @param value    java.lang.String
	 */
	public static void updateCookie(javax.servlet.http.HttpServletResponse response, String name, String value) {
		Cookie cookie;

		if (value != null) {
			cookie = new Cookie(name, value);
			String isCookieSecure = System.getProperty("server.servlet.session.cookie.secure", "true");
			if (isCookieSecure != null) {
				cookie.setSecure(new Boolean(isCookieSecure));
			}
			cookie.setHttpOnly(true);
			// cookie.setPath("/");
		} else {
			cookie = new Cookie(name, "");
			cookie.setMaxAge(0);
		}

		response.addCookie(cookie);
	}
}