package com.unfi.cbk.controller.chargeback;

import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackReportBO;
import com.unfi.cbk.delegates.ChargebackReportDelegate;
import com.unfi.cbk.forms.ChargebackReportForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.DateFunctions;
import com.unfi.cbk.util.ESAPIUtil;
import com.unfi.cbk.util.StringFunctions;

@Controller("chargebackReport_Chargeback")
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ChargebackReportController {
	static Logger log = Logger.getLogger(ChargebackReportController.class);
	@Autowired
	ActionMessages errors;

	@Autowired
	ActionMessages messages;
	@Autowired
	Environment env;

	@Autowired
	private ChargebackReportDelegate chargebackReportDelegate;

	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	@RequestMapping(value = "/chargebackReport", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=chargeReport" })
	public ModelAndView chargeReport(@ModelAttribute("chargebackReportForm") ChargebackReportForm chargebackReportForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackReportForm.setFormParameterMap(request);

		if (request.getParameter("isformreset") != null) {
			chargebackReportForm.reset(request);
		}

		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		mav.setViewName(ActionUrlMapping.CHARGEBACKREPORTACTION.get("byChargeReport"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackReportForm", chargebackReportForm);
		request.setAttribute("reasons", chargebackReportDelegate.getReasonCode());

		return mav;
	}

	@RequestMapping(value = "/cbkReportResults", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView execute(@ModelAttribute("chargebackReportForm") ChargebackReportForm chargebackReportForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		chargebackReportForm.setFormParameterMap(request);
		ServletOutputStream out = null;

		try {
			log.debug("***** CHARGEBACK REPORT- RESULTS *****");
			// HttpSession session=request.getSession();

			Map<String, Comparable> searchParametersFromForm = chargebackReportForm.getMap();

			log.debug("*****  CHARGEBACK REPORT *****");
			Map searchParametersFrom = chargebackReportForm.getMap();

			String fromDate = null;
			String toDate = null;

			if (request.getParameter("datefrom") != null) {
				fromDate = request.getParameter("datefrom");
			}
			if (request.getParameter("dateTo") != null) {
				toDate = request.getParameter("dateTo");
			}

			searchParametersFrom.put("showAll", "true");

			searchParametersFrom.put("fromDate", DateFunctions.chargebackDateConversion(fromDate));
			searchParametersFrom.put("toDate", DateFunctions.chargebackDateConversion(toDate));

			// userId - Originator
			if (chargebackReportForm.getVendorId() != null && !chargebackReportForm.getVendorId().isEmpty()) {
				searchParametersFrom.put("vendorId", chargebackReportForm.getVendorId());
			}
			// searchParametersFrom.put("vendorId", chargebackReportForm.getVendorId());
			if (chargebackReportForm.getReasonCode() != null && !chargebackReportForm.getReasonCode().isEmpty()) {
				searchParametersFrom.put("reasonCode", chargebackReportForm.getReasonCode());
			}

			ResultList searchResults = chargebackReportDelegate.getChargebackReportList(searchParametersFrom);
			chargebackReportForm.setSearchResults(searchResults.getList());

			List ResulstList = (List) chargebackReportForm.getSearchResults();

			out = response.getOutputStream();

			// The response headers must be set in the following order, or else IE
			// won't handle things properly.
			// response.setHeader("Content-length", ""+file.getFile().length());
			response.setHeader("Content-disposition", "attachment; filename=ChargebackReport.csv");
			response.setContentType("text/comma-separated-values");
			response.setHeader("Pragma", "public");
			response.setHeader("Cache-control", "must-revalidate");

			// out.println("Document Results (" + searchCriteriaSummary + ")");
			out.println(",,,,,,,Chargeback Report List  ");
			out.println(",,,,,Chargeback Report List  pulled: " + DateFunctions.getTodayTime());
			/*
			 * if (!dateRangeUsed.equals("")) { out.println("Deduction extract date range: "
			 * + dateRangeUsed); }
			 */
			out.println();
			out.println(
					",DOCUMENT,, Location,,DOCUMENT_DATE,,VENDOR_NUMBER,,VENDOR_NAME,,TYPE_DESCRIPTION,,CREATOR,, AmoBRIEF_DESCRIPTION,,REASON_CODE,PRODUCT_GROUP_CODE,AMOUNT,DIST_LOCATION_NUMBAR,STATE,ACCOUNT_NUMBER,DISTRIBUTION_AMOUNT_DUE_DATE");
			out.println("");

			for (int i = 0; i < ResulstList.size(); i++) {
				ChargebackReportBO reportBO = (ChargebackReportBO) ResulstList.get(i);

				// Put a '=' and quotes around the document number to avoid
				// Excel dropping any leading zeros in the value.
				out.print(",");
				out.print("=\"" + ESAPIUtil.encodeforXSS(StringFunctions.convertNull(reportBO.getDocumentNumber()))
						+ "\"");
				out.print(",,");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(reportBO.getLocationNumber())));
				out.print(",,");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(reportBO.getDocumentDate())));
				out.print(",,");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(reportBO.getVendorNumber())));
				out.print(",,");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(reportBO.getVendorName())));
				out.print(",,");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(reportBO.getTypeDescription())));
				out.print(",,");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(reportBO.getCreator())));
				out.print(",,");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(reportBO.getBriefDecription())));
				out.print(",,");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(reportBO.getReasonCode())));
				out.print(",,");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(reportBO.getProductGroupCode())));
				out.print(",,");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(reportBO.getAmount())));
				out.print(",,");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(reportBO.getDistLocNumber())));
				out.print(",,");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(reportBO.getState())));
				out.print(",,");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(reportBO.getAccNumber())));
				out.print(",,");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(reportBO.getDistributionAmount())));
				out.print(",,");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(reportBO.getDueDate())));
				out.print(",,");

				out.print("\n");
			}

		} catch (Exception e) {
			e.printStackTrace();
			// Report the error using the appropriate name and ID.
			log.error("Exception in execute():" + e);
		} finally {
			if (out != null) {
				out.close();
			}
			response.flushBuffer();
		}

		// No mappings or forwards for this action...
		return null;
	}

}
