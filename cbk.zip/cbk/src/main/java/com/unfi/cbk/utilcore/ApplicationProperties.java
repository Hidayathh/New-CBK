/*
 * Created on Oct 24, 2005
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.unfi.cbk.utilcore;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.unfi.cbk.exceptions.CbkRuntimeException;

/**
 * @author yhp6y2l
 *
 *         To change the template for this generated type comment go to
 *         Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ApplicationProperties {
	private static ApplicationProperties SINGLETON = null;
	/**
	 * Properties themselves.
	 */
	private static Properties props = null;
	/**
	 * Name of the resource for primary property values (should be in the
	 * classpath).
	 */
	private static final String BUNDLE_NAME = "cbkApplication.properties";
	/**
	 * Name of a property that should be found in the ExternalResources to assert
	 * that this component found its main bundle.
	 */
	private static final String PROPERTIES_FOUND = "com.unfi.cbk.properties.found";
	/**
	 * Retrieve the CID Schema name from the properties file.
	 */
	public static final String DB_SCHEMA_NAME = "db.schema.name";

	public static final String FILE_PATH_PROPERTY_NAME = "com.unfi.cbk.FILE_ZONE_PATH";
	private static String FILE_PATH = null;

	public static String getProdFilePath() {
		if (FILE_PATH == null) {
			FILE_PATH = getString(FILE_PATH_PROPERTY_NAME, null);
			if (FILE_PATH == null || FILE_PATH.length() < 1) {
				getLog().error(
						"No File path, insure that the property \'" + ApplicationProperties.FILE_PATH_PROPERTY_NAME
								+ "\' has been properly set in the config file.");
				throw new CbkRuntimeException(
						"No file path, insure that the property \'" + ApplicationProperties.FILE_PATH_PROPERTY_NAME
								+ "\' has been properly set in the config file.");
			}
		}
		return FILE_PATH;
	}

	/*
	 * private static String INVOICE_FILE_PATH = null; public static String
	 * getInvoiceFilePath() { if (INVOICE_FILE_PATH == null) { INVOICE_FILE_PATH =
	 * getString("com.supervalu.epass.INVOICE_FILE_PATH", null); } return
	 * INVOICE_FILE_PATH; }
	 */

	/**
	 * Cached version of the application default schema name
	 */
	private static String DEFAULT_APPLICATION_SCHEMA = null;

	/**
	 * Gets the default application schema name.
	 * 
	 * @return The default application schema name.
	 */
	public static String getDBSchema() {
		if (DEFAULT_APPLICATION_SCHEMA == null) {
			DEFAULT_APPLICATION_SCHEMA = getString(DB_SCHEMA_NAME, null);
			if (DEFAULT_APPLICATION_SCHEMA == null || DEFAULT_APPLICATION_SCHEMA.length() < 1) {
				getLog().error("No default schema name, insure that the property \'"
						+ ApplicationProperties.DB_SCHEMA_NAME + "\' has been properly set in the config file.");
				throw new CbkRuntimeException("No default schema name, insure that the property \'"
						+ ApplicationProperties.DB_SCHEMA_NAME + "\' has been properly set in the config file.");
			}
		}
		return DEFAULT_APPLICATION_SCHEMA;
	}

	/**
	 * 
	 * @return
	 */
	public static String checkProperties() {
		return getString(PROPERTIES_FOUND, null);
	}

	/** Name of the application name (full) property */
	private static final String APPLICATION_FULLNAME_PROPERTY_NAME = "com.unfi.cbk.APP_NAME";

	public static String getApplicationFullName() {
		return getString(APPLICATION_FULLNAME_PROPERTY_NAME);
	}

	/**
	 * Hide the default constructor.
	 *
	 */
	private ApplicationProperties() {
	}

	/**
	 * Forces a reload of the property bundle(s).
	 */
	public static void forceReload() {

		LogFactory.getLog(ApplicationProperties.class).warn("Resetting the property bundle.");
		props = null;
		DEFAULT_APPLICATION_SCHEMA = null;
	}

	/**
	 * Gets the singleton instance so that non-static methods may be executed.
	 * 
	 * @return
	 */
	public static ApplicationProperties getSingleton() {
		if (SINGLETON == null) {
			SINGLETON = new ApplicationProperties();
		}
		return SINGLETON;
	}

	/**
	 * 
	 * @param name Name of the property.
	 * @return Value of the named property as a String.
	 */
	public static String getString(String name) {
		if (props == null) {
			loadProperties();
		}
		String ret = (String) props.get(name);
		if (ret == null) {
			getLog().warn("Unable to find property named \'" + name + "\'");
		}
		return ret;
	}

	/**
	 * 
	 * @param name Name of the property.
	 * @return Value of the named property as a String.
	 */
	public static String getString(String name, String defaultValue) {
		if (props == null) {
			loadProperties();
		}
		return (String) props.getProperty(name, defaultValue);
	}

	/**
	 * Gets a property by name and tries to interprete it as an int. If the property
	 * is not found or errors occur then the default value is returned.
	 * 
	 * @param name         Name of the property.
	 * @param defaultValue The default value to use.
	 * @return The property value interpreted as an int if found and interpretable
	 *         as an int, otherwise the default value.
	 */
	public static int getInt(String name, int defaultValue) {
		if (props == null) {
			loadProperties();
		}
		Object obj = props.get(name);
		int ret = defaultValue;
		if (obj == null) {
			// use default
		} else if (obj instanceof Number) {
			ret = ((Number) obj).intValue();
		} else if (obj instanceof String) {
			try {
				ret = Integer.parseInt((String) obj);
			} catch (NumberFormatException e) {
				getLog().warn("Configuration property \'" + name + "\' value \'" + (String) obj
						+ "\' not interpretable as integer. Default of " + ret + " used.");
			}
		} else {
			getLog().warn("Configuration property \'" + name + "\' is of non-convertable type \'"
					+ obj.getClass().getName() + "\', using default of " + ret);
		}
		return ret;
	}

	/**
	 * Gets a property by name and tries to interprete it as a <code>long</code>. If
	 * the property is not found or errors occur then the default value is returned.
	 * 
	 * @param name         Name of the property.
	 * @param defaultValue The default value to use.
	 * @return The property value interpreted as an int if found and interpretable
	 *         as an int, otherwise the default value.
	 */
	public static long getLongPrim(String name, long defaultValue) {
		if (props == null) {
			loadProperties();
		}
		Object obj = props.get(name);
		long ret = defaultValue;
		if (obj == null) {
			// use default
		} else if (obj instanceof Number) {
			ret = ((Number) obj).longValue();
		} else if (obj instanceof String) {
			try {
				ret = Long.parseLong((String) obj);
			} catch (NumberFormatException e) {
				getLog().warn("Configuration property \'" + name + "\' value \'" + (String) obj
						+ "\' not interpretable as a long. Default of " + ret + " used.");
			}
		} else {
			getLog().warn("Configuration property \'" + name + "\' is of non-convertable type \'"
					+ obj.getClass().getName() + "\', using default of " + ret);
		}
		return ret;
	}

	/**
	 * Load the singleton properties by first loading the primary resource and then
	 * the second. If the second properties file is not found then a warning message
	 * is written to the application log.
	 *
	 */
	private static synchronized void loadProperties() {
		Properties temp = new Properties();
		try {
			appendProperties(temp, BUNDLE_NAME);
		} catch (IOException ioe) {
			getLog().fatal("IOException during get of properties from \'" + BUNDLE_NAME + "\'");
			getLog().fatal(ioe.getMessage());
			throw new CbkRuntimeException("IOException during get of properties from \'" + BUNDLE_NAME + "\'", ioe);
		}
		props = temp;
	}

	/**
	 * Append a resource worth of properties.
	 * 
	 * @param temp       Property set to add to.
	 * @param bundleName Qualified name of the resource.
	 * @throws IOException
	 */
	private static void appendProperties(Properties temp, String bundleName) throws IOException {
		InputStream resourceStream = ApplicationProperties.class.getClassLoader().getResourceAsStream(bundleName);
		if (resourceStream != null) {
			temp.load(resourceStream);
			resourceStream.close();
		} else {
			throw new IOException("Resource not found \'" + bundleName + "\'");
		}
	}

	private static Log LOG = null;

	/**
	 * Gets the application log.
	 * 
	 * @return The application log for this class.
	 */
	private static Log getLog() {
		if (LOG == null) {
			LOG = LogFactory.getLog(ApplicationProperties.class);
		}
		return LOG;
	}

	private static String DEFAULT_USERID = null;

	public static String getDefaultUserID() {
		if (DEFAULT_USERID == null) {
			DEFAULT_USERID = getString("DEFAULT_USER_ID", null);
		}
		return DEFAULT_USERID;
	}

	private static String DEFAULT_ROLE = null;

	public static String getDefaultRole() {
		if (DEFAULT_ROLE == null) {
			DEFAULT_ROLE = getString("DEFAULT_USER_ROLES", null);
		}
		return DEFAULT_ROLE;
	}

	private static String DEFAULT_USER_TYPE = null;

	public static String getDefaultUserType() {
		if (DEFAULT_USER_TYPE == null) {
			DEFAULT_USER_TYPE = getString("DEFAULT_USER_TYPE", null);
		}
		return DEFAULT_USER_TYPE;
	}

	private static String HELP_LINK_USER = null;

	public static String getHelpLinkUser() {
		if (HELP_LINK_USER == null) {
			HELP_LINK_USER = getString("help.link.user", null);
		}
		return HELP_LINK_USER;
	}

	private static String HELP_LINK_EMPLOYEE = null;

	public static String getHelpLinkEmployee() {
		if (HELP_LINK_EMPLOYEE == null) {
			HELP_LINK_EMPLOYEE = getString("help.link.employee", null);
		}
		return HELP_LINK_EMPLOYEE;
	}

	private static String DEFAULT_USER_NAME = null;

	public static String getDefaultUserName() {
		if (DEFAULT_USER_NAME == null) {
			DEFAULT_USER_NAME = getString("DEFAULT_USER_NAME", null);
		}
		return DEFAULT_USER_NAME;
	}

	private static String WRAPPER_CLASS = null;

	public static String getWrapperClass() {
		if (WRAPPER_CLASS == null) {
			WRAPPER_CLASS = getString("WRAPPER_CLASS", null);
		}
		return WRAPPER_CLASS;
	}

	private static final String MAIL_HOST = "mail.host.name";

	public static String getMailHost() {
		return getString(MAIL_HOST);
	}

	private static final String DUMMY_EMAIL = "dummy.email.address";

	public static String getDummyEMail() {
		return getString(DUMMY_EMAIL);
	}

	private static final String PAGE_ACCESS_CONTROL = "com.unfi.cbk.PAGE_ACCESS_CONTROL";

	public static String getPageControlFlag() {
		return getString(PAGE_ACCESS_CONTROL);
	}
}
