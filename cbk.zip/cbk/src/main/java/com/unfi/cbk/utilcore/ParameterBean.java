package com.unfi.cbk.utilcore;

import java.io.Serializable;

//import org.apache.log4j.Logger;
/**
 * 
 * @author yhp6y2l
 *
 */
public class ParameterBean implements Serializable {
	// static Logger log = Logger.getLogger(ParameterBean.class);
	private Object paramValue;
	private boolean isOutputParam;

	/**
	 * Initializes a newly created <code>ParameterBean</code> object. The
	 * constructor takes an <code>Object</code> and a <code>boolean</code> and makes
	 * them available to the entire instance.
	 * 
	 * @param paramValue    the parameter object
	 * @param isOutputParam <code>boolean</code> indicating if the parameter is and
	 *                      output parameter
	 */
	public ParameterBean(Object paramValue, boolean isOutputParam) {
		// Constructor
		this.paramValue = paramValue;
		this.isOutputParam = isOutputParam;

	}

	// **************************************//
	/**
	 * Get paramValue
	 * 
	 * @return Object
	 */
	public Object getParamValue() {
		return paramValue;

	}

	/**
	 * Set paramValue
	 * 
	 * @param object <code>Object</code> to set
	 */
	public void setParamValue(Object object) {
		this.paramValue = object;

	}

	// **************************************//
	/**
	 * Get isOutputParam
	 * 
	 * @return boolean
	 */
	public boolean isOutputParam() {
		return this.isOutputParam;

	}
	// **************************************//

}