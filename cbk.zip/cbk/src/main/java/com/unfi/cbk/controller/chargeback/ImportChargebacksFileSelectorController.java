package com.unfi.cbk.controller.chargeback;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.forms.ImportChargebacksFileSelectorForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.Constants;

@Controller("importChargebacksFileAction_importChargebackFileSelector")
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ImportChargebacksFileSelectorController {

	static Logger log = Logger.getLogger(ImportChargebacksFileSelectorController.class);
	@Autowired
	ActionMessages errors;
	

	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	@RequestMapping(value = "/importChargebacksFileSelector", method = { RequestMethod.GET,
			RequestMethod.POST }, params = { "action=open" })
	public ModelAndView open(@ModelAttribute ImportChargebacksFileSelectorForm importChargebacksFileSelectorForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();

		boolean exceptionOccurred = false;

		try {
			log.debug("*****ImportChargebacksFileSelectorController OPEN *****");


		} catch (Exception e) {
			exceptionOccurred = true;
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);
			if (errors.isEmpty()) {
				errors.add("error", "errors.general");
			}
		}

		if (!exceptionOccurred) {
			// forward = mapping.findForward("open");
			mav.setViewName(ActionUrlMapping.IMPORTCHARGEBACKFILESELECTORACTION.get("open"));
		}

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			// forward = mapping.findForward("failure");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
		}

		request.setAttribute("actionMessages", errors);
		request.setAttribute("importChargebacksFileSelectorForm", importChargebacksFileSelectorForm);
		return mav;
	}

}
