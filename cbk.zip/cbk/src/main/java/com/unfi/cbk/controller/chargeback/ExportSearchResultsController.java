package com.unfi.cbk.controller.chargeback;

import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.delegates.ChargebackSearchDelegate;
import com.unfi.cbk.forms.ChargebackSearchForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.DateFunctions;
import com.unfi.cbk.util.ESAPIUtil;
import com.unfi.cbk.util.StringFunctions;

/**
 * The ExportSearchResultsAction class is the struts action called to export the
 * search results to a CSV file. The action makes the call to the database for
 * the results, parses through each row, and creates a CSV with one line per
 * result row.
 * <p>
 * The resulting text file is sent to the requesing page as the response with
 * the appropriate mime type and response headers set.
 *
 * @author vpil001
 * @since 1.0
 */
@Controller("exportSearchResultsAction_chargeback")
public class ExportSearchResultsController {// extends Action {
	static Logger log = Logger.getLogger(ExportSearchResultsController.class);

	@Autowired
	private ChargebackSearchDelegate chargebackSearchDelegate;

	public ExportSearchResultsController(ChargebackSearchDelegate chargebackSearchDelegate) {
		this.chargebackSearchDelegate = chargebackSearchDelegate;
	}

	@Autowired
	ActionMessages error;
	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	public ExportSearchResultsController() {

	}

	@RequestMapping(value = "/exportChargebacktResults", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView execute(@ModelAttribute("chargebackSearchForm") ChargebackSearchForm chargebackSearchForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		chargebackSearchForm.setFormParameterMap(request);
		ServletOutputStream out = null;

		try {
			log.debug("***** CHARGEBACK SEARCH - EXPORT *****");
			// HttpSession session=request.getSession();

			Map<String, Comparable> searchParametersFromForm = chargebackSearchForm.getMap();

			String dateCriteria = request.getParameter("dateCriteria");
			String fromDate = request.getParameter("fromDate");
			String toDate = request.getParameter("toDate");

			String userId = chargebackSearchForm.getString("userId");

			String vendorUsed = String.valueOf(chargebackSearchForm.getValue("vendorId"));

			searchParametersFromForm.put("originator", chargebackSearchForm.getOriginator());
			searchParametersFromForm.put("nextApprover", chargebackSearchForm.getNextApprover());
			searchParametersFromForm.put("vendorId", chargebackSearchForm.getVendorId());
			searchParametersFromForm.put("locationNumber", chargebackSearchForm.getLocationNumber());

			searchParametersFromForm.put("invoiceFrom", chargebackSearchForm.getInvoiceFrom());
			searchParametersFromForm.put("invoiceTo", chargebackSearchForm.getInvoiceTo());
			searchParametersFromForm.put("amountFrom", chargebackSearchForm.getAmountFrom());
			searchParametersFromForm.put("amountTo", chargebackSearchForm.getAmountTo());
			searchParametersFromForm.put("dateCriteria", dateCriteria);
			searchParametersFromForm.put("type", chargebackSearchForm.getType());
			searchParametersFromForm.put("fromDate", fromDate);
			searchParametersFromForm.put("toDate", toDate);

	
			if (("Cancelled").equalsIgnoreCase(chargebackSearchForm.getStatus())) {// Cancelled IS NOT NULL
				log.debug("********CANCELLED SELECTED******");
				searchParametersFromForm.put("cancelled", "true");
			} else
			// Active is NULL
			{
				searchParametersFromForm.put("active", "true");
			}
			if (("Final").equalsIgnoreCase(chargebackSearchForm.getAPStatus())) {// Final IS NOT NULL
				log.debug("********FINAL SELECTED******");
				searchParametersFromForm.put("final", true);
			} else
			// notFinal IS NULL
			{
				searchParametersFromForm.put("notFinal", true);
			}

			// Get the search results based on the parameters in the form
			ResultList searchResults = chargebackSearchDelegate.getChargebacks(searchParametersFromForm);
		
			chargebackSearchForm.setSearchResults(searchResults.getList());
			// chargebackSearchForm =
			// (ChargebackSearchForm)session.getAttribute("chargebackSearchForm");
			List ResulstList = (List) chargebackSearchForm.getSearchResults();

			out = response.getOutputStream();

			// The response headers must be set in the following order, or else IE
			// won't handle things properly.
			// response.setHeader("Content-length", ""+file.getFile().length());
			response.setHeader("Content-disposition", "attachment; filename=ChargebackSearchResults.csv");
			response.setContentType("text/comma-separated-values");
			response.setHeader("Pragma", "public");
			response.setHeader("Cache-control", "must-revalidate");

			// out.println("Document Results (" + searchCriteriaSummary + ")");
			out.println("Chargebacks pulled for vendor number: " + vendorUsed);
			out.println("Chargebacks pulled: " + DateFunctions.getTodayTime());
			/*
			 * if (!dateRangeUsed.equals("")) { out.println("Deduction extract date range: "
			 * + dateRangeUsed); }
			 */
			out.println();
			out.println("Invoice, Location, Invoice Date, Vendor, Amount, Originator, Next Approver, FIN, CA");

			for (int i = 0; i < ResulstList.size(); i++) {
				ChargebackBO chargebackBO = (ChargebackBO) ResulstList.get(i);

				// Put a '=' and quotes around the document number to avoid
				// Excel dropping any leading zeros in the value.

				out.print("=\"" + ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getInvoiceNumber()))
						+ "\"");
				out.print(",");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getLocationNumber())));
				out.print(",");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getInvoiceDateString())));
				out.print(",");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getVendorId())));
				out.print(",");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getNetAmount())));
				out.print(",");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getOriginator())));
				out.print(",");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getApprover())));
				out.print(",");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getFin())));
				out.print(",");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getCa())));
				out.print("\n");
			}

		} catch (Exception e) {
			e.printStackTrace();
			// Report the error using the appropriate name and ID.
			log.error("Exception in execute():" + e);
		} finally {
			if (out != null) {
				out.close();
			}
			response.flushBuffer();
		}

		// No mappings or forwards for this action...
		return null;
	}

}