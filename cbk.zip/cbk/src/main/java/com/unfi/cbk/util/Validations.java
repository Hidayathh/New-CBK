package com.unfi.cbk.util;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;

import com.unfi.cbk.utilcore.DaoDBUtil;

/**
 * The Validations class is used to perform server-side validations that can't
 * be done by the struts validator.
 *
 * @author yhp6y2l
 * @since 1.0
 */
public class Validations extends DaoDBUtil implements Serializable {
	static Logger log = Logger.getLogger(Validations.class);


	/**
	 * Verify the from date is less than the to date.
	 * 
	 * @param fromDate
	 * @param toDate
	 * @return
	 */
	public boolean isValidDateRange(String fromDate, String toDate) {
		boolean isValid = true;
		try {
			Date fromDateObj = DateFunctions.stringToDate(fromDate);
			Date toDateObj = DateFunctions.stringToDate(toDate);

			// If either date object is null, there was a problem parsing the
			// date, so assume that it isn't a valid date.
			if (fromDateObj == null || toDateObj == null) {
				isValid = false;

			} else {
				// Verify condition
				int dateCompare = DateFunctions.compareDates(fromDateObj, toDateObj);

				if (dateCompare > 0) {
					// The from date is greater than the to date - invalid.
					isValid = false;
				}
			}

		} catch (Exception e) {
			log.error("Exception in isValidDateRange():" + e);
			isValid = false;
		}

		// log.debug("isValidDateRange: " + isValid);
		return isValid;
	}

	/**
	 * Verify neither date goes back farther than the passed in number of years
	 * 
	 * @param fromDate
	 * @param toDate
	 * @param maxYears
	 * @return
	 */
	public boolean isValidTimePeriod(String fromDate, String toDate, String maxYears) {
		boolean isValid = true;
		try {
			Date fromDateObj = DateFunctions.stringToDate(fromDate);
			Date toDateObj = DateFunctions.stringToDate(toDate);

			// If either date object is null, there was a problem parsing the
			// date, so assume that it isn't a valid date.
			if (fromDateObj == null || toDateObj == null) {
				isValid = false;
			} else {
				// Verify condition
				int maxYearsToGoBack = -Integer.parseInt(maxYears);
				Date maxYearsAgo = DateFunctions.adjustCurrentDateNoFormat(maxYearsToGoBack);

				int dateCompare1 = DateFunctions.compareDates(maxYearsAgo, fromDateObj);
				int dateCompare2 = DateFunctions.compareDates(maxYearsAgo, toDateObj);

				if (dateCompare1 > 0 || dateCompare2 > 0) {
					// One of the dates is more than the max specified years ago - invalid
					isValid = false;
				}

			}

		} catch (Exception e) {
			log.error("Exception in isValidTimePeriod():" + e);
			isValid = false;
		}

		// log.debug("isValidTimePeriod: " + isValid);
		return isValid;
	}

	/**
	 * Verify neither date is in the future
	 * 
	 * @param fromDate
	 * @param toDate
	 * @return
	 */
	public boolean isNotFutureDate(String fromDate, String toDate) {
		boolean isValid = true;
		try {
			Date fromDateObj = DateFunctions.stringToDate(fromDate);
			Date toDateObj = DateFunctions.stringToDate(toDate);

			// If either date object is null, there was a problem parsing the
			// date, so assume that it isn't a valid date.
			if (fromDateObj == null || toDateObj == null) {
				isValid = false;
			} else {
				// Verify condition (3)
				int dateCompare1 = DateFunctions.compareDates(fromDateObj, new Date());
				int dateCompare2 = DateFunctions.compareDates(toDateObj, new Date());

				if (dateCompare1 > 0 || dateCompare2 > 0) {
					// One of the dates is a future date - invalid
					isValid = false;
				}
			}

		} catch (Exception e) {
			log.error("Exception in isNotFutureDate():" + e);
			isValid = false;
		}

		// log.debug("isNotFutureDate:" + isValid);
		return isValid;
	}

	/**
	 * Verify neither date is in the future
	 * 
	 * @param fromDate
	 * @param toDate
	 * @return
	 */
	public boolean isNot30PlusDaysInFuture(String fromDate, String toDate) {
		boolean isValid = true;
		try {
			Date fromDateObj = DateFunctions.stringToDate(fromDate);
			Date toDateObj = DateFunctions.stringToDate(toDate);

			// If either date object is null, there was a problem parsing the
			// date, so assume that it isn't a valid date.
			if (fromDateObj == null || toDateObj == null) {
				isValid = false;
			} else {
				// Verify condition (3)

				Date testDate1 = DateFunctions.adjustCurrentDateByDaysNoFormat(30);

				int dateCompare1 = DateFunctions.compareDates(fromDateObj, testDate1);
				int dateCompare2 = DateFunctions.compareDates(toDateObj, testDate1);

				if (dateCompare1 > 0 || dateCompare2 > 0) {
					// One of the dates is a future date - invalid
					isValid = false;
				}
			}

		} catch (Exception e) {
			log.error("Exception in isNot30PlusDaysInFuture():" + e);
			isValid = false;
		}

		// log.debug("isNotFutureDate:" + isValid);
		return isValid;
	}

	/**
	 * Takes a vendor ID and adds any leading zeros needed to make it 7 digits.
	 * 
	 * @return the formatted vendor ID
	 * @param vendorId the vendor ID to format
	 * @since 1.0
	 */
	public static String formatVendorId(String vendorId) {
		StringBuffer formattedVendorId = new StringBuffer(vendorId);
		int targetLength = 7;

		while (formattedVendorId.length() < targetLength) {
			formattedVendorId.insert(0, "0");

		}

		return formattedVendorId.toString();

	}

	
	/**
	 * Verify the date does not go back farther than the passed in number of months
	 * 
	 * @param docDate
	 * @param maxYears
	 * @return
	 */
	public boolean isValidTimePeriodMonths(String docDate, int maxMonths) {
		Date date = DateFunctions.stringToDate(docDate);
		if (date == null) {
			return false;
		}
		Date today = new Date();
		Calendar now = Calendar.getInstance();
		now.setTime(today);
		Calendar testDate = Calendar.getInstance();
		testDate.setTime(date);
		testDate.add(Calendar.MONTH, maxMonths);
		if (testDate.before(now)) {
			return false;
		}
		return true;
	}

	/**
	 * Verify neither date goes back farther than the passed in number of months
	 * 
	 * @param fromDate
	 * @param toDate
	 * @param maxYears
	 * @return
	 */
	public boolean isValidTimePeriodMonths(String fromDate, String toDate, int maxMonths) {
		Date fromDateObj = DateFunctions.stringToDate(fromDate);
		Date toDateObj = DateFunctions.stringToDate(toDate);
		if (fromDateObj == null || toDateObj == null) {
			return false;
		}
		Date today = new Date();
		Calendar now = Calendar.getInstance();
		now.setTime(today);
		Calendar testDate = Calendar.getInstance();
		testDate.setTime(fromDateObj);
		testDate.add(Calendar.MONTH, maxMonths);
		if (testDate.before(now)) {
			return false;
		}
		testDate.setTime(toDateObj);
		testDate.add(Calendar.MONTH, maxMonths);
		if (testDate.before(now)) {
			return false;
		}
		return true;

	}
}