/*
 * Created on Oct 6, 2005
 * 
 */
package com.unfi.cbk.email;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Collection;
import java.util.Iterator;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.log4j.Logger;

import com.unfi.cbk.util.ESAPIUtil;

/**
 * @author yhp6y2l
 * @version 1.0 Oct 6, 2005
 * 
 *          This is a thin wrapper around the MimeMessage object.
 * 
 */
public class WrappedMessage {

	protected MimeMessage message = null;
	protected Multipart multipart = null;
	protected StringBuffer header = null;
	protected StringBuffer body = null;
	protected StringBuffer footer = null;

	private static Logger log = Logger.getLogger(WrappedMessage.class);
	private static final String MAIL_SMTP_HOST = "mail.smtp.host";


	public WrappedMessage(String host) {
		System.getProperties().put(MAIL_SMTP_HOST, host);
		Session session = Session.getInstance(System.getProperties(), null);
		message = new MimeMessage(session);
		multipart = new MimeMultipart();
	}

	public void setAttachment(String pathAndName, String fileName) {
		if (fileName != null) {
			File f = new File(pathAndName);
			if (f.exists()) {
				MimeBodyPart attachment = new MimeBodyPart();
				try {
					attachment.setDataHandler(new DataHandler(new FileDataSource(f)));
					attachment.setFileName(ESAPIUtil.encode(fileName));
					attachment.setDisposition(javax.mail.Part.ATTACHMENT);
					multipart.addBodyPart(attachment);
				} catch (Exception e) {
					log.error("Cannot create attachment: " + e.getMessage());
				}
			}
		}
	}

	public String getBody() {
		return (header == null ? "" : header.toString()) + (body == null ? "" : body.toString())
				+ (footer == null ? "" : footer.toString());
	}

	/**
	 * 
	 * @param text The text to append.
	 */
	public void appendBody(String text) {
		if (body == null) {
			body = new StringBuffer();
		}
		body.append(text);
	}

	public void setBody(String text) {
		body = new StringBuffer(text);
	}

	/**
	 * 
	 * @param text The text to prepend
	 */
	public void appendHeader(String text) {
		if (header == null) {
			header = new StringBuffer();
		}
		header.append(text);
	}

	public void appendFooter(String text) {
		if (footer == null) {
			footer = new StringBuffer();
		}
		footer.append(text);
	}

	/**
	 * @param receivers A collection of email addresses that are the recipients of
	 *                  this message
	 */
	public void setReceivers(Collection receivers) {
		if (receivers != null) {
			Iterator iter = receivers.iterator();
			while (iter.hasNext()) {
				setReceivers((String) iter.next());
			}
		}
	}

	public String getFrom() {
		String s = null;
		try {
			s = message.getFrom()[0].toString();
		} catch (MessagingException e) {
			log.error("MessagingException " + e);
			// e.printStackTrace();
		}
		return s;
	}

	/**
	 * @param receiver The email address that is the recipient of this message
	 */
	public void setReceivers(String receiver) {
		addRecipient(Message.RecipientType.TO, receiver);
	}

	public String getReceiver() {
		StringBuffer buffer = new StringBuffer();
		try {
			Address[] addresses = message.getAllRecipients();
			if (addresses != null) {
				for (int i = 0; i < addresses.length; i++) {
					buffer.append(addresses[i].toString() + ";");
				}
			}
		} catch (MessagingException e) {
			log.error("MessagingException " + e);
			// e.printStackTrace();
		}
		return buffer.toString();
	}

	public boolean send() {
		boolean ret = false;

		try {
			if (message.getAllRecipients() != null && message.getAllRecipients().length > 0) {
				// Set the body
				if (getBody().length() > 0) {
					MimeBodyPart bodyPart = new MimeBodyPart();
					bodyPart.setText(getBody());
					multipart.addBodyPart(bodyPart);
				}
				// Set the multipart message
				message.setContent(multipart);
				Transport.send(message);
				ret = true;
			} else {
				log.error("No recipients were specified for this message.");
			}
		} catch (MessagingException e) {
			log.error("Error sending message: " + e.getMessage());
			log.error("StackTrace: " + e.getStackTrace());
			// e.printStackTrace();
		}

		return ret;
	}

	/**
	 * @param subject The subject of this message
	 */
	public void setSubject(String subject) {
		if (subject != null) {
			try {
				message.setSubject(subject);
			} catch (Exception e) {
				log.error("Error setting subject. " + e.getMessage());
			}
		}
	}

	public String getSubject() {
		String s = null;
		try {
			s = message.getSubject();
		} catch (MessagingException e) {
			log.error("MessagingException " + e);
			// e.printStackTrace();
		}

		return s;
	}

	/**
	 * @param sender The "from" address for this message
	 */
	public void setSender(String sender) {
		if (sender != null) {
			try {
				message.setFrom(new InternetAddress(sender));
			} catch (Exception e) {
				log.error("Invalid email address: " + sender);
				log.error(e.getMessage());
			}
		}
	}

	/**
	 * 
	 * @param copyTo The email address of the person being copied for this message
	 */
	public void setCopyTo(String copyTo) {
		addRecipient(Message.RecipientType.CC, copyTo);
	}

	/**
	 * 
	 * @param copyTo The collection of email addresses for persons being copied for
	 *               this message
	 */
	public void setCopyTo(Collection copyTo) {
		if (copyTo != null) {
			Iterator iter = copyTo.iterator();
			while (iter.hasNext()) {
				setCopyTo((String) iter.next());
			}
		}
	}

	/**
	 * 
	 * @param copyTo The email address of the person being blind copied for this
	 *               message
	 */
	public void setBlindCopyTo(String copyTo) {
		addRecipient(Message.RecipientType.BCC, copyTo);
	}

	/**
	 * 
	 * @param copyTo The collection of email addresses being blind copied for this
	 *               message
	 */
	public void setBlindCopyTo(Collection copyTo) {
		if (copyTo != null) {
			Iterator iter = copyTo.iterator();
			while (iter.hasNext()) {
				setBlindCopyTo((String) iter.next());
			}
		}
	}

	private void addRecipient(Message.RecipientType type, String recipient) {
		if (recipient != null) {
			try {
				message.addRecipient(type, new InternetAddress(recipient));
			} catch (Exception e) {
				log.error(ESAPIUtil.encode("Invalid email address: " + recipient));
				log.error(e.getMessage());
			}
		}
	}

	/**
	 * Set data from a ByteArrayOutputStream as an attachment to the message.
	 * 
	 * @since 3.5
	 * @author yhp6y2l
	 * @param fileName the file name of the attachment
	 * @param data     the ByteArrayOutputStream object that contains the data
	 * @param mimeType data type, for example "application/pdf"
	 */
	public void setAttachment(final String fileName, final ByteArrayOutputStream data, final String mimeType) {

		MimeBodyPart attachment = new MimeBodyPart();
		try {
			attachment.setDataHandler(new DataHandler(new DataSource() {
				public InputStream getInputStream() throws IOException {
					return new ByteArrayInputStream(data.toByteArray());
				}

				public OutputStream getOutputStream() throws IOException {
					throw new IOException("Read-only data");
				}

				public String getContentType() {
					return mimeType;
				}

				public String getName() {
					return fileName;
				}
			}));

			attachment.setFileName(fileName);
			attachment.setDisposition(javax.mail.Part.ATTACHMENT);
			multipart.addBodyPart(attachment);
		} catch (Exception e) {
			log.error("Error setting attachment: " + fileName + "(" + mimeType + ")");
			log.error(e.getMessage());
		}
	}
}
