package com.unfi.cbk.utilcore;

import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

/**
 * This is a property (java.util.Properties) chopper - it makes a new Properties
 * object out of an existing Properties object.
 * 
 * If you have a series of properties like so:
 * 
 * in.name = Duke in.drink = Coffee out.color = Blue out.company = Microsoft
 * neither.x = 100
 * 
 * If you KEEP (it's a method below) everything that starts with "in." you will
 * have a resulting property that contains
 * 
 * name = Duke drink = Coffee
 * 
 * If you CULL (again, a method) everything that starts with "out." you get
 *
 * in.name = Duke in.drink = Coffee neither.x = 100
 * 
 * @author yhp6y2l
 *
 */
public class PropertiesUtil {

	public static Properties copy(Properties properties) {
		Properties out = new Properties();
		Set keys = properties.keySet();
		Iterator iter = keys.iterator();
		while (iter.hasNext()) {
			String name = (String) iter.next();
			String value = properties.getProperty(name);
			out.setProperty(name, value);
		}
		return out;
	}

	/**
	 * Keep everything that starts with prefix (stripping the prefix)
	 * 
	 * @param properties
	 * @param prefix
	 * @return
	 */
	public static Properties keep(Properties properties, String prefix) {
		// System.out.println("Prefix for keep is " + prefix);
		Properties out = new Properties();
		Set keys = properties.keySet();
		// System.out.println("Number of properties: " + properties.size());
		Iterator iter = keys.iterator();
		while (iter.hasNext()) {
			String name = (String) iter.next();
			// System.out.println("Old short name is " + name);
			if (name.startsWith(prefix)) {
				String pShort = name.substring(prefix.length() + 1);
				// System.out.println("New short name is " + pShort);
				String value = properties.getProperty(name);
				out.setProperty(pShort, value);
			}
		}
		return out;
	}

	/**
	 * Cut out everything that starts with prefix
	 * 
	 * @param properties
	 * @param prefix
	 * @return
	 */
	public static Properties cull(Properties properties, String prefix) {
		Properties out = new Properties();

		Set keys = properties.keySet();
		Iterator iter = keys.iterator();
		while (iter.hasNext()) {
			String p = (String) iter.next();
			if (!p.startsWith(prefix)) {
				out.setProperty(p, properties.getProperty(p));
			}
		}
		return out;
	}
}
