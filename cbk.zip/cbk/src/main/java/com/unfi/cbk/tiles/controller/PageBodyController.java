/*
 * Created on Jun 8, 2005
 * 
 */
package com.unfi.cbk.tiles.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.tiles.Attribute;
import org.apache.tiles.AttributeContext;
import org.apache.tiles.ListAttribute;
import org.apache.tiles.preparer.ViewPreparer;
import org.apache.tiles.request.Request;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.unfi.cbk.util.SpringUtils;

/**
 * @author yhp6y2l
 * 
 */
//@Component
public class PageBodyController implements ViewPreparer {// Controller {

	@Override
	public void execute(Request tilesContext, AttributeContext attributeContext) {

		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
				.getRequest();

		ListAttribute listAttribute = (ListAttribute) attributeContext.getAttribute("insertLists");
		if (listAttribute != null) {

			List<Attribute> l = listAttribute.getValue();
			if (l != null) {
				for (int i = 0; i < l.size(); i++) {
					Attribute a = (Attribute) l.get(i);
					String s = a.toString();
					// System.out.println("Attribute to String ="+s);
					// System.out.println("Attribute renderer = "+a.getRenderer() +" , value
					// ="+a.getValue());

					ListInserter li = (ListInserter) SpringUtils.getBeanFromRequest(request, s);
					li.insertList(request, System.getProperty("db.schema.name"));
				}
			}
		}

	}
}
