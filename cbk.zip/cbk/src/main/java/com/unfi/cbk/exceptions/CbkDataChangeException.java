/*
 * Created on Sep 10, 2009
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.unfi.cbk.exceptions;

/**
 * @author yhp6y2l
 *
 *         To change the template for this generated type comment go to
 *         Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class CbkDataChangeException extends CbkServiceException {

	/**
	 * 
	 */
	public CbkDataChangeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public CbkDataChangeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public CbkDataChangeException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 */
	public CbkDataChangeException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
