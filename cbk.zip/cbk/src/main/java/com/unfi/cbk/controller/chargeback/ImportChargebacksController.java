package com.unfi.cbk.controller.chargeback;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.bo.ChargebackImportBO;
import com.unfi.cbk.controller.PageAccessResolver;
import com.unfi.cbk.delegates.ChargebackSearchDelegate;
import com.unfi.cbk.email.ChargebackMailer;
import com.unfi.cbk.exceptions.DataAccessException;
import com.unfi.cbk.forms.ImportChargebacksForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.Constants;
import com.unfi.cbk.util.DateFunctions;
import com.unfi.cbk.utilcore.ApplicationProperties;

@Controller("importChargebackAction_importChargeback")
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ImportChargebacksController {

	static Logger log = Logger.getLogger(ImportChargebacksController.class);
	@Autowired
	ActionMessages messages;
	@Autowired
	Environment env;
	@Autowired
	ActionMessages errors;
	@Autowired
	private ChargebackSearchDelegate chargebackSearchDelegate;
	@Autowired
	private ChargebackMailer chargebackMailer;

	private static String TEST_EMAIL = ApplicationProperties.getDummyEMail();

	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	/**
	 * 
	 * @param importChargebacksForm
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	//@RequestMapping(value=("/uploadpsd"),headers=("content-type=multipart/*"),method=RequestMethod.POST)
	@RequestMapping(value = "/importChargeback", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=importCbks" })
	public ModelAndView importChargebacks(
			@ModelAttribute("importChargebacksForm") ImportChargebacksForm importChargebacksForm,
			@RequestParam("file") MultipartFile file, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		ModelAndView mav = new ModelAndView();
		boolean exceptionOccurred = false;
		importChargebacksForm.setFormParameterMap(request);

		if (request.getParameter("isformreset") != null) {
			importChargebacksForm.reset();
		}
		String userType = null;
		if (request.getAttribute("userType") != null) {
			userType = (String) request.getAttribute("userType");
		}
		log.debug("***** importChargebacks*****");

		// Get the Reasons list
		List<ChargebackBO> reasons = chargebackSearchDelegate.getReasons();
		importChargebacksForm.setReasons(reasons);

		// Excel File Code
		String[] fileFrags = file.getOriginalFilename().split("\\.");
		String extension = fileFrags[fileFrags.length - 1];
		if (!file.isEmpty() && extension.equalsIgnoreCase("xls")) {

			List<Object> cellListHolder = new ArrayList<>();
			try {
				HSSFWorkbook myWorkBook = new HSSFWorkbook(file.getInputStream());
				HSSFSheet mySheet = myWorkBook.getSheetAt(0);
				// boolean sheet = isSheetNotEmpty(myWorkBook.getSheetAt(0));
				if (isSheetNotEmpty(mySheet)) {
					Iterator<Row> rowIter = mySheet.rowIterator();
					while (rowIter.hasNext()) {
						HSSFRow myRow = (HSSFRow) rowIter.next();
						int numCells = 0;
						Double price = 0.00;
						String strCells = "";
						Date dteColumn;
						if (myRow.getRowNum() != 0 && !isRowEmpty(myRow)) {
							Iterator<Cell> cellIter = myRow.cellIterator();
							List<Object> cellStoreList = new ArrayList<>();
							while (cellIter.hasNext()) {
								HSSFCell myCell = (HSSFCell) cellIter.next();
								if (myCell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC) {
									if (myCell.getColumnIndex() == 3) {
										dteColumn = (Date) myCell.getDateCellValue();
										cellStoreList.add(DateFunctions.formatDate(dteColumn));
									} else if (myCell.getColumnIndex() == 6) {
										price = myCell.getNumericCellValue();
										cellStoreList.add(price);
									} else if (myCell.getColumnIndex() == 7) {
										BigDecimal bd = new BigDecimal(myCell.getNumericCellValue());
										long accNum = bd.longValue();
										cellStoreList.add(accNum);
									} else {
										numCells = (int) myCell.getNumericCellValue();
										cellStoreList.add(numCells);
									}
								} else if (myCell.getCellType() == HSSFCell.CELL_TYPE_STRING) {
									strCells = myCell.getStringCellValue();
									cellStoreList.add(strCells);
								} else if (myCell.getCellType() == HSSFCell.CELL_TYPE_BLANK) {
									cellStoreList.add("");
								}
							}
							cellListHolder.add(cellStoreList);
						}
					}

					List<ChargebackImportBO> chargebackImportBO = new ArrayList<ChargebackImportBO>();

					for (int i = 0; i < cellListHolder.size(); i++) {
						ChargebackImportBO cbkib = new ChargebackImportBO();

						String[] eachRow = cellListHolder.get(i).toString().split(",|]");

						cbkib.setVendorId(eachRow[0].substring(1).trim());
						cbkib.setShortDesc(eachRow[1].trim());
						cbkib.setProductGrp(eachRow[2].trim());
						cbkib.setInvoiceDate(eachRow[3].trim());
						cbkib.setItemDesc(eachRow[4].trim());
						cbkib.setItemQuantity(eachRow[5].trim());
						if (!eachRow[6].trim().isEmpty()) {
							cbkib.setItemPrice(Double.parseDouble(eachRow[6].trim()));
						}
						cbkib.setAccountNumber(eachRow[7].trim());
						if (eachRow.length > 8) {
							cbkib.setItemNumber((eachRow[8].trim()));
						}
						chargebackImportBO.add(cbkib);
					}
					importChargebacksForm.setImportChargebacks(chargebackImportBO);
				} else {

					messages.add("noRecords", "No rows to display", null);
				}

			} catch (Exception e) {
				exceptionOccurred = true;
				messages.add("noRecords", "The given excel data rows/cells are entered Incorrectly, please review your data and submit again with valid a data.  ", null);
				mav.setViewName(ActionUrlMapping.IMPORTCHARGEBACKSACTION.get(Constants.ACTION_ERROR));
				request.setAttribute("actionMessages", messages);
				return mav;
			}
		} else {
			exceptionOccurred = true;
		}

		// forward = mapping.findForward("open");
		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess() && !exceptionOccurred) {
			mav.setViewName(ActionUrlMapping.IMPORTCHARGEBACKSACTION.get(Constants.ACTION_SUCCESS));
			request.setAttribute("actionMessages", messages);
			messages.saveMessages(request);
			request.setAttribute("importChargebacksForm", importChargebacksForm);

			return mav;
		} else if (resolver.hasAccess() && exceptionOccurred) {
			mav.setViewName(ActionUrlMapping.CHARGEBACKCREATEACTIONS.get("other"));
			request.setAttribute("actionMessages", messages);
			request.setAttribute("importChargebacksForm", importChargebacksForm);
			return mav;

		}
		return mav;
	}

	public static boolean isRowEmpty(Row row) {
		for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
			Cell cell = row.getCell(c);
			if (cell != null && cell.getCellType() != Cell.CELL_TYPE_BLANK)
				return false;
		}
		return true;
	}

	boolean isSheetNotEmpty(HSSFSheet sheet) {
		Iterator<Row> rows = sheet.rowIterator();
		while (rows.hasNext()) {
			HSSFRow row = (HSSFRow) rows.next();
			Iterator<Cell> cells = row.cellIterator();
			while (cells.hasNext()) {
				HSSFCell cell = (HSSFCell) cells.next();
				if (!cell.getStringCellValue().isEmpty()) {
					return true;
				}
			}
		}
		return false;
	}

	@RequestMapping(value = "/importChargeback", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=approver" })
	public ModelAndView approver(@ModelAttribute ImportChargebacksForm importChargebacksForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		String locationNumber = null;
		Integer chargebackType = null;
		String chargebackReason = null;
		HttpSession session = request.getSession();
		String smUserId = (String) session.getAttribute("SmUserId");
		List<ChargebackImportBO> readExcelData = importChargebacksForm.getImportChargebacksList();
		if (request.getParameter("locationNumber") != null) {
			locationNumber = request.getParameter("locationNumber");
			importChargebacksForm.setLocationNumber(locationNumber);
		}
		if (request.getParameter("chargebackType") != null) {
			chargebackType = Integer.parseInt(request.getParameter("chargebackType"));
		}
		if (request.getParameter("reasonCode") != null) {
			chargebackReason = request.getParameter("reasonCode");
			importChargebacksForm.setReasonCode(chargebackReason);
		}

		List<ChargebackBO> finalExcelData = new ArrayList<ChargebackBO>();
		generateAndSetNextInvoice(importChargebacksForm, chargebackSearchDelegate);
		String companyCode = null;
		String accNum = null;
		Double distAmount = 0.00;
		
		Integer invoiceNum = Integer.parseInt(importChargebacksForm.getInvoiceNumber());
		String vendorNum = null;
		//Integer lineNum = 1;
		for (int i = 0; i < readExcelData.size(); i++) {
			ChargebackImportBO chargebackImportBO = new ChargebackImportBO();
			chargebackImportBO = (ChargebackImportBO) readExcelData.get(i);
			ChargebackBO cbkBO = new ChargebackBO();
			
			cbkBO.setVendorId(chargebackImportBO.getVendorId());
			if(vendorNum != null  && !vendorNum.equals(chargebackImportBO.getVendorId())) {
				invoiceNum = invoiceNum + 1;
				//lineNum = 1;
			}
			
				vendorNum = chargebackImportBO.getVendorId();
			cbkBO.setInvoiceNumber(invoiceNum.toString());	
			
			cbkBO.setLocationNumber(locationNumber);
			if (!chargebackImportBO.getAccountNumber().isEmpty()) {
				cbkBO.setDistLocNumber(chargebackImportBO.getAccountNumber().substring(0, 5));
				companyCode = chargebackImportBO.getAccountNumber().substring(0, 3);
				if (companyCode.equals("999")) {
					cbkBO.setCompanyCode("999");
				} else {
					cbkBO.setCompanyCode("10");
				}
			}
			cbkBO.setCreatorId(smUserId);
			cbkBO.setTypeId(chargebackType);
			cbkBO.setReasonCode(chargebackReason);
			
			cbkBO.setShortDesc(chargebackImportBO.getShortDesc());
			String prdCode = chargebackImportBO.getProductGrp();
			if(chargebackImportBO.getProductGrp().length() == 1 )
				prdCode = "00" + prdCode;
			else if (chargebackImportBO.getProductGrp().length() == 2 )
				prdCode = "0" + prdCode;
			
			cbkBO.setProductGrp(prdCode);
			cbkBO.setProductCode(prdCode);
			cbkBO.setPrdGrpCode(prdCode);
			
			
			cbkBO.setAttachment(0);
			if(!chargebackImportBO.getInvoiceDate().isEmpty()) {
			cbkBO.setInvoiceDate(DateFunctions.stringToDate(chargebackImportBO.getInvoiceDate()));
			cbkBO.setDueDate(DateFunctions.stringToDate(chargebackImportBO.getInvoiceDate()));
			}
			cbkBO.setItemDesc(chargebackImportBO.getItemDesc());
			if(!chargebackImportBO.getItemQuantity().isEmpty()) {
			cbkBO.setItemQuantity(Integer.parseInt(chargebackImportBO.getItemQuantity()));
			}
			cbkBO.setItemPriceFormat(chargebackImportBO.getItemPrice().toString());
			//cbkBO.setLineNumber(1);
			
			if (chargebackImportBO.getAccountNumber().length() > 6) {
				accNum = chargebackImportBO.getAccountNumber().substring(chargebackImportBO.getAccountNumber().length() - 6);
			} else {
				accNum = chargebackImportBO.getAccountNumber();
			}
			cbkBO.setAccountNumber(accNum);
			distAmount = (Double.parseDouble(chargebackImportBO.getItemQuantity()) * chargebackImportBO.getItemPrice());
			cbkBO.setDistributionAmt(distAmount);
			if(!chargebackImportBO.getItemNumber().isEmpty()) {
			cbkBO.setItemNumber(Integer.parseInt(chargebackImportBO.getItemNumber()));
			}
			finalExcelData.add(cbkBO);
			
			
		}
		importChargebacksForm.setLocationNumber(locationNumber);
		importChargebacksForm.setTypeId(chargebackType);
		importChargebacksForm.setExcelResults(finalExcelData);

		boolean exceptionOccurred = false;
		try {
			log.debug("*****ImportChargebacksController approver *****");

		} catch (Exception e) {
			exceptionOccurred = true;
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);
			if (errors.isEmpty()) {
				errors.add("error", "errors.general");
			}
		}

		if (!exceptionOccurred) {
			mav.setViewName(ActionUrlMapping.IMPORTCHARGEBACKFILESELECTORACTION.get("approver"));
		}

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			// forward = mapping.findForward("failure");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
		}

		request.setAttribute("actionMessages", errors);
		request.setAttribute("importChargebacksForm", importChargebacksForm);
		return mav;
	}

@RequestMapping(value = "/importChargebackSubmit", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=submitImportCbk" })
	public ModelAndView submitImportCbk(
			@ModelAttribute("importChargebacksForm") ImportChargebacksForm importChargebacksForm,
			HttpServletRequest request) throws Exception {
		log.debug("***** importChargebacks *****-importChargebacks.java-- submit()---");
		ModelAndView mav = new ModelAndView();
		boolean exceptionOccurred = false;
		HttpSession session = request.getSession();
        String SmUserId = (String) session.getAttribute("SmUserId");
		List excelDataList = (List) session.getAttribute("excelData");

		try {

			Integer nextInvoiceNumber = null;
			String insertType = null, nextApprover = null;
			//int invoiceCount = excelDataList.size();
			int invoiceCount = 0;
			double distAmount = 0.00;
			
			if (request.getParameter("insertType") != null) {
				insertType = request.getParameter("insertType");
			}
			if (request.getParameter("approver") != null) {
				nextApprover = request.getParameter("approver");
			}
			String invoiceNo =  null;
			Integer line =1;
			for (int i = 0; i < excelDataList.size(); i++) {
				ChargebackBO chargebackBO = new ChargebackBO();
				chargebackBO = (ChargebackBO) excelDataList.get(i);
				if (nextApprover != null) {
				chargebackBO.setApprover(nextApprover);
				}
				importChargebacksForm.setLocationNumber(chargebackBO.getLocationNumber());

				// Insert Data in to Chargeback details
				if( i == 0)
				{
					chargebackSearchDelegate.updateChargeback(chargebackBO, true);
					nextInvoiceNumber = Integer.parseInt(chargebackBO.getInvoiceNumber().substring(2));
					invoiceCount++;
				}
				if(invoiceNo != null  && !(invoiceNo).equals(chargebackBO.getInvoiceNumber()))
				{
					chargebackSearchDelegate.updateChargeback(chargebackBO, true);
					nextInvoiceNumber = Integer.parseInt(chargebackBO.getInvoiceNumber().substring(2));
					invoiceCount++;
					line  = 1;
					
				}
				invoiceNo = chargebackBO.getInvoiceNumber();
				
				chargebackBO.setLineNumber(line);
				chargebackSearchDelegate.createCbkItemSingleRecord(chargebackBO);
				
				chargebackSearchDelegate.createCbkDistributionSingleRecord(chargebackBO);
				distAmount = distAmount + chargebackBO.getDistributionAmt();
				line  = line + 1;
			}
			importChargebacksForm.setDistributionAmt(Double.parseDouble(String.format("%.2f",distAmount)));
			importChargebacksForm.setInvoiceCount(invoiceCount);

			if (nextInvoiceNumber != null) {
				updateGeneratedInvoice(importChargebacksForm, chargebackSearchDelegate,
						String.valueOf((nextInvoiceNumber + 1)), insertType);
				nextInvoiceNumber = null;
			}
			// Get the Email address of the Approver
			
/*			if (!importChargebacksForm.getApprover().equals("") && importChargebacksForm.getApprover() != null) {
				CreateNewUserBO UserBODetails = chargebackSearchDelegate
						.getUserDetails(importChargebacksForm.getApprover());
				// Send email only when user finally confirmed on the approver and notification
				if (UserBODetails.getUseremailId() != null) {
					UserBODetails.setUseremailId(TEST_EMAIL); // need to remove this line when we are at actual environment. 
					chargebackMailer.importChargebacksSendEmail(importChargebacksForm, UserBODetails.getUseremailId(), SmUserId);
				}
			} else {
				CreateNewUserBO UserBODetails = chargebackSearchDelegate.getUserDetails(SmUserId);
				// Send email only when user finally confirmed on the approver and notification
				if (UserBODetails.getUseremailId() != null) {
					UserBODetails.setUseremailId(TEST_EMAIL); //// need to remove this line when we are at actual environment. 
					chargebackMailer.importChargebacksSendEmail(importChargebacksForm, UserBODetails.getUseremailId(), SmUserId);
				}
			} */


		} catch (Exception e) {
			// Determine the error, log it, and put an error message in ActionErrors
			exceptionOccurred = true;
			e.printStackTrace();
			// forward = mapping.findForward("failure");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);

		}
		
		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess() && !exceptionOccurred) {
            mav.setViewName(ActionUrlMapping.CHARGEBACKADMINACTION.get("submitSuccess"));
            request.setAttribute("actionMessages", messages);
            request.setAttribute("importChargebacksForm", importChargebacksForm);
            //importChargebacksForm.reset();
            return mav;
        }
		mav.setViewName(ActionUrlMapping.CHARGEBACKCREATEACTIONS.get("other"));
		request.setAttribute("actionMessages", messages);
		request.setAttribute("importChargebacksForm", importChargebacksForm);
		return mav;

	}

	public void generateAndSetNextInvoice(ImportChargebacksForm importChargebacksForm,
			ChargebackSearchDelegate chargebackSearchDelegate) {
		ChargebackBO invoiceBO = null;
		String twoDigitlocationNumber = importChargebacksForm.getLocationNumber().substring(0, 2);
		try {
			
			invoiceBO = chargebackSearchDelegate
					.getNextInvoceNumberOrBarcode(twoDigitlocationNumber);

			if (invoiceBO != null && invoiceBO.getLocationNumber() != null) {

				// location found and invoice reached to 0000000
				if (Integer.parseInt(invoiceBO.getInvoiceNumber()) == (Constants.MAX_INVOICE)) {
					importChargebacksForm.setNextInvoiceNumber(twoDigitlocationNumber + "0");
					importChargebacksForm.setInvoiceNumber(String.valueOf(Constants.MAX_INVOICE));
					importChargebacksForm.setInsertType("1");
				} else // location found and invoice not reached to 0000000
				{
					Integer nextInvoice = Integer.parseInt(invoiceBO.getInvoiceNumber());
					importChargebacksForm.setNextInvoiceNumber(String.valueOf(nextInvoice + 1));
					importChargebacksForm.setInvoiceNumber(twoDigitlocationNumber + invoiceBO.getInvoiceNumber());
					importChargebacksForm.setInsertType("2");
				}

			} else // location not available
			{
				importChargebacksForm.setInvoiceNumber(twoDigitlocationNumber + "1");
				importChargebacksForm.setNextInvoiceNumber(twoDigitlocationNumber + "2");
				importChargebacksForm.setInsertType("3");
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception in execute:" + e);

		}
	}

	@RequestMapping(value = "/validateVendorId", method = { RequestMethod.GET,
			RequestMethod.POST }, consumes = "application/json", params = { "action=submitVendorId" })
	public @ResponseBody ResponseEntity<?> validVendorId(@RequestParam("vendorId") String vendorId) {

		ArrayList<String> invalidVendorIds = new ArrayList<String>();
		log.debug("vendor ids :" + vendorId);
		// vendor ids :324905,325266,5125422,139105
		String[] vendorIds = vendorId.split(",");

		for (String vId : vendorIds) {
			if (vId != null) {
				try {
					String vendorStatus = chargebackSearchDelegate.getValidVendorNumber(vId);
					if (vendorStatus == null) {

						invalidVendorIds.add(vId);
					}

				} catch (DataAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return ResponseEntity.ok(invalidVendorIds);
	}

	@RequestMapping(value = "/validateAccount", method = { RequestMethod.GET,
			RequestMethod.POST }, consumes = "application/json", params = { "action=ValidAccount" })
	public @ResponseBody ResponseEntity<?> validateAccountNumber(@RequestParam("account") String accountNumber) {
		String location = null;
		String accNum = null;
		String prod_code = null;
		String acct_unit = null;
		ArrayList<String> invalidAccounts = new ArrayList<String>();
		String[] accounts = accountNumber.split(",");
		
		for (String account : accounts) {
		String companyCode = account.substring(0, 3);
		if (companyCode.equals("999")) {
			companyCode = "999";
		} else {
			companyCode = "10";
		}
		if (account.length() > 6) {
			accNum = account.substring(account.length() - 6);
		} else {
			accNum = account;
		}
		location = account.substring(0, 5);
		prod_code = account.substring(5, 8);
		acct_unit = 0 + location + prod_code;
		if (account != null) {
			// VALIDATE FROM DATABASE
			try {
				String vendorStatus = chargebackSearchDelegate.getValidAccountNumber(companyCode, accNum, acct_unit);
				if (vendorStatus == null) {
					invalidAccounts.add(account);
				}

			} catch (DataAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		}
		return ResponseEntity.ok(invalidAccounts);
	}

	public void updateGeneratedInvoice(ImportChargebacksForm importChargebacksForm,
			ChargebackSearchDelegate chargebackSearchDelegate, String nextInvoice, String insertType) {

		String twoDigitlocationNumber = importChargebacksForm.getLocationNumber().substring(0, 2);
		
		try {
			if (insertType.equals("1") || insertType.equals("2")) {
				ChargebackBO newInvoiceBO = new ChargebackBO();
				newInvoiceBO.setInvoiceNumber(nextInvoice);
				newInvoiceBO.setLocationNumber(twoDigitlocationNumber);
				chargebackSearchDelegate.updateInvoice(newInvoiceBO);

			} else if (insertType.equals("3")) {
				ChargebackBO newInvoiceBO = new ChargebackBO();
				newInvoiceBO.setInvoiceNumber(nextInvoice);
				newInvoiceBO.setLocationNumber(twoDigitlocationNumber);
				chargebackSearchDelegate.insertInvoice(newInvoiceBO);
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception in execute:" + e);

		}
	}
}
