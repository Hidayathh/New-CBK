package com.unfi.cbk.dao.ibImpl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.dao.ChargebackExportDao;
import com.unfi.cbk.exceptions.DataAccessException;

/**
 * The ChargebackExportDaoImpl class handles the call to the database to get the
 * results of the chargebacks search based on the form values.
 *
 * @author vpil001
 * @since 1.0
 */

public class ChargebackExportDaoImpl extends SqlMapClientDaoSupport implements ChargebackExportDao {

	private static Logger log = Logger.getLogger(ChargebackExportDaoImpl.class);
	protected static Date BAD_DATE = null;

	public ChargebackExportDaoImpl(SqlMapClientTemplate sqlMapTemplate) {
		this.setSqlMapClientTemplate(sqlMapTemplate);
	}

	/* For AuditDetails */

	public ResultList getTypeAmount(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		ResultList rL = new ResultList();

		try {

			System.out.println("-----ExportDaoImpl.java-------GetTypeAmount()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackExport.getTypeAmount", map));
			System.out.println("------------ExportDaoImpl.java--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getTypeAmount() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}
		return rL;

	}

	@Override
	public ResultList previewExportResults() throws DataAccessException {
		// TODO Auto-generated method stub
		ResultList rL = new ResultList();

		try {

			System.out.println("------ExportDaoImpl.java-------previewExportResults()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackExport.previewExportResults"));
			System.out.println("------------ExportDaoImpl.java--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in previewExportResults() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}
		return rL;

	}

	@Override
	public ResultList agedChargebackReportSearch(Map map) throws DataAccessException {
		ResultList rL = new ResultList();

		try {

			System.out.println("------ExportDaoImpl.java-------agedChargebackReportSearch()------");
			if (("true").equals(map.get("showAll"))) {
				rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackExport.agedChargebackReportShowAll",
						map));

			} else {
				rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackExport.agedChargebackReport", map));
			}

			System.out.println("------------ExportDaoImpl.java--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			} else if (map.get("showAll") != null && ((String) map.get("showAll")).equals("true")) {
				rL.setTotalCount(new Integer(rL.getList().size()));
			} else {
				rL.setTotalCount((Integer) getSqlMapClientTemplate()
						.queryForObject("ChargebackExport.agedChargebackReportCount", map));
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in agedChargebackReportSearch() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}
		System.out.println(rL.getList().get(0));
		System.out.println(rL);
		return rL;

	}

	@Override
	public ResultList updateDuedate() throws DataAccessException {
		ResultList rL = new ResultList();

		try {

			System.out.println("------ExportDaoImpl.java-------updateDuedate()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackExport.updateDuedate"));
			System.out.println("------------ExportDaoImpl.java--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getAuditResults() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}
		System.out.println(rL.getList().get(0));
		System.out.println(rL);
		return rL;

	}

	/*
	 * 
	 */
	public void updateChargebackDueDate(ChargebackBO chargeBack) throws DataAccessException {
		try {
			System.out.println("-----in DAOIMPL---updateChargebackDueDate()---");
			getSqlMapClientTemplate().update("ChargebackExport.updateChargebackDueDate", chargeBack);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	public void insertExpType() throws DataAccessException {

		try {
			getSqlMapClientTemplate().insert("ChargebackExport.insertExpType");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	public void insertExpReasons() throws DataAccessException {

		try {
			getSqlMapClientTemplate().insert("ChargebackExport.insertExpReasons");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	public void insertExpAvailableExports() throws DataAccessException {

		try {
			getSqlMapClientTemplate().insert("ChargebackExport.insertExpAvailableExports");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	public void insertExpChargeback() throws DataAccessException {

		try {
			getSqlMapClientTemplate().insert("ChargebackExport.insertExpChargeback");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	public void insertExpDistribution() throws DataAccessException {

		try {
			getSqlMapClientTemplate().insert("ChargebackExport.insertExpDistribution");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	public void insertExpItem() throws DataAccessException {

		try {
			getSqlMapClientTemplate().insert("ChargebackExport.insertExpItem");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	public void insertExpApprovals() throws DataAccessException {

		try {
			getSqlMapClientTemplate().insert("ChargebackExport.insertExpApprovals");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	public void insertExpDistRecords() throws DataAccessException {

		try {
			getSqlMapClientTemplate().insert("ChargebackExport.insertExpDistRecords");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	public void insertExpDetail() throws DataAccessException {

		try {
			getSqlMapClientTemplate().insert("ChargebackExport.insertExpDetail");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	public void insertExpNotExported() throws DataAccessException {

		try {
			getSqlMapClientTemplate().insert("ChargebackExport.insertExpNotExported");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}
	
	public void insertCvdDistExport() throws DataAccessException {

		try {
			getSqlMapClientTemplate().insert("ChargebackExport.insertCvdDistExport");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}


	public void updateChargebackExportorNot(String exportedStatus) throws DataAccessException {
		try {
			getSqlMapClientTemplate().update("ChargebackSearch.updateChargeback", exportedStatus);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	public void deleteExpType() throws DataAccessException {

		try {
			getSqlMapClientTemplate().delete("ChargebackExport.deleteExpType");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	public void deleteExpReasons() throws DataAccessException {

		try {
			getSqlMapClientTemplate().delete("ChargebackExport.deleteExpReasons");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	public void deleteExpAvailableExports() throws DataAccessException {

		try {
			getSqlMapClientTemplate().delete("ChargebackExport.deleteExpAvailableExports");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	public void deleteExpChargeback() throws DataAccessException {

		try {
			getSqlMapClientTemplate().delete("ChargebackExport.deleteExpChargeback");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	public void deleteExpDistribution() throws DataAccessException {

		try {
			getSqlMapClientTemplate().delete("ChargebackExport.deleteExpDistribution");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	public void deleteExpItem() throws DataAccessException {

		try {
			getSqlMapClientTemplate().delete("ChargebackExport.deleteExpItem");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	public void deleteExpApprovals() throws DataAccessException {

		try {
			getSqlMapClientTemplate().delete("ChargebackExport.deleteExpApprovals");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	public void deleteExpDistRecords() throws DataAccessException {

		try {
			getSqlMapClientTemplate().delete("ChargebackExport.deleteExpDistRecords");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	public void deleteExpDetail() throws DataAccessException {

		try {
			getSqlMapClientTemplate().delete("ChargebackExport.deleteExpDetail");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	public void deleteExpNotExported() throws DataAccessException {

		try {
			getSqlMapClientTemplate().delete("ChargebackExport.deleteExpNotExported");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}
	
	public void deleteExpCviInvExport() throws DataAccessException {

		try {
			getSqlMapClientTemplate().delete("ChargebackExport.deleteExpCviInvExport");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}
	
	public void deleteExpFundsRecords() throws DataAccessException{
		try {
			getSqlMapClientTemplate().delete("ChargebackExport.deleteExpFundsRecords");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}
	
	@Override
	public List getExportId(String date) throws DataAccessException {
		// TODO Auto-generated method stub
		List<String> l = null;
		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("date", date);
			l = (List) getSqlMapClientTemplate().queryForList("ChargebackExport.getExportId", map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		
		
		return l;
	}



}