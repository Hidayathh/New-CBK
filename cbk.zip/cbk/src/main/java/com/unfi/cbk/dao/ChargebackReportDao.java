package com.unfi.cbk.dao;

import java.util.List;
import java.util.Map;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.exceptions.DataAccessException;

/**
 * The ChargebackSearchDao interface creates the bridge between the caller and
 * the actual work in retrieving the data.
 *
 * @author yhp6y2l
 * @since 1.0
 */

public interface ChargebackReportDao {

	 public List getReasonCode() throws DataAccessException; 
	 
	 public ResultList getChargebackReportList(Map searchParametersFrom) throws DataAccessException;

}
