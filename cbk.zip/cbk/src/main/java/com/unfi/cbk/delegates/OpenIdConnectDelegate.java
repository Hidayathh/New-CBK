package com.unfi.cbk.delegates;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.unfi.cbk.bo.OAuthResponseBO;
import com.unfi.cbk.bo.OAuthValidateBO;

@Configuration
public class OpenIdConnectDelegate {

	private static Logger log = Logger.getLogger(OpenIdConnectDelegate.class);

	@Autowired
	RestTemplate restTemplate;

	@Bean
	@ConfigurationProperties(prefix = "myunfi.openid")
	 public Map<String, String> openidProperty() {
	    return new HashMap<>();
	  }
	@Bean
	@ConfigurationProperties(prefix = "ldapconfig.map")
	 public Map<String, String> ldapProperties() {
	    return new HashMap<>();
	  }



	/**
	 * 
	 * @return redirectUrl() holds Site Minder connectivity login uri/page for the
	 *         user authentication and authorization.
	 */
	public String cbkHomeUrl() {

		return openidProperty().get("cbkHomeUri");
	}

	public String redirectUrl() {
		
		return openidProperty().get("issuerUri") + "response_type="
				+ openidProperty().get("responseType") + "&scope=" + openidProperty().get("scope")
				+ "&client_id=" + openidProperty().get("clientId") + "&redirect_uri="
				+ openidProperty().get("redirectUri") + ""; 

	}

	/**
	 * 
	 * @param code
	 * @return fetchAccessToken() fetch access_token and ID_Token using CODE
	 *         parameter for the user validation.
	 * 
	 */
	public ResponseEntity<OAuthResponseBO> fetchAccessToken(String code) {
		ResponseEntity<OAuthResponseBO> responseEntity = null;
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED.toString());
			MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
			map.add("grant_type", openidProperty().get("grantType"));
			map.add("code", code);
			map.add("client_id", openidProperty().get("clientId"));
			map.add("client_secret", openidProperty().get("clientSecret"));

			HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<>(map, headers);
			responseEntity = restTemplate.exchange(openidProperty().get("accessTokenUri"), HttpMethod.POST,
					requestEntity, OAuthResponseBO.class);
		} catch (Exception e) {
			log.error("Error at Access Tokean ResponseEntity :" + e.getMessage());
			throw e;
		}
		return responseEntity;
	}

	/**
	 * 
	 * @param token
	 * @return validateAccessToken() validates user access token to grant
	 *         application access
	 */
	public ResponseEntity<OAuthValidateBO> validateAccessToken(String token) {
		ResponseEntity<OAuthValidateBO> responseEntity = null;
		try {
			HttpHeaders headers = new HttpHeaders();

			headers.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED.toString());
			MultiValueMap<String, String> map = new LinkedMultiValueMap<>();

			map.add("token", token);
			map.add("token_type_hint", openidProperty().get("tokenTypeHint"));
			map.add("client_id", openidProperty().get("clientId"));
			map.add("client_secret", openidProperty().get("clientSecret"));

			HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<>(map, headers);
			responseEntity = restTemplate.exchange(openidProperty().get("validationUri"), HttpMethod.POST,
					requestEntity, OAuthValidateBO.class);
		} catch (Exception e) {
			log.error("Error at Access Token ResponseEntity :" + e.getMessage());
			throw e;
		}
		return responseEntity;
	}

}
