package com.unfi.cbk.forms;

import java.util.List;

/**
 * The RequestSourceForm class is the struts action form used for the request
 * source maintenance section. It extends the ValidatorActionForm class in order
 * to utilize built-in struts validation and implements Pageable in order to
 * work with the VCR buttons.
 *
 * @author yhp6y2l
 * @version 1.0
 */
public class UserIDSelectorForm {

	private Integer results = null;

	private List searchResults = null;
	private String selectedResult = null;
	// private String single = "";
	private String userID = null;
	private String userName = null;

	/**
	 * @return
	 */
	public Integer getResults() {
		return results;
	}

	/**
	 * @return
	 */
	public List getSearchResults() {
		return searchResults;
	}

	/**
	 * @return
	 */
	public String getSelectedResult() {
		return selectedResult;
	}

	/**
	 * @return
	 */

	/**
	 * @param i
	 */
	public void setResults(Integer i) {
		results = i;
	}

	/**
	 * @param list
	 */
	public void setSearchResults(List list) {
		searchResults = list;
	}

	/**
	 * @param string
	 */
	public void setSelectedResult(String string) {
		selectedResult = string;
	}

	/**
	 * @param string
	 */

	/**
	 * @return
	 */

	public String getUserName() {
		return userName;
	}

	/**
	 * @return
	 */

	public String getUserID() {
		return userID;
	}

	/**
	 * @param string
	 */
	public void setUserName(String string) {
		userName = string;
	}

	/**
	 * @param string
	 */

	public void setUserID(String string) {
		userID = string;
	}

}