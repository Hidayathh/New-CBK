package com.unfi.cbk.bo;

import java.util.Date;

import com.unfi.cbk.util.DateFunctions;

public class BalanceAccrualBO {

	private String invoiceNumber;
	private Date invoiceDate;
	private String vendorNumber;

	private String companyCode;
	private String locationNumber;
	private String rName;
	private String creatorId;
	private String typeDescr;
	private String ledgerType;
	private String location;
	private String accUnit;
	private String dist;
	private String amount;

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	

	public Date getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getVendorNumber() {
		return vendorNumber;
	}

	public void setVendorNumber(String vendorNumber) {
		this.vendorNumber = vendorNumber;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getLocationNumber() {
		return locationNumber;
	}

	public void setLocationNumber(String locationNumber) {
		this.locationNumber = locationNumber;
	}

	public String getrName() {
		return rName;
	}

	public void setrName(String rName) {
		this.rName = rName;
	}

	public String getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public String getTypeDescr() {
		return typeDescr;
	}

	public void setTypeDescr(String typeDescr) {
		this.typeDescr = typeDescr;
	}

	public String getLedgerType() {
		return ledgerType;
	}

	public void setLedgerType(String ledgerType) {
		this.ledgerType = ledgerType;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getAccUnit() {
		return accUnit;
	}

	public void setAccUnit(String accUnit) {
		this.accUnit = accUnit;
	}

	public String getDist() {
		return dist;
	}

	public void setDist(String dist) {
		this.dist = dist;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}
	
	public String getInvoiceDateString() {
		String s = null;
		if (invoiceDate != null) {
			s = DateFunctions.formatDate(invoiceDate);
		}
		return s;
	}

	public void setInvoiceDateString(String s) {
		if (s != null && s.trim().length() > 0) {
			invoiceDate = DateFunctions.stringToDate(s);
		}
	}

}
