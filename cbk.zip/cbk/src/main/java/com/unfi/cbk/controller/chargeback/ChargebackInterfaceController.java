package com.unfi.cbk.controller.chargeback;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.bo.ChargebackInterfaceBO;
import com.unfi.cbk.delegates.ChargebackManagerDelegate;
import com.unfi.cbk.delegates.ChargebackSearchDelegate;
import com.unfi.cbk.exceptions.DataAccessException;
import com.unfi.cbk.forms.ChargebackInterfaceForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.Constants;
import com.unfi.cbk.util.DateFunctions;

@Controller("chargebackInterfaceController_chargeback")
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ChargebackInterfaceController {
	static Logger log = Logger.getLogger(ChargebackInterfaceController.class);

	@Autowired
	ActionMessages errors;

	@Autowired
	ActionMessages messages;
	@Autowired
	Environment env;
	@Autowired
	private ChargebackSearchDelegate chargebackSearchDelegate;

	@Autowired
	private ChargebackManagerDelegate chargebackManagerDelegate;

	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	@RequestMapping(value = "/chargebackInterface", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=confirm" })
	public ModelAndView Confirm(
			@ModelAttribute("chargebackInterfaceForm") ChargebackInterfaceForm chargebackInterfaceForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}
		mav.setViewName(ActionUrlMapping.CHARGEBACKINTERFACEACTION.get("confirm"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackInterfaceForm", chargebackInterfaceForm);
		return mav;
	}

//	@RequestMapping(value = "/chargebackInterface", method = { RequestMethod.GET, RequestMethod.POST }, params = {
//			"action=read" })
//	public ModelAndView Read(@ModelAttribute("chargebackInterfaceForm") ChargebackInterfaceForm chargebackInterfaceForm,
//			HttpServletRequest request,HttpServletResponse response) throws Exception {
//		ModelAndView mav = new ModelAndView();
//		chargebackInterfaceForm.setFormParameterMap(request);
//		
//		
//		Map searchParametersFromForm = chargebackInterfaceForm.getMap();
//		boolean vendorValidate = false;
//		boolean accountValidate = false;
//		boolean inBalValidate=false;
//
//		String substring = null;
//		String accNum = null;
//		String account = null;
//		String companyCode = null;
//		String location = null;
//		String prod_code = null;
//		String acct_unit = null;
//		String invoiceNum = null;
//		String referenceNum = null;
//		String vendorId = null;
//		Double itemTotalAmt=0.00;
//		Double distAmt = 0.00;
//		List list = new ArrayList();
//
//		try {
//			// File file = new File("C:\\CbkInterface\\Bakery3.txt");
//			File file = new File("C:\\CbkInterface\\Bakery2.txt");
//
//			if (file != null) {
//				list = Files.readAllLines(file.toPath(), Charset.defaultCharset());
//				System.out.println("list of Records in file:" + list);
//
//				ChargebackBO cbkBO = new ChargebackBO();
//
//				ChargebackInterfaceBO intBO = new ChargebackInterfaceBO();
//				for (int i = 0; i < list.size(); i++) {
//
//					String[] eachRow = list.get(i).toString().split(",");
//					if (i == 0) {
//						substring = eachRow[0];
//						System.out.println("===Length of 1st row of the File---: " + substring.length());
//						System.out.println(" Table Header--@@:" + substring);
//						intBO.setRecordType(eachRow[0].substring(0, 1).trim());
//
//						referenceNum = eachRow[0].substring(2, 21).trim();
//						cbkBO.setReferenceNumber(referenceNum);
//
//						// Create Invoices
//						// 99332954FI,99341622FI
//						if (referenceNum != null) {
//							invoiceNum = referenceNum + "I";
//							cbkBO.setInvoiceNumber(invoiceNum);
//						}
//						cbkBO.setLocationNumber(eachRow[0].substring(21, 26).trim());
//						cbkBO.setDueDate(DateFunctions.stringToDate(eachRow[0].substring(26, 34).trim()));
//						cbkBO.setInvoiceDate(DateFunctions.stringToDate(eachRow[0].substring(26, 34).trim()));
//						cbkBO.setApprovalDate(DateFunctions.stringToDate(eachRow[0].substring(26, 34).trim()));
//						cbkBO.setTypeId(Integer.parseInt(eachRow[0].substring(43, 44).trim()));
//						cbkBO.setCreatorId(eachRow[0].substring(45, 50).trim());
//						cbkBO.setShortDesc(eachRow[0].substring(50, 154).trim());
//						cbkBO.setReasonCode(eachRow[0].substring(154, 170).trim());
//						vendorId = eachRow[0].substring(34, 43).trim();
//						System.out.println("@@@@@VendorNumber---:" + vendorId);
//
//						System.out.println("IntBO Record Type--:" + intBO.getRecordType());
//						System.out.println("Invoice Number--:" + cbkBO.getInvoiceNumber());
//						System.out.println("Reference--:" + cbkBO.getReferenceNumber());
//						System.out.println(" ProcLevel--:" + cbkBO.getLocationNumber());
//						System.out.println(" DueDate:--:" + cbkBO.getDueDate());
//						System.out.println(" InvoiceDate:--:" + cbkBO.getInvoiceDate());
//						System.out.println(" ApprovalDate:--:" + cbkBO.getApprovalDate());
//						System.out.println(" CreatorId--:" + cbkBO.getCreatorId());
//						System.out.println("--ShortDescription--:" + cbkBO.getShortDesc().length());
//						System.out.println("-- Cbk Reason--:" + cbkBO.getReasonCode());
//						System.out.println("-- ChargebackType--:" + cbkBO.getTypeId());
//
//						// vendorId="807263";
//						if (vendorId != null) {
//							// VALIDATE FROM DATABASE
//							try {
//								String vendorStatus = chargebackSearchDelegate.getValidVendorNumber(vendorId);
//								System.out.println("vendor Status--:" + vendorStatus);
//								if (vendorStatus != null) {
//									vendorValidate = true;
//									// intBO.setVendorNumber(vendorId);
//									cbkBO.setVendorId(vendorId);
//								} else {
//									mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
//									request.setAttribute("actionMessages", errors);
//									request.setAttribute("chargebackInterfaceForm", chargebackInterfaceForm);
//									return mav;
//								}
//
//							} catch (DataAccessException e) {
//								e.printStackTrace();
//								log.error(e);
//							}
//							System.out.println("Vendor validate:--" + vendorValidate);
//							System.out.println(" VendorNumber--:" + cbkBO.getVendorId());
//						}
//
//						System.out.println();
//					} else if (i == 1) {
//						substring = eachRow[0];
//						System.out.println("====Length of 2nd row of the File---: " + substring.length());
//						System.out.println(" Table Item--@@:" + substring);
//
//						// cbkBO.setReferenceNumber(eachRow[0].substring(2, 21).trim());
//						cbkBO.setLineNumber(Integer.parseInt(eachRow[0].substring(21, 23).trim()));
//						cbkBO.setItemNumber(Integer.parseInt(eachRow[0].substring(23, 30).trim()));
//						cbkBO.setItemPack(Integer.parseInt(eachRow[0].substring(30, 33).trim()));
//						cbkBO.setItemSize(eachRow[0].substring(33, 40).trim());
//						cbkBO.setItemDesc(eachRow[0].substring(40, 71).trim());
//						cbkBO.setItemUpc(eachRow[0].substring(71, 83).trim());
//						cbkBO.setItemQuantity(Integer.parseInt(eachRow[0].substring(90, 94).trim()));
//						cbkBO.setItemPrice(Double.parseDouble(eachRow[0].substring(94, 102).trim()));
//						cbkBO.setProductCode(eachRow[0].substring(102, 105).trim());
//						// cbkBO.setRegion(eachRow[0].substring(105, 108).trim());
//						cbkBO.setDcNumber(eachRow[0].substring(105, 108).trim());
//						
//						System.out.println("IntBO Record Type--:" + intBO.getRecordType());
//						System.out.println("ReferenceNumber--:" + cbkBO.getReferenceNumber());
//						System.out.println("--Item Line--:" + cbkBO.getLineNumber());
//						System.out.println("--Item Number-- :" + cbkBO.getItemNumber());
//						System.out.println("--Item Pack-- :" + cbkBO.getItemPack());
//						System.out.println("--Item Size-- " + cbkBO.getItemSize());
//						System.out.println("--Item Description-- :" + cbkBO.getItemDesc());
//						System.out.println("--Quantity-- " + cbkBO.getItemQuantity());
//						System.out.println("--ItemPrice--:$" + cbkBO.getItemPrice());
//						System.out.println("--Product Group Code-- :" + cbkBO.getProductCode());
//						System.out.println("--DC Number--- :" + cbkBO.getDcNumber());
//						System.out.println("--ItemUpc--- :" + cbkBO.getItemUpc());
//
//						System.out.println();
//					} else if (i == 2) {
//						substring = eachRow[0];
//						System.out.println("====Length of 3rd row of the File---: " + substring.length());
//						System.out.println(" Table Distrubution--@@:" + substring);
//						intBO.setRecordType(eachRow[0].substring(0, 1).trim());
//
//						// cbkBO.setReferenceNumber(eachRow[0].substring(2, 21).trim());
//						cbkBO.setCompanyCode(eachRow[0].substring(21, 25).trim());
//						cbkBO.setLocationNumber(eachRow[0].substring(25, 30).trim());
//						cbkBO.setDistLocNumber(eachRow[0].substring(25, 30).trim());
//						cbkBO.setProductGrpCode(eachRow[0].substring(30, 33).trim());
//						// cbkBO.setAccountNumber(eachRow[0].substring(33, 39).trim());
//						
//						//AMOUNT VALIDATE
//						itemTotalAmt =cbkBO.getItemPrice()* cbkBO.getItemQuantity();
//						distAmt=distAmt+Double.parseDouble(eachRow[0].substring(39, 49).trim());
//						System.out.println("Total Amount by price and quantity------:"+itemTotalAmt);
//						System.out.println("Total Amount by DistAmount------:"+distAmt);
//						if (distAmt.equals(itemTotalAmt)) {
//							inBalValidate=true;
//							System.out.println("Mutliplication of itemAmount == DistAmount:"+inBalValidate);
//							cbkBO.setDistributionAmt(distAmt);
//						}
//
//						accNum = eachRow[0].substring(33, 39).trim();
//						companyCode = eachRow[0].substring(21, 25).trim();
//						location = eachRow[0].substring(25, 30).trim();
//
////						if (companyCode.equals("999")) {
////							companyCode = "999";
////						} else {
////							companyCode = "10";
////						}
////						if (account.length() > 6) {
////							accNum = account.substring(account.length() - 6);
////						} else {
////							accNum = account;
////						}
//
//						location = eachRow[0].substring(25, 30).trim();
//						prod_code = eachRow[0].substring(30, 33).trim();
//						acct_unit = 0 + location + prod_code;
//						System.out.println("---->String Location--:" + location);
//						System.out.println("---->String prod_code--:" + prod_code);
//						System.out.println("---->String acct_unit--:" + acct_unit);
//						if (accNum != null) {
//							// VALIDATE FROM DATABASE
//							try {
//								String accountStatus = chargebackSearchDelegate.getValidAccountNumber(companyCode,
//										accNum, acct_unit);
//								System.out.println("Account Status---:@@@@" + accountStatus);
//								if (accountStatus != null) {
//									accountValidate = true;
//									cbkBO.setAccountNumber(eachRow[0].substring(33, 39).trim());
//								} else {
//									System.out.println("@@@@@@@DistroStatus validation else Block--- ");
//									mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
//									request.setAttribute("actionMessages", errors);
//									request.setAttribute("chargebackInterfaceForm", chargebackInterfaceForm);
//									return mav;
//								}
//
//							} catch (DataAccessException e) {
//								e.printStackTrace();
//							}
//							System.out.println("Account Validate Status---:@@@@" + accountValidate);
//						}
//
//						System.out.println("IntBO Record Type--:" + intBO.getRecordType());
//						System.out.println("Reference--:" + cbkBO.getReferenceNumber());
//						System.out.println("Company Code :" + cbkBO.getCompanyCode());
//						System.out.println("---Location Number--:" + cbkBO.getLocationNumber());
//						System.out.println("---Dist_Location Number--:" + cbkBO.getLocationNumber());
//						System.out.println("---State ProductGroup Code--:" + cbkBO.getProductGrpCode());
//						System.out.println("---Account Number---:" + cbkBO.getAccountNumber());
//						System.out.println("---Amount---:$" + cbkBO.getDistributionAmt());
//
//						System.out.println();
//					} else if (i == 3) {
//						substring = eachRow[0];
//						System.out.println("===Length of 4th row of the File---: " + substring.length());
//						System.out.println(" Table Approver--@@:" + substring);
//
//						cbkBO.setStepNumber(eachRow[0].substring(21, 23).trim());
//						cbkBO.setApproverId(eachRow[0].substring(23, 30).trim());
//
//						System.out.println("IntBO Record Type--:" + intBO.getRecordType());
//						System.out.println("Reference:" + cbkBO.getReferenceNumber());
//						System.out.println("Step Number--:" + cbkBO.getStepNumber());
//						System.out.println("--Approver Id--:" + cbkBO.getApproverId());
//					}
//
//				}
//				
//				//ServletOutputStream out = null;
//				if (vendorValidate ==true&& accountValidate ==true &&inBalValidate==true) {
//					System.out.println("lets import the Funds management Records--------");
////				chargebackSearchDelegate.createCbkFundsRecord(cbkBO);
////				chargebackSearchDelegate.createCbkItemFundsRecord(cbkBO);
////				chargebackSearchDelegate.createCbkDistributionFundsRecord(cbkBO);
////				chargebackSearchDelegate.createCbkApprFundsRecord(cbkBO);
//					System.out.println(cbkBO.getInvoiceNumber());
//					
//					// The response headers must be set in the following order, or else IE
//					// won't handle things properly.
//					// response.setHeader("Content-length", ""+file.getFile().length());
////					response.setHeader("Content-disposition", "attachment; filename=FundsImportFile.csv");
////					response.setContentType("text/comma-separated-values");
////					response.setHeader("Pragma", "public");
////					response.setHeader("Cache-control", "must-revalidate");
////					out = response.getOutputStream();
////					out.println("VendorValid, AccountValid, BalanceValid ");
////					
////					out.print(
////							"=\"" + Boolean.toString(vendorValidate) + "\"");
////					out.print(",");
////					out.print(Boolean.toString(accountValidate));
////					out.print(",");
////					out.print(Boolean.toString(inBalValidate));
//					
//					mav.setViewName(ActionUrlMapping.CHARGEBACKINTERFACEACTION.get("success"));
//					request.setAttribute("actionMessages", errors);
//					// request.setAttribute("chargebackInterfaceForm", chargebackInterfaceForm);
//					return mav;
//				}
//			}
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//			log.error("Error in Interface Controller:" + e);
//			throw new DataAccessException(e);
//		}
//
//		log.debug("*****CHARGEBACK INTERFACE *****Read()");
//		mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
//		request.setAttribute("actionMessages", errors);
//		request.setAttribute("chargebackInterfaceForm", chargebackInterfaceForm);
//		return mav;
//
//	}

	@RequestMapping(value = "/chargebackInterface", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=read" })
	public ModelAndView Read(@ModelAttribute("chargebackInterfaceForm") ChargebackInterfaceForm chargebackInterfaceForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackInterfaceForm.setFormParameterMap(request);
		Map searchParametersFromForm = chargebackInterfaceForm.getMap();
		boolean vendorValidate = false;
		boolean accountValidate = false;
		boolean inBalValidate=false;


		String substring = null;
		String accNum = null;
		String companyCode = null;
		String location = null;
		String prod_code = null;
		String acct_unit = null;
		String invoiceNum = null;
		String referenceNum = null;
		String vendorId = null;
		Double itemTotalAmt=0.00;
		Double distAmt = 0.00;
		List list = new ArrayList();

		try {
			File folder = new File("C:\\CbkInterface");

			File[] listOfFiles = folder.listFiles();
			for (int i = 0; i < listOfFiles.length; i++) {
				if (listOfFiles[i]!= null) {
					list = Files.readAllLines(listOfFiles[i].toPath(), Charset.defaultCharset());
					System.out.println("----------------========= Files in Folder----:" + i);
					ChargebackBO cbkBO = new ChargebackBO();

					ChargebackInterfaceBO intBO = new ChargebackInterfaceBO();

					for (int j = 0; j < list.size(); j++) {

						String[] eachRow = list.get(j).toString().split(",");
						if (j == 0) {
							substring = eachRow[0];
							System.out.println("===Length of 1st row of the File---: " + substring.length());
							System.out.println(" Table Header--@@:" + substring);
							intBO.setRecordType(eachRow[0].substring(0, 1).trim());

							referenceNum = eachRow[0].substring(2, 21).trim();
							cbkBO.setReferenceNumber(referenceNum);

							// Create Invoices
							// 99332954FI,99341622FI
							if (referenceNum != null) {
								invoiceNum = referenceNum + "I";
								cbkBO.setInvoiceNumber(invoiceNum);
							}
							cbkBO.setLocationNumber(eachRow[0].substring(21, 26).trim());
							cbkBO.setDueDate(DateFunctions.stringToDate(eachRow[0].substring(26, 34).trim()));
							cbkBO.setInvoiceDate(DateFunctions.stringToDate(eachRow[0].substring(26, 34).trim()));
							cbkBO.setApprovalDate(DateFunctions.stringToDate(eachRow[0].substring(26, 34).trim()));
							cbkBO.setTypeId(Integer.parseInt(eachRow[0].substring(43, 44).trim()));
							cbkBO.setCreatorId(eachRow[0].substring(45, 50).trim());
							cbkBO.setShortDesc(eachRow[0].substring(50, 154).trim());
							cbkBO.setReasonCode(eachRow[0].substring(154, 170).trim());
							vendorId = eachRow[0].substring(34, 43).trim();
							System.out.println("@@@@@VendorNumber---:" + vendorId);

							System.out.println("IntBO Record Type--:" + intBO.getRecordType());
							System.out.println("Invoice Number--:" + cbkBO.getInvoiceNumber());
							System.out.println("Reference--:" + cbkBO.getReferenceNumber());
							System.out.println(" ProcLevel--:" + cbkBO.getLocationNumber());
							System.out.println(" DueDate:--:" + cbkBO.getDueDate());
							System.out.println(" InvoiceDate:--:" + cbkBO.getInvoiceDate());
							System.out.println(" ApprovalDate:--:" + cbkBO.getApprovalDate());
							System.out.println(" CreatorId--:" + cbkBO.getCreatorId());
							System.out.println("--ShortDescription--:" + cbkBO.getShortDesc().length());
							System.out.println("-- Cbk Reason--:" + cbkBO.getReasonCode());
							System.out.println("-- ChargebackType--:" + cbkBO.getTypeId());

							// vendorId="807263";
							if (vendorId != null) {
								// VALIDATE FROM DATABASE
								try {
									String vendorStatus = chargebackSearchDelegate.getValidVendorNumber(vendorId);
									System.out.println("vendor Status--:" + vendorStatus);
									if (vendorStatus != null) {
										vendorValidate = true;
										// intBO.setVendorNumber(vendorId);
										cbkBO.setVendorId(vendorId);
									} else {
										mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
										request.setAttribute("actionMessages", errors);
										request.setAttribute("chargebackInterfaceForm", chargebackInterfaceForm);
										return mav;
									}

								} catch (DataAccessException e) {
									e.printStackTrace();
									log.error(e);
								}
								System.out.println("Vendor validate:--" + vendorValidate);
								System.out.println(" VendorNumber--:" + cbkBO.getVendorId());
							}

							System.out.println();
						} else if (j == 1) {
							substring = eachRow[0];
							System.out.println("====Length of 2nd row of the File---: " + substring.length());
							System.out.println(" Table Item--@@:" + substring);

							// cbkBO.setReferenceNumber(eachRow[0].substring(2, 21).trim());
							cbkBO.setLineNumber(Integer.parseInt(eachRow[0].substring(21, 23).trim()));
							cbkBO.setItemNumber(Integer.parseInt(eachRow[0].substring(23, 30).trim()));
							cbkBO.setItemPack(Integer.parseInt(eachRow[0].substring(30, 33).trim()));
							cbkBO.setItemSize(eachRow[0].substring(33, 40).trim());
							cbkBO.setItemDesc(eachRow[0].substring(40, 71).trim());
							cbkBO.setItemUpc(eachRow[0].substring(71, 83).trim());
							cbkBO.setItemQuantity(Integer.parseInt(eachRow[0].substring(90, 94).trim()));
							cbkBO.setItemPrice(Double.parseDouble(eachRow[0].substring(94, 102).trim()));
							cbkBO.setProductCode(eachRow[0].substring(102, 105).trim());
							cbkBO.setDcNumber(eachRow[0].substring(105, 108).trim());
							// cbkBO.setRegion(eachRow[0].substring(105, 108).trim());

							System.out.println("IntBO Record Type--:" + intBO.getRecordType());
							System.out.println("ReferenceNumber--:" + cbkBO.getReferenceNumber());
							System.out.println("--Item Line--:" + cbkBO.getLineNumber());
							System.out.println("--Item Number-- :" + cbkBO.getItemNumber());
							System.out.println("--Item Pack-- :" + cbkBO.getItemPack());
							System.out.println("--Item Size-- " + cbkBO.getItemSize());
							System.out.println("--Item Description-- :" + cbkBO.getItemDesc());
							System.out.println("--Quantity-- " + cbkBO.getItemQuantity());
							System.out.println("--ItemPrice--:$" + cbkBO.getItemPrice());
							System.out.println("--Product Group Code-- :" + cbkBO.getProductCode());
							System.out.println("--DC Number--- :" + cbkBO.getDcNumber());
							System.out.println("--ItemUpc--- :" + cbkBO.getItemUpc());

							System.out.println();
						} else if (j == 2) {
							substring = eachRow[0];
							System.out.println("====Length of 3rd row of the File---: " + substring.length());
							System.out.println(" Table Distrubution--@@:" + substring);
							intBO.setRecordType(eachRow[0].substring(0, 1).trim());

							// cbkBO.setReferenceNumber(eachRow[0].substring(2, 21).trim());
							cbkBO.setCompanyCode(eachRow[0].substring(21, 25).trim());
							cbkBO.setLocationNumber(eachRow[0].substring(25, 30).trim());
							cbkBO.setDistLocNumber(eachRow[0].substring(25, 30).trim());
							cbkBO.setProductGrpCode(eachRow[0].substring(30, 33).trim());
							// cbkBO.setAccountNumber(eachRow[0].substring(33, 39).trim());
							//cbkBO.setDistributionAmt(Double.parseDouble(eachRow[0].substring(39, 49).trim()));
							
							//AMOUNT VALIDATE
							itemTotalAmt =cbkBO.getItemPrice()* cbkBO.getItemQuantity();
							distAmt=Double.parseDouble(eachRow[0].substring(39, 49).trim());
							System.out.println("Total Amount by price and quantity------:"+itemTotalAmt);
							System.out.println("Total Amount by DistAmount------:"+distAmt);
							if (distAmt.equals(itemTotalAmt)) {
								inBalValidate=true;
								System.out.println("Mutliplication of itemAmount == DistAmount:"+inBalValidate);
								cbkBO.setDistributionAmt(distAmt);
							}

							accNum = eachRow[0].substring(33, 39).trim();
							companyCode = eachRow[0].substring(21, 25).trim();
							location = eachRow[0].substring(25, 30).trim();

//			if (companyCode.equals("999")) {
//				companyCode = "999";
//			} else {
//				companyCode = "10";
//			}
//			if (account.length() > 6) {
//				accNum = account.substring(account.length() - 6);
//			} else {
//				accNum = account;
//			}

							location = eachRow[0].substring(25, 30).trim();
							prod_code = eachRow[0].substring(30, 33).trim();
							acct_unit = 0 + location + prod_code;
							System.out.println("---->String Location--:" + location);
							System.out.println("---->String prod_code--:" + prod_code);
							System.out.println("---->String acct_unit--:" + acct_unit);
							if (accNum != null) {
								// VALIDATE FROM DATABASE
								try {
									String accountStatus = chargebackSearchDelegate.getValidAccountNumber(companyCode,
											accNum, acct_unit);
									System.out.println("Account Status---:@@@@" + accountStatus);
									if (accountStatus != null) {
										accountValidate = true;
										cbkBO.setAccountNumber(eachRow[0].substring(33, 39).trim());
									} else {
										mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
										request.setAttribute("actionMessages", errors);
										request.setAttribute("chargebackInterfaceForm", chargebackInterfaceForm);
										return mav;
									}

								} catch (DataAccessException e) {
									e.printStackTrace();
								}
								System.out.println("Account Validate Status---:@@@@" + accountValidate);
							}

							System.out.println("IntBO Record Type--:" + intBO.getRecordType());
							System.out.println("Reference--:" + cbkBO.getReferenceNumber());
							System.out.println("Company Code :" + cbkBO.getCompanyCode());
							System.out.println("---Location Number--:" + cbkBO.getLocationNumber());
							System.out.println("---Dist_Location Number--:" + cbkBO.getLocationNumber());
							System.out.println("---State ProductGroup Code--:" + cbkBO.getProductGrpCode());
							System.out.println("---Account Number---:" + cbkBO.getAccountNumber());
							System.out.println("---Amount---:$" + cbkBO.getDistributionAmt());

							System.out.println();
						} else if (j == 3) {
							substring = eachRow[0];
							System.out.println("===Length of 4th row of the File---: " + substring.length());
							System.out.println(" Table Approver--@@:" + substring);

							// cbkBO.setReferenceNumber(eachRow[0].substring(2, 21).trim());
							cbkBO.setStepNumber(eachRow[0].substring(21, 23).trim());
							cbkBO.setApproverId(eachRow[0].substring(23, 30).trim());

							System.out.println("IntBO Record Type--:" + intBO.getRecordType());
							System.out.println("Reference:" + cbkBO.getReferenceNumber());
							System.out.println("Step Number--:" + cbkBO.getStepNumber());
							System.out.println("--Approver Id--:" + cbkBO.getApproverId());
						}

					}
					if (vendorValidate == true && accountValidate == true&&inBalValidate==true) {
//		chargebackSearchDelegate.createCbkFundsRecord(cbkBO);
//		chargebackSearchDelegate.createCbkItemFundsRecord(cbkBO);
//		chargebackSearchDelegate.createCbkDistributionFundsRecord(cbkBO);
//		chargebackSearchDelegate.createCbkApprFundsRecord(cbkBO);
						System.out.println("Imported  Funds management Invoices into Chargeback Tables--------");
						System.out.println(cbkBO.getInvoiceNumber());
						
					}
				}
			}
			mav.setViewName(ActionUrlMapping.CHARGEBACKINTERFACEACTION.get("success"));
			request.setAttribute("actionMessages", errors);
			// request.setAttribute("chargebackInterfaceForm", chargebackInterfaceForm);
			return mav;
		
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
			log.error("Error in Interface Controller:" + e);
			throw new DataAccessException(e);
		}
		log.debug("*****CHARGEBACK INTERFACE *****Read()");
		mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackInterfaceForm", chargebackInterfaceForm);
		return mav;
	}

}
