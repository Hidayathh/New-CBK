package com.unfi.cbk.dao;

import java.util.List;
import java.util.Map;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.bo.ChargebackManagerBO;
import com.unfi.cbk.exceptions.DataAccessException;

/**
 * The ChargebackSearchDao interface creates the bridge between the caller and
 * the actual work in retrieving the data.
 *
 * @author yhp6y2l
 * @since 1.0
 */

public interface ChargebackManagerDao {

	ResultList getAuditResults(Map searchParametersFrom) throws DataAccessException;

	ResultList getCbkLocDetails(Map searchParametersFrom) throws DataAccessException;

	void saveCreateLocation(Map searchParametersFrom) throws DataAccessException;

	public List getChargebackTypes() throws DataAccessException;

	public ResultList getChargebacks(Map formSearchValuesMap) throws DataAccessException;

	public ResultList locationNumberValidator(Map formSearchValuesMap) throws DataAccessException;

	public ResultList invoiceNumberValidator(Map formSearchValuesMap) throws DataAccessException;

	public ResultList vendorNumberValidator(Map formSearchValuesMap) throws DataAccessException;

	public ResultList originatorValidator(Map formSearchValuesMap) throws DataAccessException;

	public ResultList approverValidator(Map formSearchValuesMap) throws DataAccessException;

	public void approveChargebacks(ChargebackBO cbkBo) throws DataAccessException;

	public String getMaxStepNumber(String typeId, String chargebackTotal) throws DataAccessException;

	public void updateChargebackApprover(ChargebackBO chargeBack) throws DataAccessException;

	public ResultList getChargeAccrual(Map map) throws DataAccessException;

	public ResultList getChargebackRoles(Map map) throws DataAccessException;

	// Product Code

	public ResultList getProductGroup(Map map) throws DataAccessException;

	public void InsertProductCode(Map formSearchValuesMap) throws DataAccessException;

	public ChargebackManagerBO getProductDetails(String productCode) throws DataAccessException;

	public void deleteProductDetails(String productCode) throws DataAccessException;

	public void updateProductCode(Map formSearchValuesMap) throws DataAccessException;

	// Excluded Vendor

	public ResultList getExcludedVendor(Map map) throws DataAccessException;

	public void InsertExcludedVendor(Map formSearchValuesMap) throws DataAccessException;

	public ChargebackManagerBO getVendorDetails(String vendor) throws DataAccessException;

	public void updateVendor(Map formSearchValuesMap) throws DataAccessException;

	public void deleteExcludedVend(String vendor) throws DataAccessException;

	// Route Name

	public ResultList getRouteName(Map map) throws DataAccessException;

	public ChargebackManagerBO getRouteId(Map map) throws DataAccessException;

	public void InsertRouteName(Map formSearchValuesMap) throws DataAccessException;

	public ChargebackManagerBO getRouteDetails(String routeId) throws DataAccessException;

	public void updateRouteName(Map formSearchValuesMap) throws DataAccessException;

	public void deleteRouteDetails(String routeId) throws DataAccessException;

//Chargeback Locations and ReasonCode Methods
	public ResultList getReasonResults() throws DataAccessException;

	public ChargebackManagerBO getEditLocDetails(String locationNumber) throws DataAccessException;

	public void saveCreateReason(Map searchParametersFromForm) throws DataAccessException;

	public ChargebackManagerBO getReasonDetails(String chargebackReason) throws DataAccessException;

	public void deleteLocDetails(String locationNumber) throws DataAccessException;

	public void updateLocation(Map map) throws DataAccessException;
	
	List getLocations() throws DataAccessException;

	public void updateReason(Map map) throws DataAccessException;

	public void deleteReasonDetails(String chargebackReason) throws DataAccessException;

	public List getAllTypes() throws DataAccessException;

	public ResultList getChargeDefinition(Map map) throws DataAccessException;

	public void updateChargeDefinition(List selectedDef) throws DataAccessException;

	// AuthorizationAmountByType
	public void saveAmountByType(Map searchParametersFromForm) throws DataAccessException;

	public void updateAmountByType(Map map) throws DataAccessException;

	public void deleteAmountByType(String roleId) throws DataAccessException;

	public ResultList getTypeDetails(Map map) throws DataAccessException;

	ChargebackManagerBO getEditType(Map map) throws DataAccessException;

	public List getAllRoles() throws DataAccessException;

	public String deleteProductGroupCodeReference(String productCode) throws DataAccessException;

	public String deleteRouteReference(String routeId) throws DataAccessException;


 // AuthorizationAmountByRole

	 public List getRoles() throws DataAccessException; 
	
	public ResultList getAuthAmount(Map map) throws DataAccessException;
	
	 public List getChargeTypes() throws DataAccessException; 
	 
	 public void InsertCbkByRole(Map formSearchValuesMap) throws DataAccessException;
	 
	 ChargebackManagerBO getAuthRoleDetails(Map searchParametersFrom) throws DataAccessException;
	 
	 public void updateAuthByRole(Map formSearchValuesMap) throws DataAccessException;
	 
	  public void deleteAuthRoleDetails(Map searchParametersFromForm) throws DataAccessException;
	  
	  
	  
	  public ResultList getRoutingDetails(Map map) throws DataAccessException;

	  void saveCreateRouting(Map searchParametersForm) throws DataAccessException;

	  ChargebackManagerBO getEditRoutingAppr(Map map) throws DataAccessException;

	  	void updateRouting(Map map) throws DataAccessException;

	  	void deleteRouting(Map map) throws DataAccessException;
	  	
	  	
	  	
	  	//Regional Administrators.

	  public ResultList allUsers(Map map) throws DataAccessException;
		
		public ResultList specificUserResults(Map map) throws DataAccessException;
		
		public ResultList specificUserSearch(Map map) throws DataAccessException;	
		
		public ResultList specificRoleIdSearch(Map map) throws DataAccessException;
		
		public List getLocationsForCreateUser() throws DataAccessException;

		public List getRolesForUser() throws DataAccessException;
		
		public ChargebackManagerBO getUserDetails(String userId) throws DataAccessException;

		public ResultList getUserRolesLocations(String userId) throws DataAccessException;
		
		public List getRolesByUserForMenu() throws DataAccessException;
		
		
		
		//Work with chargebcks
		public void getCancelChargeback(String invoiceNumber) throws DataAccessException;
		
		public String getMaxStepNumberForInvoice(String invoiceNumber) throws DataAccessException;
		
		public List getReasons() throws DataAccessException;
		
		public List getProductGroup() throws DataAccessException;
		
		public ChargebackManagerBO getChargebackVendor(Map formSearchValuesMap) throws DataAccessException;
		
		public ChargebackManagerBO getChargebackDetailInfo(Map formSearchValuesMap) throws DataAccessException;
		
		public ResultList getCbkDetTable(Map formSearchValuesMap) throws DataAccessException;
		
		public ResultList getChargebackDistribution(Map formSearchValuesMap) throws DataAccessException;
		
		 public String getMinStepNumberWithInvoiceAmount(String invoiceNumber,String locationNumber,String typeId) throws DataAccessException;
		 
		 public ResultList getApprovalHistory(String invoice) throws DataAccessException;
		 
		 public List<ChargebackManagerBO> getAttachmentName(String invoiceNumber) throws DataAccessException;
		 
		public String getRoleIdForNextApprover(String invoiceNumber,String typeId,String locationNumber,String userId) throws DataAccessException;
		
		public String getAdminUser(String userId, String roleId) throws DataAccessException;
		
		public ResultList getChargebackApprovalStatus(String inviceNumber, String approverId) throws DataAccessException;
		
		  public String getInvoiceEditableStatus(String invoiceNumber) throws DataAccessException;
		
	  
}
