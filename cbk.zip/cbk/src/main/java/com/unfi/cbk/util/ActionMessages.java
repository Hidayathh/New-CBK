
/**
* 
 */
package com.unfi.cbk.util;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

/**
 * @author yhp6y2l
 *
 */
@Component
@Scope(scopeName = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ActionMessages {

	public static final String GLOBAL_MESSAGE = Constants.MSG_INFO;
	public static final String GLOBAL_ERROR = Constants.MSG_ERROR;
	public static final String GLOBAL_WARN = Constants.MSG_WARN;

	@Autowired
	private MessageSource messageSource;

	private boolean type;

	private List<String> messages;

	private Map<String, List<String>> messagesMap;

	public void clear() {
		if (this.messages != null) {
			this.messages.clear();
		}
		if (this.messagesMap != null) {
			this.messagesMap.clear();
		}
	}

	public boolean isType() {
		return type;
	}

	public void setType(boolean type) {
		this.type = type;
	}

	public void add(String msgError, String msg) {

		if (this.messagesMap == null) {
			this.messagesMap = new LinkedHashMap<>();
		}

		List<String> messageList = this.messagesMap.get(msgError);
		if (messageList == null) {
			messageList = new ArrayList<>();
		}
		messageList.add(msg);

		this.messagesMap.put(msgError, messageList);
	}

	public void add(String msgCode, String msgSourceKey, String[] msgPlaceHolders) {
		addMsg(msgCode, msgSourceKey, msgPlaceHolders);
	}

	public void add(String msgCode, String msgSourceKey, String defaultMsg, String[] msgPlaceHolders) {
		addMsg(msgCode, msgSourceKey, defaultMsg, msgPlaceHolders);
	}

	public void add(String msgCode, String msgSourceKey, String defaultMsg, boolean isAppendDefaultMsg,
			String[] msgPlaceHolders) {
		addMsg(msgCode, msgSourceKey, defaultMsg, isAppendDefaultMsg, msgPlaceHolders);
	}

	public boolean isEmpty() {

		if (this.messages == null && this.messagesMap == null) {
			return true;
		}

		if (this.messages != null && this.messages.isEmpty()) {
			return true;
		}

		if (this.messagesMap != null && this.messagesMap.isEmpty()) {
			return true;
		}

		return false;
	}

	public void addMsg(String msgCode, String msgSourceKey, String[] msgPlaceHolders) {
		String msg = "";
		if (msgPlaceHolders == null || msgPlaceHolders.length == 0) {
			msg = messageSource.getMessage(msgSourceKey, null, msgSourceKey, LocaleContextHolder.getLocale());
		} else {
			msg = messageSource.getMessage(msgSourceKey, msgPlaceHolders, msg, LocaleContextHolder.getLocale());
		}

		add(msgCode, msg);

	}

	public void addMsg(String msgCode, String msgSourceKey, String defaultMsg, String[] msgPlaceHolders) {
		String msg = "";

		if (msgPlaceHolders == null || msgPlaceHolders.length == 0) {
			msg = messageSource.getMessage(msgSourceKey, null, defaultMsg, LocaleContextHolder.getLocale());
		} else {
			msg = messageSource.getMessage(msgSourceKey, msgPlaceHolders, defaultMsg, LocaleContextHolder.getLocale());
		}

		add(msgCode, msg);

	}

	public void addMsg(String msgCode, String msgSourceKey, String defaultMsg, boolean isAppendDefaultMsg,
			String[] msgPlaceHolders) {
		String msg = "";

		if (msgPlaceHolders == null || msgPlaceHolders.length == 0) {
			msg = messageSource.getMessage(msgSourceKey, null, defaultMsg, LocaleContextHolder.getLocale());
		} else {
			msg = messageSource.getMessage(msgSourceKey, msgPlaceHolders, defaultMsg, LocaleContextHolder.getLocale());
		}
		if (isAppendDefaultMsg) {
			msg += " " + defaultMsg;
		}

		add(msgCode, msg);

	}

	public List<String> getMessages() {
		return messages;
	}

	public void setMessages(List<String> messages) {
		this.messages = messages;
	}

	public Map<String, List<String>> getMessagesMap() {
		return messagesMap;
	}

	public void setMessagesMap(Map<String, List<String>> messagesMap) {
		this.messagesMap = messagesMap;
	}

	@Override
	public String toString() {
		return "ActionMessages [type=" + type + ", messages=" + messages + ", messagesMap=" + messagesMap + "]";
	}

	public void saveMessages(HttpServletRequest request) {

		request.setAttribute("messages", this.messagesMap);
		request.setAttribute("messageList", this.messages);

	}

}
