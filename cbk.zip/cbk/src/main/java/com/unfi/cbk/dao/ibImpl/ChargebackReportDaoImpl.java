package com.unfi.cbk.dao.ibImpl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.dao.ChargebackReportDao;
import com.unfi.cbk.exceptions.DataAccessException;

/**
 * The ChargebackExportDaoImpl class handles the call to the database to get the
 * results of the chargebacks search based on the form values.
 *
 * @author vpil001
 * @since 1.0
 */

public class ChargebackReportDaoImpl extends SqlMapClientDaoSupport implements ChargebackReportDao {

	private static Logger log = Logger.getLogger(ChargebackReportDaoImpl.class);
	protected static Date BAD_DATE = null;

	public ChargebackReportDaoImpl(SqlMapClientTemplate sqlMapTemplate) {
		this.setSqlMapClientTemplate(sqlMapTemplate);
	}

	public List getReasonCode() throws DataAccessException {
		List l = null;
		try {
			// HashMap map = new HashMap();
			l = (List) getSqlMapClientTemplate().queryForList("ChargebackReport.getReasonCode");
			System.out.println("------------ChargebackReportDaoImpl.java-getRoles---List size----" + l.size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		System.out.println(l);
		return l;
	}
	
	
	@Override
	public ResultList getChargebackReportList(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		ResultList rL = new ResultList();

		try {

			System.out.println("------ExportDaoImpl.java-------getChargebackReportList()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackReport.getChargebackReportList",map));
			System.out.println("------------ExportDaoImpl.java--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getChargebackReportList() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}
		return rL;

	}
	
}