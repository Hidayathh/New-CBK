/*
 * Created on Nov 30, 2006
 */
package com.unfi.cbk.ui;

/**
 * @author yhp6y2l
 * @version 1.0
 */
public interface Sortable {
	public String getSortBy();

	public String getSortOrder();

	public void setSortBy(String string);

	public void setSortOrder(String string);
}
