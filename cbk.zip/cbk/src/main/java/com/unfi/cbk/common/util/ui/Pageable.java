/*
 * Created on Apr 20, 2005
 * 
 */
package com.unfi.cbk.common.util.ui;

/**
 * 
 * @author yhp6y2l
 *
 */
public interface Pageable {
	public int getCurrentRecord();

	public int getDisplayCount();

	public int getTotalRecords();

	public void setCurrentRecord(int record);

	public void setDisplayCount(int display);

	public void setTotalRecords(int total);

	public boolean isShowAll();

	public void setShowAll(boolean showAll);
}
