package com.unfi.cbk.controller.chargeback;

import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.controller.PageAccessResolver;
import com.unfi.cbk.delegates.ChargebackSearchDelegate;
import com.unfi.cbk.forms.ChargebackSearchForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.Constants;

/**
 * The GetResultsAction class is the struts action called when retrieving the
 * search results. The action simply determines the user type and forwards the
 * request to a secondary struts action specific to the user type.
 * <p>
 * This is to accommodate the struts Validator. Since all three versions of the
 * search form use the same ActionForm, the different validations that need to
 * be done specific to the type of form used are accomplished by having the
 * validator use the actions to determine which rules to use.<br>
 * This action, then, makes the user type transparent to the user by always
 * having the same action called when searching, regardless of user type.
 *
 * @author vpil001
 * @since 1.0
 */
@Controller("getResultsAction_chargebacks")
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ChargebackSearchResultsController {// extends Action {
	static Logger log = Logger.getLogger(ChargebackSearchResultsController.class);
	@Autowired
	private ChargebackSearchDelegate chargebackSearchDelegate;

	public ChargebackSearchResultsController(ChargebackSearchDelegate chargebackSearchDelegate) {
		this.chargebackSearchDelegate = chargebackSearchDelegate;
	}

	@Autowired
	ActionMessages messages;
	@Autowired
	Environment env;
	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	@RequestMapping(value = "/getChargebackResults", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView execute(@ModelAttribute("chargebackSearchForm") ChargebackSearchForm chargebackSearchForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***** CHARGEBACK SEARCH - RESULTS *****");
		chargebackSearchForm.setFormParameterMap(request);
		// **** Exceptions handled by global exception handlers ****
		String dateCriteria = request.getParameter("dateCriteria");

		HttpSession session = request.getSession();
		String SmUserId = (String) session.getAttribute("SmUserId");

		Map<String, Comparable> searchParametersFromForm = chargebackSearchForm.getMap();

		if (chargebackSearchForm.getLocationNumber() != null) {

			String idPattern = "[\\s0-9,. ]*";
			boolean specialCharFlag = validateSpecialCharacters(chargebackSearchForm.getLocationNumber().toString(),
					idPattern);
			if (specialCharFlag == true) {
				messages.add("locationNumber", "errors.validateLocation", null);
			}
		}

		if (messages.isEmpty()) {
			searchParametersFromForm.put("userId", SmUserId);
			searchParametersFromForm.put("originator", chargebackSearchForm.getOriginator());
			searchParametersFromForm.put("nextApprover", chargebackSearchForm.getNextApprover());
			searchParametersFromForm.put("vendorId", chargebackSearchForm.getVendorId());
			if (!chargebackSearchForm.getLocationNumber().isEmpty()
					&& chargebackSearchForm.getLocationNumber() != null) {
				String location = chargebackSearchForm.getLocationNumber().substring(0, 2);
				searchParametersFromForm.put("location", location);
			} else {
				searchParametersFromForm.put("location", "");
			}

			searchParametersFromForm.put("invoiceFrom", chargebackSearchForm.getInvoiceFrom());
			searchParametersFromForm.put("invoiceTo", chargebackSearchForm.getInvoiceTo());
			if (chargebackSearchForm.getInvoiceTo() == null || chargebackSearchForm.getInvoiceTo().isEmpty()) {
				searchParametersFromForm.put("invoiceTo", chargebackSearchForm.getInvoiceFrom());
			}

			searchParametersFromForm.put("amountFrom", chargebackSearchForm.getAmountFrom());
			searchParametersFromForm.put("amountTo", chargebackSearchForm.getAmountTo());
			searchParametersFromForm.put("dateCriteria", dateCriteria);
			searchParametersFromForm.put("type", chargebackSearchForm.getType());
			searchParametersFromForm.put("fromDate", chargebackSearchForm.getFromDate());
			searchParametersFromForm.put("toDate", chargebackSearchForm.getToDate());

		
			if (("Cancelled").equalsIgnoreCase(chargebackSearchForm.getStatus())) {// Cancelled IS NOT NULL
				searchParametersFromForm.put("cancelled", "true");
			} else
			// Active is NULL
			{
				searchParametersFromForm.put("active", "true");
			}
			if (("Final").equalsIgnoreCase(chargebackSearchForm.getAPStatus())) {// Final IS NOT NULL
				searchParametersFromForm.put("final", true);
			} else
			// notFinal IS NULL
			{
				searchParametersFromForm.put("notFinal", true);
			}
			// VALIDATION START
			if (chargebackSearchForm.getLocationNumber() != null
					&& !chargebackSearchForm.getLocationNumber().isEmpty()) {
				ResultList locationValidatorResult = chargebackSearchDelegate
						.locationNumberValidator(searchParametersFromForm);
				if (locationValidatorResult.getList().size() == 0) {
					messages.add("locationNumber", "errors.InvalidLocationNumber", null);
				}
			}

			if (chargebackSearchForm.getLocationNumber() != null && !chargebackSearchForm.getVendorId().isEmpty()) {
				ResultList vendorValidatorResult = chargebackSearchDelegate
						.vendorNumberValidator(searchParametersFromForm);
				if (vendorValidatorResult.getList().size() == 0) {
					messages.add("vendorId", "errors.InvalidVendorNumber", null);
				}
			}

			if (chargebackSearchForm.getOriginator() != null && !chargebackSearchForm.getOriginator().isEmpty()) {
				ResultList originatorValidatorResult = chargebackSearchDelegate
						.originatorValidator(searchParametersFromForm);
				if (originatorValidatorResult.getList().size() == 0) {
					messages.add("originator", "errors.InvalidOriginator", null);
				}
			}

			if (chargebackSearchForm.getNextApprover() != null && !chargebackSearchForm.getNextApprover().isEmpty()) {
				ResultList approverValidatorResult = chargebackSearchDelegate
						.nextApproverValidator(searchParametersFromForm);
				if (approverValidatorResult.getList().size() == 0) {
					messages.add("nextApprover", "errors.InvalidApprover", null);
				}
			}
			// VALIDATION END
		}

		chargebackSearchForm.validate(request, messages);

		if (!messages.isEmpty()) {

			List chargebackTypes = chargebackSearchDelegate.getChargebackTypes();
			chargebackSearchForm.setChargebackTypes(chargebackTypes);
			request.setAttribute("actionMessages", messages);
			messages.saveMessages(request);
			mav.setViewName(ActionUrlMapping.CHARGEBACKNEWSEARCHACTION.get(Constants.ACTION_SUCCESS));
			request.setAttribute("chargebackSearchForm", chargebackSearchForm);
			return mav;
		}

		// Define the display parameters
		int maxRows = 20;
		chargebackSearchForm.setDisplayCount(maxRows);

		if (chargebackSearchForm.isShowAll()) {
			searchParametersFromForm.put("showAll", "true");
		} else {
			searchParametersFromForm.put("rowStart", new Integer(chargebackSearchForm.getCurrentRecord()));
			searchParametersFromForm.put("rowEnd", new Integer(chargebackSearchForm.getCurrentRecord() + maxRows - 1));
		}

		// Get the search results based on the parameters in the form
		ResultList searchResults = chargebackSearchDelegate.getChargebacks(searchParametersFromForm);

		chargebackSearchForm.setSearchResults(searchResults.getList());
		// Populate the result count property in the ActionForm
		chargebackSearchForm.setTotalRecords(searchResults.getTotalCount().intValue());

		messages.saveMessages(request);

		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess()) {
			mav.setViewName(ActionUrlMapping.CHARGEBACKGETRESULTSACTION.get(Constants.ACTION_SUCCESS));
			request.setAttribute("actionMessages", messages);
			request.setAttribute("chargebackSearchForm", chargebackSearchForm);
			
			return mav;
		}
		mav.setViewName(ActionUrlMapping.CHARGEBACKGETRESULTSACTION.get("other"));
		request.setAttribute("actionMessages", messages);
		request.setAttribute("chargebackSearchForm", chargebackSearchForm);
		return mav;
	}

	/**
	 * 
	 * @param string
	 * @param idNamePattern
	 * @return
	 */

	private boolean validateSpecialCharacters(String string, String idNamePattern) {
		Pattern pattern = Pattern.compile(idNamePattern);

		Matcher matcher = pattern.matcher(string);

		boolean patternFlag = false;

		if (!matcher.matches()) {

			patternFlag = true;
			log.debug("String--- " + string + " contains special character");
		}

		return patternFlag;
	}
}