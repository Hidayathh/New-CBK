package com.unfi.cbk.controller.chargeback;

import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.UserSearchResultBO;
import com.unfi.cbk.delegates.AdminDelegate;
import com.unfi.cbk.delegates.UserSearchResultDeligate;
import com.unfi.cbk.forms.ChargebackAdminForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.DateFunctions;
import com.unfi.cbk.util.ESAPIUtil;
import com.unfi.cbk.util.StringFunctions;

/**
 * The ExportAdminUserSearchResultsController class is the struts action called to export
 * the search results to a CSV file. The action makes the call to the database
 * for the results, parses through each row, and creates a CSV with one line per
 * result row.
 * <p>
 * The resulting text file is sent to the requesing page as the response with
 * the appropriate mime type and response headers set.
 *
 * @author vpil001
 * @since 1.0
 */
@Controller("exportAdminUserSearchResultsAction_chargeback")
public class ExportAdminUserSearchResultsController {// extends Action {
	static Logger log = Logger.getLogger(ExportAdminUserSearchResultsController.class);

	@Autowired
	private AdminDelegate adminDelegate;
	
	@Autowired
	private UserSearchResultDeligate userSearchResultDeligate;

	public ExportAdminUserSearchResultsController(AdminDelegate adminDelegate) {
		this.adminDelegate = adminDelegate;
	}

	@Autowired
	ActionMessages error;
	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	public ExportAdminUserSearchResultsController() {

	}

	@RequestMapping(value = "/exportAdminUserResults", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView execute(@ModelAttribute("chargebackAdminForm") ChargebackAdminForm chargebackAdminForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		chargebackAdminForm.setFormParameterMap(request);
		ServletOutputStream out = null;

		try {
			log.debug("***** CHARGEBACK ADMIN USER  SEARCH RESULTS- EXPORT *****");
			// HttpSession session=request.getSession();

			Map<String, Comparable> searchParametersFromForm = chargebackAdminForm.getMap();

			boolean exceptionOccurred = false;

			log.debug("***** CHARGEBACK ADMIN *****");
			Map searchParametersFrom = chargebackAdminForm.getMap();
			

			// Location
			searchParametersFrom.put("location", chargebackAdminForm.getLocation());
			if (chargebackAdminForm.getLocation()!=null && chargebackAdminForm.getLocation().equals("2")) {
				searchParametersFrom.put("locationNumber", chargebackAdminForm.getLocationNumber());
			}

			// Roles
			searchParametersFrom.put("roles", chargebackAdminForm.getRoles());
			if (chargebackAdminForm.getRoles() != null && chargebackAdminForm.getRoles().equals("1")) {
				chargebackAdminForm.setRoleSelected("");
			}
			searchParametersFrom.put("roleSelected", chargebackAdminForm.getRoleSelected());

			// userId - Originator
			if (chargebackAdminForm.getOriginator() != null && !chargebackAdminForm.getOriginator().isEmpty()) {
				searchParametersFrom.put("userId", chargebackAdminForm.getOriginator());
			}

			// Status
			searchParametersFrom.put("status", chargebackAdminForm.getStatus());
			if (chargebackAdminForm.getStatus() != null && chargebackAdminForm.getStatus().equals("1")) {
				chargebackAdminForm.setStatusSelected("");
			}
			searchParametersFrom.put("statusSelected", chargebackAdminForm.getStatusSelected());

			//ResultList searchResults = adminDelegate.adminResults(searchParametersFrom);
			
			ResultList searchResults = userSearchResultDeligate.allUsers(searchParametersFrom);
			chargebackAdminForm.setSearchResults(searchResults.getList());
			chargebackAdminForm.setTotalRecords(searchResults.getTotalCount().intValue());
			
		
			List ResulstList = (List) chargebackAdminForm.getSearchResults();

			out = response.getOutputStream();

			// The response headers must be set in the following order, or else IE
			// won't handle things properly.
			// response.setHeader("Content-length", ""+file.getFile().length());
			response.setHeader("Content-disposition", "attachment; filename=AdminUserSearchResults.csv");
			response.setContentType("text/comma-separated-values");
			response.setHeader("Pragma", "public");
			response.setHeader("Cache-control", "must-revalidate");

			// out.println("Document Results (" + searchCriteriaSummary + ")");
			out.println("Users List  ");
			out.println("User information  pulled: " + DateFunctions.getTodayTime());
			/*
			 * if (!dateRangeUsed.equals("")) { out.println("Deduction extract date range: "
			 * + dateRangeUsed); }
			 */
			out.println();
			out.println("User ID, User Name, Email, Status");

			for (int i = 0; i < ResulstList.size(); i++) {
				//AdminResultsBO adminBO = (AdminResultsBO) ResulstList.get(i);
				UserSearchResultBO adminBO = (UserSearchResultBO) ResulstList.get(i);

				// Put a '=' and quotes around the document number to avoid
				// Excel dropping any leading zeros in the value.

				out.print("=\"" + ESAPIUtil.encodeforXSS(StringFunctions.convertNull(adminBO.getUserId())) + "\"");
				out.print(",");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(adminBO.getUserName())));
				out.print(",");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(adminBO.getEmailId())));
				out.print(",");
				if (adminBO.getStatusSelected().equals("A"))
					out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull("Active")));
				else if (adminBO.getStatusSelected().equals("I"))
					out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull("Inactive")));
				out.print("\n");
			}

		} catch (Exception e) {
			e.printStackTrace();
			// Report the error using the appropriate name and ID.
			log.error("Exception in execute():" + e);
		} finally {
			if (out != null) {
				out.close();
			}
			response.flushBuffer();
		}

		// No mappings or forwards for this action...
		return null;
	}

}