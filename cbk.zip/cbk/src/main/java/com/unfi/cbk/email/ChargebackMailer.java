package com.unfi.cbk.email;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.exceptions.CbkServiceException;
import com.unfi.cbk.forms.ChargebackCreateForm;
import com.unfi.cbk.forms.ChargebackUpdateForm;

/**
 * @author yhp6y2l
 */
@Configuration
public class ChargebackMailer {

	@Autowired
	private JavaMailSender javaMailSender;
	@Autowired
	private Environment environment;
	

	public void updateSendEmail(ChargebackUpdateForm update, String AssignerEmail, String SmUserId) throws CbkServiceException, MessagingException {
		
		MimeMessage msg = javaMailSender.createMimeMessage();
		MimeMessageHelper message = new MimeMessageHelper(msg, true);
		message.setFrom(environment.getProperty("usergroup.email.address"));
		message.setTo(AssignerEmail);
		message.setSubject(
				"Chargeback Information Invoice #" + update.getInvoiceNumber()+ " updated by "+SmUserId);
		message.setText("<h1>Central Disbursements Chargeback Application</h1>" + System.lineSeparator() 
				+ "Chargeback # "+update.getInvoiceNumber()+" has been approved by "+ update.getCreatorId()
				+ " for Location "+update.getLocationNumber()+". Please launch the Chargeback application from the Start>SV Apps>Chargeback menu option and select 'View Invoices For' section of the ‘Create New Chargeback’ screen. "
				, true);
		javaMailSender.send(msg);
		

	}
	
	public void createSendEmail(ChargebackCreateForm create, String AssignerEmail, String SmUserId) throws CbkServiceException, MessagingException {
		
		MimeMessage msg = javaMailSender.createMimeMessage();
		MimeMessageHelper message = new MimeMessageHelper(msg, true);
		message.setFrom(environment.getProperty("usergroup.email.address"));
		message.setTo(AssignerEmail);
		message.setSubject(
				"Chargeback Information Invoice #" + create.getInvoiceNumber()+ " created by "+SmUserId);
		message.setText("<h1>Central Disbursements Chargeback Application</h1>" + System.lineSeparator() 
				+ "Chargeback # "+create.getInvoiceNumber()+" has been created by "+ create.getCreatorId()
				+ " for Location "+create.getLocationNumber()+". Please launch the Chargeback application from the Start>SV Apps>Chargeback menu option and select 'View Invoices For' section of the ‘Create New Chargeback’ screen. "
				, true);
		javaMailSender.send(msg);
		

	}

	public void nextApproverSendEmail(ChargebackBO cbkbo, String AssignerEmail, String SmUserId) throws CbkServiceException, MessagingException {
		
		MimeMessage msg = javaMailSender.createMimeMessage();
		MimeMessageHelper message = new MimeMessageHelper(msg, true);
		message.setFrom(environment.getProperty("usergroup.email.address"));
		message.setTo(AssignerEmail);
		message.setSubject(
				"Chargeback Information Invoice #" + cbkbo.getInvoiceNumber()+ " approved by "+SmUserId);
		message.setText("<h1>Central Disbursements Chargeback Application</h1>" + System.lineSeparator() 
				+ "Chargeback # "+cbkbo.getInvoiceNumber()+" has been assigned to "+ cbkbo.getNextApprover()
				+ " for Location "+cbkbo.getLocationNumber()+". Please launch the Chargeback application from the Start>SV Apps>Chargeback menu option and select 'View Invoices For' section of the ‘Create New Chargeback’ screen. "
				, true);
		javaMailSender.send(msg);
		

	}

	public void finalApproverSendEmail(ChargebackBO cbkbo, String AssignerEmail, String SmUserId) throws CbkServiceException, MessagingException {
		
		MimeMessage msg = javaMailSender.createMimeMessage();
		MimeMessageHelper message = new MimeMessageHelper(msg, true);
		message.setFrom(environment.getProperty("usergroup.email.address"));
		message.setTo(AssignerEmail);
		message.setSubject(
				"Chargeback Information Invoice #" + cbkbo.getInvoiceNumber()+ " approved by "+SmUserId);
		message.setText("<h1>Central Disbursements Chargeback Application</h1>" + System.lineSeparator() 
				+ "Chargeback # "+cbkbo.getInvoiceNumber()+" has been approved by "+ cbkbo.getCreatorId()
				+ " for Location "+cbkbo.getLocationNumber()+". And reached maximum amount, hence no further approval is required."
				, true);
		javaMailSender.send(msg);
		

	}

}
