package com.unfi.cbk.controller.chargeback;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.beans.UserDataBean;
import com.unfi.cbk.dao.ChargebackCommonDao;
import com.unfi.cbk.forms.VendorSelectorForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.Constants;
import com.unfi.cbk.util.StringFunctions;

/**
 * The action method that will be called is automatically determined based upon
 * the value of the parameter that is passed in.
 * <p>
 * The action method will then sets the user data in the request, sets any
 * values needed, and forwards to the appropriate action mapping.
 *
 * @author vpil001
 * @version 1.0
 */
@Controller
public class VendorSelectorActions {
	static Logger log = Logger.getLogger(VendorSelectorActions.class);
	private ChargebackCommonDao chargebackCommonDao;

	public VendorSelectorActions(@Autowired ChargebackCommonDao dao) {
		this.chargebackCommonDao = dao;
	}

	@Autowired
	ActionMessages errors;

	/**
	 * The open() method displays the Vendor Selector pop up.
	 * 
	 * @param mapping  The ActionMapping used to select this instance
	 * @param form     The ActionForm bean for this request
	 * @param request  The HTTP request we are processing
	 * @param response The HTTP response we are creating
	 * @return an ActionForward instance describing where and how control should be
	 *         forwarded, or null if the response has already been completed.
	 * @throws Exception if an exception occurs
	 */
	@RequestMapping(value = "/vendorSelector", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=open" })
	public ModelAndView open(@ModelAttribute VendorSelectorForm vendorSelectorForm, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		// ActionErrors errors = new ActionErrors();
		// ActionMessages errors = new ActionMessages();
		// ActionForward forward = new ActionForward(); // return value
		System.out.println("VendorSelectorActions.java---------open()---");
		boolean exceptionOccurred = false;

		try {
			log.debug("***** VENDOR SELECTOR OPEN *****");

			// Set the UserDataBean for the request. The setUserInfo method exists in the
			// base class.
			UserDataBean userBean = new UserDataBean(request);

		} catch (Exception e) {
			// Determine the error, log it, and put an error message in ActionErrors
			exceptionOccurred = true;
			// forward = mapping.findForward("failure");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);

			// Only add the general error if no other errors are present
			if (errors.isEmpty()) {
				errors.add("error", "errors.general");
				// errors.add("error", "errors.general");
			}
		}

		if (!exceptionOccurred) {
			// forward = mapping.findForward("open");
			mav.setViewName(ActionUrlMapping.VENDORSELECTORACTIONS.get("open"));
		}

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			// forward = mapping.findForward("failure");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
		}

		// Finish with
		// return (forward);
		System.out.println("-----URL mapping---" + mav.getViewName());
		request.setAttribute("actionMessages", errors);
		request.setAttribute("vendorSelectorForm", vendorSelectorForm);
		return mav;
	}

	/**
	 * The search() method get the values from the database.
	 * 
	 * @param mapping  The ActionMapping used to select this instance
	 * @param form     The ActionForm bean for this request
	 * @param request  The HTTP request we are processing
	 * @param response The HTTP response we are creating
	 * @return an ActionForward instance describing where and how control should be
	 *         forwarded, or null if the response has already been completed.
	 * @throws Exception if an exception occurs
	 */
	@RequestMapping(value = "/vendorSelector", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=search" })
	public ModelAndView search(@ModelAttribute VendorSelectorForm vendorSelectorForm, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		// ActionErrors errors = new ActionErrors();
		ActionMessages errors = new ActionMessages();
		// ActionForward forward = new ActionForward(); // return value
		// VendorSelectorForm vendorSelectorForm = (VendorSelectorForm) form;

		boolean exceptionOccurred = false;

		try {
			System.out.println("----VENDOR SELECTOR SEARCH------");
			log.debug("***** VENDOR SELECTOR SEARCH *****");
			List searchResults = null;
			// Set the UserDataBean for the request. The setUserInfo method exists in the
			// base class.
			UserDataBean userBean = new UserDataBean(request);
			System.out.println("----VENDOR SELECTOR SEARCH------");
			// Get the list of vendors and put them into the bean for the JSP page
			System.out.println("---vendorSelectorForm.getVendorNumber()--" + vendorSelectorForm.getVendorNumber());
			System.out.println("---vendorSelectorForm.getVendorName()--" + vendorSelectorForm.getVendorName());
			if(vendorSelectorForm.getVendorNumber()!="") 
			{
				String vendorId = StringFunctions.spaceFillLeft(vendorSelectorForm.getVendorNumber(),9,true);
				System.out.println("----VENDOR SELECTOR SEARCH---vendorId---"+vendorId);
				 searchResults = chargebackCommonDao.doVendorSearch(vendorId, vendorSelectorForm.getVendorName());
			}
			else
			{
				 searchResults = chargebackCommonDao.doVendorSearch(vendorSelectorForm.getVendorNumber(), vendorSelectorForm.getVendorName());
			}
				
			
			System.out.println("----VENDOR SELECTOR SEARCH-----111-");
			vendorSelectorForm.setSearchResults(searchResults);
			System.out.println("----VENDOR SELECTOR SEARCH-----222-");
			vendorSelectorForm.setResults(new Integer(searchResults.size()));

			System.out.println("----VENDOR SELECTOR SEARCH----333--");
		} catch (Exception e) {
			// Determine the error, log it, and put an error message in ActionErrors
			exceptionOccurred = true;
			e.printStackTrace();
			// forward = mapping.findForward("failure");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));

			log.error("Exception in execute:" + e);

			// Only add the general error if no other errors are present
			if (errors.isEmpty()) {
				errors.add("error", "errors.general");
			}
		}

		if (!exceptionOccurred) {
			// forward = mapping.findForward("open");
			mav.setViewName(ActionUrlMapping.VENDORSELECTORACTIONS.get("open"));
		}

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			// forward = mapping.findForward("failure");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
		}

		// Finish with
		// return (forward);
		System.out.println("-----URL mapping" + mav.getViewName());
		request.setAttribute("actionMessages", errors);
		request.setAttribute("vendorSelectorForm", vendorSelectorForm);
		return mav;
	}
}
