package com.unfi.cbk.config;

import org.springframework.boot.Banner.Mode;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.context.ApplicationPidFileWriter;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication(scanBasePackages = { "com.unfi.cbk" }, exclude = { DataSourceAutoConfiguration.class })

/**
 * 
 * @author yhp6y2l
 *
 */

public class CBKBootApplication {
	/**
	 * 
	 * Spring Boot start controller to start the application
	 */
	@Bean
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}

	public static void main(String[] args) {

		SpringApplication springApplication = new SpringApplication(CBKBootApplication.class);
		springApplication.addListeners(new ApplicationPidFileWriter()); // register PID write to spring boot. It will
																		// write PID to file
		springApplication.setBannerMode(Mode.LOG);
		springApplication.run(args);

	}

}
