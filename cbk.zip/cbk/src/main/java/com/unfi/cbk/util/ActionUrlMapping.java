package com.unfi.cbk.util;

import java.util.HashMap;
import java.util.Map;

public class ActionUrlMapping {

	/*
	 * CBK
	 * 
	 */
	public static Map<String, String> HOMEACTION;
	public static Map<String, String> AVAILABLECHARGEBACKACTION;
	public static Map<String, String> CHARGEBACKNEWSEARCHACTION;
	public static Map<String, String> VENDORSELECTORACTIONS;
	public static Map<String, String> GLOBAL;
	public static Map<String, String> CHARGEBACKLOCATIONSELECTORACTIONS;
	public static Map<String, String> ORIGINATORSELECTORACTIONS;
	public static Map<String, String> APPROVERSELECTORACTIONS;
	public static Map<String, String> CHARGEBACKGETRESULTSACTION;
	public static Map<String, String> CHARGEBACKDETAILSACTIONS;
	public static Map<String, String> CHARGEBACKDETAILSPRINT;
	public static Map<String, String> CHARGEBACKCREATEACTIONS;
	public static Map<String, String> CHARGEBACKADMINACTION;
	public static Map<String, String> USERIDSELECTORACTIONS;
	public static Map<String, String> CHARGEBACKUPDATEACTIONS;
	public static Map<String, String> CBKAPPROVERSELECTORACTIONS;
	public static Map<String, String> CBKCREATEAPPROVERSELECTORACTIONS;
	public static Map<String, String> CBKIMPORTMASSAPPROVERSELECTORACTIONS;

	public static Map<String, String> CBKAPPROVERREASONACTIONS;

	// END

	public static Map<String, String> ERRORACTION;
	public static Map<String, String> DOCUMENTSEXPORTSEARCHRESULTSACTION;
	public static Map<String, String> PASSGETATTACHMENTACTION;
	public static Map<String, String> DOCUMENTSLOADDOCUMENTACTION;
	public static Map<String, String> LOADCHECKIMAGEACTION;
	public static Map<String, String> PRINTPASSDETAILSACTION;
	public static Map<String, String> DOCUMENTADDITIONALINFOACTION;
	public static Map<String, String> MAINTENANCEMENUACTION;
	public static Map<String, String> OPENCHARGEBACKSACTION;
	public static Map<String, String> MASSAPPROVALSACTIONS;
	public static Map<String, String> IMPORTCHARGEBACKSACTION;
	public static Map<String, String> IMPORTCHARGEBACKFILESELECTORACTION;
	public static Map<String, String> CHARGEBACKMANAGERACTION;
	public static Map<String, String> CHARGEBACKEXPORTACTION;
	public static Map<String, String> PARENTSEARCHSELECTORACTIONS;
	
	public static Map<String, String> CHARGEBACKREPORTACTION;
	public static Map<String, String> CHARGEBACKINTERFACEACTION;

	static {
		GLOBAL = new HashMap<>();
		GLOBAL.put("failure", "error.def");
		GLOBAL.put("error", "error.display.def");
	}

	static {
		ERRORACTION = new HashMap<>(GLOBAL);
		ERRORACTION.put("success", "errorPageDef");

	}

	static {
		MASSAPPROVALSACTIONS = new HashMap<>(GLOBAL);
		MASSAPPROVALSACTIONS.put("success", "massApprovals.search.def");
		MASSAPPROVALSACTIONS.put("error", "errorPageDef");
		MASSAPPROVALSACTIONS.put("other", "massApprovals.disabled.def");
		MASSAPPROVALSACTIONS.put("results", "massApprovals.result.def");

	}

	static {
		CHARGEBACKGETRESULTSACTION = new HashMap<>(GLOBAL);
		CHARGEBACKGETRESULTSACTION.put("success", "chargeback.results.def");
		CHARGEBACKGETRESULTSACTION.put("error", "errorPageDef");
		CHARGEBACKGETRESULTSACTION.put("other", "chargeback.disabled.def");
	}

	static {
		CHARGEBACKDETAILSACTIONS = new HashMap<>(GLOBAL);
		CHARGEBACKDETAILSACTIONS.put("success", "chargeback.details.def");
		CHARGEBACKDETAILSACTIONS.put("error", "errorPageDef");
		CHARGEBACKDETAILSACTIONS.put("other", "chargeback.disabled.def");
	}

	static {
		CHARGEBACKDETAILSPRINT = new HashMap<>(GLOBAL);
		CHARGEBACKDETAILSPRINT.put("success", "chargeback.print.def");
		CHARGEBACKDETAILSPRINT.put("error", "errorPageDef");
		CHARGEBACKDETAILSPRINT.put("other", "chargeback.disabled.def");
	}

	static {
		HOMEACTION = new HashMap<>(GLOBAL);
		HOMEACTION.put("home", "homePageDef");
		HOMEACTION.put("token", "homePageDef");
	}
	static {
		AVAILABLECHARGEBACKACTION = new HashMap<>(GLOBAL);
		AVAILABLECHARGEBACKACTION.put("success", "availableChargeback.results.def");
		AVAILABLECHARGEBACKACTION.put("error", "errorPageDef");
		AVAILABLECHARGEBACKACTION.put("other", "availableChargeback.disabled.def");
	}
	static {
		OPENCHARGEBACKSACTION = new HashMap<>(GLOBAL);
		OPENCHARGEBACKSACTION.put("success", "openChargebacks.results.def");
		OPENCHARGEBACKSACTION.put("error", "errorPageDef");
		OPENCHARGEBACKSACTION.put("other", "openChargebacks.disabled.def");
		IMPORTCHARGEBACKSACTION = new HashMap<>(GLOBAL);
		IMPORTCHARGEBACKSACTION.put("success", "importChargebacks.results.def");
		IMPORTCHARGEBACKSACTION.put("error", "error.def");
		IMPORTCHARGEBACKSACTION.put("other", "importChargebacks.disabled.def");

	}
	static {
		IMPORTCHARGEBACKFILESELECTORACTION = new HashMap<>(GLOBAL);
		IMPORTCHARGEBACKFILESELECTORACTION.put("open", "importfileselector.def");
		IMPORTCHARGEBACKFILESELECTORACTION.put("approver", "importChargebacksApprover.def");
	}

	static {
		CHARGEBACKCREATEACTIONS = new HashMap<>(GLOBAL);
		CHARGEBACKCREATEACTIONS.put("success", "chargeback.create.def");
		//CHARGEBACKCREATEACTIONS.put("validateAccount", "chargeback.validateAccount.def");
		CHARGEBACKCREATEACTIONS.put("error", "errorPageDef");
		CHARGEBACKCREATEACTIONS.put("other", "chargeback.disabled.def");
	}

	static {
		CHARGEBACKUPDATEACTIONS = new HashMap<>(GLOBAL);
		CHARGEBACKUPDATEACTIONS.put("success", "chargeback.update.def");
		CHARGEBACKUPDATEACTIONS.put("error", "errorPageDef");
		CHARGEBACKUPDATEACTIONS.put("other", "chargeback.disabled.def");
	}

	static {
		CHARGEBACKNEWSEARCHACTION = new HashMap<>(GLOBAL);
		CHARGEBACKNEWSEARCHACTION.put("success", "chargeback.search.page");

	}

	static {
		CHARGEBACKLOCATIONSELECTORACTIONS = new HashMap<>(GLOBAL);
		CHARGEBACKLOCATIONSELECTORACTIONS.put("open", "chargebackLocationSelector.def");
		CHARGEBACKLOCATIONSELECTORACTIONS.put("openLocName", "cbkManagerLocationSelector.def");
	}
	static {
		USERIDSELECTORACTIONS = new HashMap<>(GLOBAL);
		USERIDSELECTORACTIONS.put("open", "userIDSelector.def");
	}

	static {
		VENDORSELECTORACTIONS = new HashMap<>(GLOBAL);
		VENDORSELECTORACTIONS.put("open", "vendorselector.def");
	}

	static {
		ORIGINATORSELECTORACTIONS = new HashMap<>(GLOBAL);
		ORIGINATORSELECTORACTIONS.put("open", "originatorselector.def");
	}

	static {
		APPROVERSELECTORACTIONS = new HashMap<>(GLOBAL);
		APPROVERSELECTORACTIONS.put("open", "approverselector.def");
	}

	static {
		CBKAPPROVERSELECTORACTIONS = new HashMap<>(GLOBAL);
		CBKAPPROVERSELECTORACTIONS.put("open", "cbkApproverselector.def");
	}
	
	static {
		CBKCREATEAPPROVERSELECTORACTIONS = new HashMap<>(GLOBAL);
		CBKCREATEAPPROVERSELECTORACTIONS.put("open", "cbkCreateApproverselector.def");
	}
	
	static {
		CBKIMPORTMASSAPPROVERSELECTORACTIONS = new HashMap<>(GLOBAL);
		CBKIMPORTMASSAPPROVERSELECTORACTIONS.put("open", "cbkImportMassApproverselector.def");
	}


	static {
		CBKAPPROVERREASONACTIONS = new HashMap<>(GLOBAL);
		CBKAPPROVERREASONACTIONS.put("open", "cbkApproverReason.def");
	}

	static {
		CHARGEBACKADMINACTION = new HashMap<>(GLOBAL);
		CHARGEBACKADMINACTION.put("open", "adminMenu.def");
		CHARGEBACKADMINACTION.put("userSearch", "userSearch.def");
		CHARGEBACKADMINACTION.put("users", "users.def");
		CHARGEBACKADMINACTION.put("create", "createUser.def");
		CHARGEBACKADMINACTION.put("edit", "editUser.def");
		CHARGEBACKADMINACTION.put("createNewuser", "createUser1.def");
		CHARGEBACKADMINACTION.put("saveEditUser", "saveEditUser.def");
		CHARGEBACKADMINACTION.put("adminUserSearch", "adminUserSearch.def");
		CHARGEBACKADMINACTION.put("adminSearchResult", "adminSearchResult.def");
		CHARGEBACKADMINACTION.put("adminDetails", "adminDetails.def");
		CHARGEBACKADMINACTION.put("byAudits", "byChargebackAudit.def");
		CHARGEBACKADMINACTION.put("deleteUser", "deleteUserStatus.def");
		CHARGEBACKADMINACTION.put("submitSuccess", "submitSuccess.def");

	}

	static {
		DOCUMENTSLOADDOCUMENTACTION = new HashMap<>(GLOBAL);
		DOCUMENTSLOADDOCUMENTACTION.put("status", "document.load.def");
		DOCUMENTSLOADDOCUMENTACTION.put("sview", "document.load.sview.def");
		DOCUMENTSLOADDOCUMENTACTION.put("failure", "error.plain.def");

	}

	static {
		LOADCHECKIMAGEACTION = new HashMap<>(GLOBAL);
		LOADCHECKIMAGEACTION.put("status", "document.load.checkimageload");
		LOADCHECKIMAGEACTION.put("sview", "document.load.checkimage.def");
		LOADCHECKIMAGEACTION.put("failure", "error.plain.def");
	}

	static {
		PRINTPASSDETAILSACTION = new HashMap<>(GLOBAL);
		PRINTPASSDETAILSACTION.put("print", "pass.details.def.print");
		PRINTPASSDETAILSACTION.put("failure", "error.plain.def");
	}

	static {
		DOCUMENTADDITIONALINFOACTION = new HashMap<>(GLOBAL);
		DOCUMENTADDITIONALINFOACTION.put("success", "documentAdditionalInfo");
		DOCUMENTADDITIONALINFOACTION.put("failure", "error.display.def");
	}

	static {
		MAINTENANCEMENUACTION = new HashMap<>(GLOBAL);
		MAINTENANCEMENUACTION.put("success", "maint.menu.def");
	}

	static {
		CHARGEBACKMANAGERACTION = new HashMap<>(GLOBAL);
		CHARGEBACKMANAGERACTION.put("managerMenu", "managerMenu.def");
		CHARGEBACKMANAGERACTION.put("success", "workWithChargebackSearch.def");
		CHARGEBACKMANAGERACTION.put("workWithChargebackResults", "workWithChargebackResults.def");
		CHARGEBACKMANAGERACTION.put("other", "massApprovals.disabled.def");
		CHARGEBACKMANAGERACTION.put("cancelSelected", "cancelSelected.def");
		CHARGEBACKMANAGERACTION.put("chargeRoles", "chargeRoles.def");
		CHARGEBACKMANAGERACTION.put("productGroup", "productGroup.def");
		CHARGEBACKMANAGERACTION.put("auditLog", "auditLog.search.def");
		CHARGEBACKMANAGERACTION.put("cbkLocation", "cbkLocation.search.def");
		CHARGEBACKMANAGERACTION.put("createLocation", "createLocation.def");
		CHARGEBACKMANAGERACTION.put("deleteLocation", "deleteLocation.def");
		CHARGEBACKMANAGERACTION.put("editLocation", "editLocation.def");
		CHARGEBACKMANAGERACTION.put("productGroup", "productGroup.def");
		CHARGEBACKMANAGERACTION.put("createProduct", "createProduct.def");
		CHARGEBACKMANAGERACTION.put("editProduct", "editProduct.def");
		CHARGEBACKMANAGERACTION.put("deleteProduct", "deleteProduct.def");

		CHARGEBACKMANAGERACTION.put("cbkReasonSearch", "cbkReasonSearch.def");
		CHARGEBACKMANAGERACTION.put("createReason", "createReason.def");
		CHARGEBACKMANAGERACTION.put("editReason", "editReason.def");
		CHARGEBACKMANAGERACTION.put("deleteReason", "deleteReason.def");
		CHARGEBACKMANAGERACTION.put("cbkByType", "cbkByType.def");
		CHARGEBACKMANAGERACTION.put("createByType", "createByType.def");
		CHARGEBACKMANAGERACTION.put("editType", "editType.def");
		CHARGEBACKMANAGERACTION.put("searchCbkRole", "searchCbkRole.def");
		CHARGEBACKMANAGERACTION.put("createByRole", "createByRole.def");
		CHARGEBACKMANAGERACTION.put("editByRoel","editByRoel.def");

		CHARGEBACKMANAGERACTION.put("exclVendor", "exclVendor.def");
		CHARGEBACKMANAGERACTION.put("createVendor", "createVendor.def");
		CHARGEBACKMANAGERACTION.put("editVendor", "editVendor.def");
		CHARGEBACKMANAGERACTION.put("deleteVendor", "deleteVendor.def");

		CHARGEBACKMANAGERACTION.put("routeAppr", "routeAppr.def");
		CHARGEBACKMANAGERACTION.put("createRoutingAppr", "createRoutingAppr.def");
		CHARGEBACKMANAGERACTION.put("editRoutingAppr", "editRoutingAppr.def");
		

		CHARGEBACKMANAGERACTION.put("routePage", "routePage.def");
		CHARGEBACKMANAGERACTION.put("createRoutePage", "createRoutePage.def");
		CHARGEBACKMANAGERACTION.put("editRoute", "editRoute.def");
		CHARGEBACKMANAGERACTION.put("deleteRoute", "deleteRoute.def");
		CHARGEBACKMANAGERACTION.put("chargebackDef", "chargebackDef.def");
		CHARGEBACKMANAGERACTION.put("managerUserSearch", "managerUserSearch.def");
		CHARGEBACKMANAGERACTION.put("managerUsers", "managerUsers.def");
		CHARGEBACKMANAGERACTION.put("managerUserDetails", "managerUserDetails.def");
		CHARGEBACKMANAGERACTION.put("workWithCbkDetails", "workWithCbkDetails.def");
	}
	
	static {
		CHARGEBACKREPORTACTION = new HashMap<>(GLOBAL);
		CHARGEBACKREPORTACTION.put("byChargeReport", "byChargeReport.def");
	}
	
	static {
		PARENTSEARCHSELECTORACTIONS = new HashMap<>(GLOBAL);
		PARENTSEARCHSELECTORACTIONS.put("open", "parentSearchSelector.def");
	}
	
	static {
		CHARGEBACKEXPORTACTION = new HashMap<>(GLOBAL);
		CHARGEBACKEXPORTACTION.put("exportMenu", "exportMenu.def");
		CHARGEBACKEXPORTACTION.put("byAuditLog", "byAuditLog.def");
		CHARGEBACKEXPORTACTION.put("previewExportResult", "previewExportResult.def");
		CHARGEBACKEXPORTACTION.put("updateDueDateResults", "updateDueDateResults.def");
		CHARGEBACKEXPORTACTION.put("agedChargebackReport", "agedChargebackReport.search.def");
	}
	static {
		CHARGEBACKINTERFACEACTION = new HashMap<>(GLOBAL);
		CHARGEBACKINTERFACEACTION.put("confirm", "confirm.def");
		CHARGEBACKINTERFACEACTION.put("success", "success.def");
	}

}
