package com.unfi.cbk.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

/**
 * @author yhp6y2l
 *
 */
public class PhoneNbrUtils {
	public static final String PHONE_NBR_PATTERN[] = { "(-| -|- | )", "\\(", "\\)", "\\ " };
	static Logger log = Logger.getLogger(StringFunctions.class);

	/**
	 * method: parsePhoneNbr param: candidateString - phone or fax number to be
	 * parsed. return: String - Returns phone number without any character seperator
	 * or spaces. Description: This method bascially replace the character
	 * seperators or spaces from the phone or fax number and return the number. Eg:
	 * Input 952-877-0998 and Output 9528770998
	 */
	public static String eliminateNbrSeperator(String candidateString) {
		String phoneNumber = candidateString != null ? candidateString : "";
		if (phoneNumber != null && !phoneNumber.equals("")) {
			int i = 0;
			while (i < PHONE_NBR_PATTERN.length) {
				Pattern p = Pattern.compile(PHONE_NBR_PATTERN[i]);
				// create the candidate String
				Matcher matcher = p.matcher(phoneNumber);
				phoneNumber = matcher.replaceAll("");
				i++;
			}
		}
		return phoneNumber.toString();
	}

	public static String getNbrPrfx(String number) {
		String nbrPrefix = "";
		if (number != null && !number.equals("")) {
			nbrPrefix = eliminateNbrSeperator(number);
			if (nbrPrefix != null && nbrPrefix.length() > 3)
				nbrPrefix = nbrPrefix.substring(0, 3);
		}
		return nbrPrefix;
	}

	public static String getNbr(String number) {
		String nbr = "";
		if (number != null && !number.equals("")) {
			nbr = eliminateNbrSeperator(number);
			if (nbr != null && nbr.length() > 3)
				nbr = nbr.substring(3, nbr.length());
		}
		return nbr;
	}

	/*
	 * param - phone/fax number without prefix (eg: 7889876) returns the formatted
	 * number (788-9876)
	 */
	public static String getFormattedPhoneNbr(String number) {
		StringBuffer fmtNbr = new StringBuffer();
		if (number != null && !number.equals("")) {
			number = eliminateNbrSeperator(number);
			if (number != null && number.length() > 6) {
				fmtNbr.append(number.substring(0, 3));
				fmtNbr.append("-");
				fmtNbr.append(number.substring(3, number.length()));
			} else
				fmtNbr.append(number);
		}
		return fmtNbr.toString();
	}
}
