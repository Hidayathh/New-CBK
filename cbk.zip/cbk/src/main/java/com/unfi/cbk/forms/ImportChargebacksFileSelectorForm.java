package com.unfi.cbk.forms;

public class ImportChargebacksFileSelectorForm {

	private String fileName;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

}
