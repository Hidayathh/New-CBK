package com.unfi.cbk.dao;

import java.util.List;
import java.util.Map;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.exceptions.DataAccessException;

/**
 * The ChargebackSearchDao interface creates the bridge between the caller and
 * the actual work in retrieving the data.
 *
 * @author yhp6y2l
 * @since 1.0
 */

public interface ChargebackExportDao {

 
    public ResultList getTypeAmount(Map map) throws DataAccessException;
    
    public ResultList previewExportResults() throws DataAccessException;
    
    public ResultList agedChargebackReportSearch(Map searchParametersFrom) throws DataAccessException;

    public ResultList updateDuedate() throws DataAccessException;
    
    public void updateChargebackDueDate(ChargebackBO chargeBack) throws DataAccessException;
    
    
    public void insertExpType() throws DataAccessException;
	
	public void insertExpReasons() throws DataAccessException;
	
	public void insertExpAvailableExports() throws DataAccessException;
	
	public void insertExpChargeback() throws DataAccessException;
	
	public void insertExpDistribution() throws DataAccessException;
	
	public void insertExpItem() throws DataAccessException;

	public void insertExpApprovals() throws DataAccessException;
	
	public void insertExpDistRecords() throws DataAccessException;

	public void insertExpDetail() throws DataAccessException;
	
	public void insertExpNotExported() throws DataAccessException;
	
    public void insertCvdDistExport() throws DataAccessException;
	
	public void updateChargebackExportorNot(String  exportedStatus) throws DataAccessException;
	
	public void deleteExpType() throws DataAccessException;
	
	public void deleteExpReasons() throws DataAccessException;
	
	public void deleteExpAvailableExports() throws DataAccessException;
	
	public void deleteExpChargeback() throws DataAccessException;
	
	public void deleteExpDistribution() throws DataAccessException;
	
	public void deleteExpItem() throws DataAccessException;
	
	public void deleteExpApprovals() throws DataAccessException;
	
	public void deleteExpDistRecords() throws DataAccessException;

	public void deleteExpDetail() throws DataAccessException;
	
	public void deleteExpNotExported() throws DataAccessException;

	public void deleteExpCviInvExport() throws DataAccessException;
	
	public void deleteExpFundsRecords() throws DataAccessException;
	
	public List getExportId(String date)throws DataAccessException;


}
