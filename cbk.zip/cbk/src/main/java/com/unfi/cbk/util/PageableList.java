package com.unfi.cbk.util;

import java.util.List;

/**
 * @author yhp6y2l
 * @version 1.0
 */
public class PageableList {

	private List list;
	private int displayCount;

	/**
	 * @param l
	 * @param c
	 */
	public PageableList(List l, int c) {
		list = l;
		displayCount = c;
	}

	/**
	 * @param startIndex
	 * @return
	 */
	public List getPage(int startIndex) {

		startIndex--;
		if (startIndex < 0) {
			startIndex = 0;
		}

		int endIndex = startIndex + displayCount;

		if (endIndex > list.size()) {
			endIndex = list.size();
		}

		return list.subList(startIndex, endIndex);
	}
}
