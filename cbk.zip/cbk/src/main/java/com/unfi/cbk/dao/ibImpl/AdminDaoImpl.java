package com.unfi.cbk.dao.ibImpl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.bo.CreateNewUserBO;
import com.unfi.cbk.dao.AdminDao;
import com.unfi.cbk.exceptions.DataAccessException;

/**
 * The AdminDataDaoImpl class handles the call to the database to get the
 * results of the chargebacks search based on the form values.
 *
 * @author vpil001
 * @since 1.0
 */

public class AdminDaoImpl extends SqlMapClientDaoSupport implements AdminDao {

	private static Logger log = Logger.getLogger(AdminDaoImpl.class);
	protected static Date BAD_DATE = null;

	public AdminDaoImpl(SqlMapClientTemplate sqlMapTemplate) {
		this.setSqlMapClientTemplate(sqlMapTemplate);
	}

	/**
	 * 
	 */

	public ResultList getChargebacks(Map formSearchValuesMap) throws DataAccessException {
		ResultList rL = new ResultList();

		try {

			System.out.println("------AdminDataDaoImpl.java-------getChargebacks()------");
			System.out.println("---status::" + formSearchValuesMap.get("status"));
			System.out.println("---apStatus::" + formSearchValuesMap.get("apStatus"));

			rL.setList((List<Integer>) getSqlMapClientTemplate().queryForList("AdminData.getChargebacks",
					formSearchValuesMap));
			System.out.println("------------AdminDataDaoImpl.java--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			} else if (formSearchValuesMap.get("showAll") != null
					&& ((String) formSearchValuesMap.get("showAll")).equals("true")) {
				rL.setTotalCount(new Integer(rL.getList().size()));
			} else {
				rL.setTotalCount((Integer) getSqlMapClientTemplate().queryForObject("AdminData.getChargebacksCount",
						formSearchValuesMap));
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getChargebacks() " + e);
			throw new DataAccessException(e);
		}

		return rL;
	}

	/**
	 * 
	 */
	public ResultList getAvailableChargebacks(Map formSearchValuesMap) throws DataAccessException {
		ResultList rL = new ResultList();

		try {

			System.out.println("------AdminDataDaoImpl.java-------getAvailableChargebacks()------");
			rL.setList((List<Integer>) getSqlMapClientTemplate().queryForList("AdminData.getAvailableChargebacks",
					formSearchValuesMap));
			System.out.println("------------AdminDataDaoImpl.java--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			} else if (formSearchValuesMap.get("showAll") != null
					&& ((String) formSearchValuesMap.get("showAll")).equals("true")) {
				rL.setTotalCount(new Integer(rL.getList().size()));
			} else {
				rL.setTotalCount((Integer) getSqlMapClientTemplate()
						.queryForObject("AdminData.getAvailableChargebacksCount", formSearchValuesMap));
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getAvailableChargebacks() " + e);
			throw new DataAccessException(e);
		}
		return rL;
	}

	@Override
	public CreateNewUserBO getUserDetails(String userId) throws DataAccessException {
		CreateNewUserBO c = null;

		try {

			HashMap map = new HashMap();
			System.out.println("------in AdminDaoImpl---getUserDetails()-------");
			map.put("userId", userId);
			c = (CreateNewUserBO) getSqlMapClientTemplate().queryForObject("AdminData.getUserDetails", map);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

		// checkIfNull(c);
		return c;

	}

	/* For AuditDetails */

	public ResultList getTypeAmount(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		ResultList rL = new ResultList();

		try {

			System.out.println("------AdminDaoImpl.java-------GetTypeAmount()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("AdminData.getTypeAmount", map));
			System.out.println("------------AdminDaoImpl.java--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getTypeAmount() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}
		return rL;

	}

	/* For AdminDetails */

	@Override
	public List getLocations() throws DataAccessException {
		List l = null;
		try {
			// HashMap map = new HashMap();
			System.out.println("------in Impl---getLocations()-------");
			l = (List) getSqlMapClientTemplate().queryForList("AdminData.getLocations");
			System.out.println("------------AdminDaoImpl.java-getLocations---List size----" + l.size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return l;
	}

	@Override
	public List getRoles() throws DataAccessException {
		// TODO Auto-generated method stub

		List l = null;
		try {
			// HashMap map = new HashMap();
			System.out.println("------in Impl---getRoles()-------");
			l = (List) getSqlMapClientTemplate().queryForList("AdminData.getRoles");
			System.out.println("------------AdminDaoImpl.java-getRoles---List size----" + l.size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return l;
	}

	@Override
	public List<CreateNewUserBO> getRolesByUserForMenu() throws DataAccessException {
		// TODO Auto-generated method stub
		List<CreateNewUserBO> l = null;
		try {
			// HashMap map = new HashMap();
			System.out.println("------in Impl---getRolesByUserForMenu()-------");
			l = (List) getSqlMapClientTemplate().queryForList("AdminData.getRolesByUserForMenuAccess");
			System.out.println("------------AdminDaoImpl.java-getRolesByUserForMenu---List size----" + l.size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return l;
	}

	public HashMap getRolesByUserForMenu(Map formSearchValuesMap) throws DataAccessException {

		List menuLinkList = null;
		HashMap map = new HashMap();
		try {

			menuLinkList = getSqlMapClientTemplate().queryForList("AdminData.getRolesByUserForMenu",
					formSearchValuesMap);
			for (int i = 0; i < menuLinkList.size(); i++) {

				map.put(i, menuLinkList.get(i));
			}

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
		// checkIfNull(s);
		return map;
	}

	@Override
	public ResultList adminResults(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		ResultList rL = new ResultList();

		try {

			System.out.println("------AdminDaoImpl.java-------adminResults()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("AdminData.adminResults", map));
			System.out.println("------------AdminDaoImpl.java--adminResults ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			} else if (map.get("showAll") != null && ((String) map.get("showAll")).equals("true")) {
				rL.setTotalCount(new Integer(rL.getList().size()));
			} else {
				rL.setTotalCount(
						(Integer) getSqlMapClientTemplate().queryForObject("AdminData.adminResultsCount", map));
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in adminResults() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

		return rL;
	}

	@Override
	public ResultList userDetails(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		ResultList rL = new ResultList();

		try {

			System.out.println("------AdminDaoImpl.java-------userDetails()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("AdminData.userDetails", map));
			System.out.println("------------AdminDaoImpl.java--userDetails ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in userDetails() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

		return rL;
	}

	@Override
	public void createCbkDistribution(List list) throws DataAccessException {
		// TODO Auto-generated method stub
		ChargebackBO chargeback = null;
		try {
			for (int i = 0; i < list.size(); i++) {
				System.out.println("---AdminDataDaoImpl.java.java---createCbkDistribution--");

				ChargebackBO cbkBO = (ChargebackBO) list.get(i);
				getSqlMapClientTemplate().insert("AdminData.insertCbkDistribution", cbkBO);
				System.out.println("----INSERTED DISTRIBUTION ITEM ROW ----" + i);
			}
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	@Override
	public void createCbkItem(ChargebackBO cbkBO) throws DataAccessException {

		try {
			getSqlMapClientTemplate().insert("AdminData.insertCbkItem", cbkBO);
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	@Override
	public void createChargeback(ChargebackBO chargeBack) throws DataAccessException {
		try {
			getSqlMapClientTemplate().insert("AdminData.insertChargeback", chargeBack);
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	@Override
	public void updateInvoice(ChargebackBO cbkBo) throws DataAccessException {
		// TODO Auto-generated method stub
		try {
			getSqlMapClientTemplate().insert("ChargebackSearch.updateInvoice", cbkBo);
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

	}

	@Override
	public void createAttachment(ChargebackBO chargebackBO) throws DataAccessException {
		try {
			getSqlMapClientTemplate().insert("ChargebackSearch.crateAttachment", chargebackBO);
			// attachment.setId(i.intValue());

		} catch (Exception e) {
			log.error("Error in createAttachment() " + e);
			// e.printStackTrace();
			throw new DataAccessException(e);
		}
	}

	@Override
	public ResultList getUserRolesLocations(String userId) throws DataAccessException {
		ResultList rL = new ResultList();
		try {

			HashMap map = new HashMap();
			System.out.println("------in Impl---getUserRolesLocations()-------");
			map.put("userId", userId);
			rL.setList((List) getSqlMapClientTemplate().queryForList("AdminData.getUserRolesLocations", map));

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
		// checkIfNull(l);
		return rL;
	}

	@Override
	public List balanceAccrual(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		List l = null;

		try {

			System.out.println("------AdminDaoImpl.java-------balanceAccrual()------");
			l=(List) getSqlMapClientTemplate().queryForList("AdminData.balanceAccrual", map);
			System.out.println("------------AdminDaoImpl.java--ResultList size----" +l.size());
			
			

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in balanceAccrual() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

		return l;
	}

	@Override
	public List getAccrualsList(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		List l = null;
		try {
			// HashMap map = new HashMap();
			System.out.println("------in Impl---getAccuralsList()-------");
			l = (List) getSqlMapClientTemplate().queryForList("AdminData.getAccruals", map);
			System.out.println("------------AdminDaoImpl.java-getAccuralsList---List size----" + l.size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return l;
	}


	@Override
	public List getExportId(String date) throws DataAccessException {
		// TODO Auto-generated method stub
		List<String> l = null;
		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("date", date);
			l = (List) getSqlMapClientTemplate().queryForList("AdminData.getExportId", map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		
		
		return l;
	}

}