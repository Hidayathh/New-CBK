package com.unfi.cbk.forms;

import java.util.List;

public class ParentSearchSelectorForm {

	private Integer results = null;

	private List searchResults = null;
	private String selectedResult = null;
	
	private String parentName = null;
	private String parentNumber = null;

	/**
	 * @return
	 */
	public Integer getResults() {
		return results;
	}

	/**
	 * @return
	 */
	public List getSearchResults() {
		return searchResults;
	}

	/**
	 * @return
	 */
	public String getSelectedResult() {
		return selectedResult;
	}

	/**
	 * @return
	 */

	/**
	 * @param i
	 */
	public void setResults(Integer i) {
		results = i;
	}

	/**
	 * @param list
	 */
	public void setSearchResults(List list) {
		searchResults = list;
	}

	/**
	 * @param string
	 */
	public void setSelectedResult(String string) {
		selectedResult = string;
	}

	/**
	 * @param string
	 */

	public String getParentName() {
		return parentName;
	}

	public void setParentName(String parentName) {
		this.parentName = parentName;
	}

	public String getParentNumber() {
		return parentNumber;
	}

	public void setParentNumber(String parentNumber) {
		this.parentNumber = parentNumber;
	}

}
