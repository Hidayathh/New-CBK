package com.unfi.cbk.dao.ibImpl;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.unfi.cbk.dao.ChargebackCommonDao;
import com.unfi.cbk.exceptions.DataAccessException;

/**
 * The ChargebackCommonDaoImpl class implements the generic ChargebackCommonDao
 * interface.
 * 
 * @author vpil001
 * @version 1.0
 */

public class ChargebackCommonDaoImpl extends SqlMapClientDaoSupport implements ChargebackCommonDao {

	static Logger log = Logger.getLogger(ChargebackCommonDaoImpl.class);

	/**
	 * @param sqlMapTemplate
	 */
	public ChargebackCommonDaoImpl(SqlMapClientTemplate sqlMapTemplate) {
		this.setSqlMapClientTemplate(sqlMapTemplate);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.unfi.cbk.dao.ChargebackCommonDao#doVendorSearch(java.lang.String,
	 * java.lang.String)
	 */
	public List doVendorSearch(String vendorNumber, String vendorName) throws DataAccessException {
		List l = null;

		try {
			System.out.println("--------ChargebackCommomDaoImpl.java-------doVendorSearch()---");
			HashMap map = new HashMap();
			map.put("vendorNumber", vendorNumber.replace('*', '%'));
			map.put("vendorName", vendorName.replace('*', '%').toUpperCase());

			l = getSqlMapClientTemplate().queryForList("ChargebackCommon.doVendorSearch", map);
		} catch (Exception e) {
			throw new DataAccessException(e);
		}

		return l;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.unfi.cbk.dao.ChargebackCommonDao#doLocationSearch(java.lang.String,
	 * java.lang.String)
	 */
	public List doLocationSearch(String locationNumber, String locationName) throws DataAccessException {
		List l = null;

		try {
			System.out.println("--------ChargebackCommomDaoImpl.java-------doLocationSearch()---");
			HashMap map = new HashMap();
			map.put("locationNumber", locationNumber.replace('*', '%'));
			map.put("locationName", locationName.replace('*', '%').toUpperCase());

			l = getSqlMapClientTemplate().queryForList("ChargebackCommon.doLocationSearch", map);
		} catch (Exception e) {
			throw new DataAccessException(e);
		}

		return l;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.unfi.cbk.dao.ChargebackCommonDao#doOriginatorSearch(java.lang.String,
	 * java.lang.String)
	 */
	public List doOriginatorSearch(String userId, String userName) throws DataAccessException {
		List l = null;

		try {
			System.out.println(
					"--------ChargebackCommomDaoImpl.java-------doOriginatorSearch()---" + userId + ":::" + userName);
			HashMap map = new HashMap();
			map.put("userId", userId.replace('*', '%'));
			map.put("userName", userName.replace('*', '%').toUpperCase());

			l = getSqlMapClientTemplate().queryForList("ChargebackCommon.doOriginatorSearch", map);
		} catch (Exception e) {
			throw new DataAccessException(e);
		}

		return l;
	}

	/* (non-Javadoc)
     * @see com.unfi.cbk.dao.ChargebackCommonDao#doNextApproverSearch(java.lang.String, java.lang.String)
     */
    public List doNextApproverSearch(String userId, String userName) throws DataAccessException {
        List l = null;
        
        try {
        	System.out.println("--------ChargebackCommomDaoImpl.java-------doNextApproverSearch()---"+userId+":::"+userName);
            HashMap map = new HashMap();
            map.put("userId", userId.replace('*', '%'));
            map.put("userName", userName.replace('*', '%').toUpperCase());
        
            l = getSqlMapClientTemplate().queryForList("ChargebackCommon.doNextApproverSearch", map);
        }
        catch (Exception e) {
            throw new DataAccessException(e);
        }
        
        return l;         
	}
    
	@Override
	public List doParentSearch(String parentNumber, String parentName) throws DataAccessException {
		List l = null;

		try {
			System.out.println("--------ChargebackCommomDaoImpl.java-------doParentSearch()---");
			HashMap map = new HashMap();
			map.put("parentNumber", parentNumber.replace('*', '%'));
			map.put("parentName", parentName.replace('*', '%').toUpperCase());

			l = getSqlMapClientTemplate().queryForList("ChargebackCommon.doParentSearch", map);
		} catch (Exception e) {
			throw new DataAccessException(e);
		}

		return l;
	}


}