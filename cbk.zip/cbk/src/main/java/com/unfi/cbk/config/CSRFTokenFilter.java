/**
 * 
 */
package com.unfi.cbk.config;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

/**
 * @author yhp6y2l
 *
 */
@Component
public class CSRFTokenFilter implements HandlerInterceptor {

	private static final String SAMEORIGIN = "SAMEORIGIN";
	private static final String ALLOWORIGIN = "*";
	private static final String POST_METHOD = "POST";
	private static final String PUT_METHOD = "PUT";
	private static final String DELETE_METHOD = "DELETE";
	private static final String OPTIONS_METHOD = "OPTIONS";

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {


		if (response.getStatus() == HttpServletResponse.SC_FORBIDDEN
				|| response.getStatus() == HttpServletResponse.SC_METHOD_NOT_ALLOWED
				|| response.getStatus() == HttpServletResponse.SC_NOT_FOUND) {
			return true;
		}

		response.addHeader("X-Frame-Options", SAMEORIGIN);

		response.addHeader("Access-Control-Allow-Origin", ALLOWORIGIN);

		if (request.getMethod().equalsIgnoreCase(OPTIONS_METHOD) || request.getMethod().equalsIgnoreCase(DELETE_METHOD)
				|| request.getMethod().equalsIgnoreCase(PUT_METHOD)) {
			response.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
			return false;
		}

		String csrfToken = CookieUtil.readCookie(request, CSRFToken._CSRF);


		if (csrfToken == null || csrfToken.isEmpty()) {
			csrfToken = (String) request.getSession().getAttribute(CSRFToken._CSRF);
		}

		if (csrfToken == null) {

			csrfToken = UUID.randomUUID().toString();
			CookieUtil.updateCookie(response, CSRFToken._CSRF, csrfToken);
			request.getSession().setAttribute(CSRFToken._CSRF, csrfToken);

		}

		if (!csrfTokenCheck(request)) {
			response.sendError(HttpServletResponse.SC_FORBIDDEN);
			return false;
		}

		CSRFToken token = new CSRFToken();
		token.setParameterName(CSRFToken._CSRF);
		token.setToken(csrfToken);
		request.setAttribute(CSRFToken._CSRF, token);


		return true;

	}

	public boolean csrfTokenCheck(HttpServletRequest request) throws IOException {

		// boolean isCsrfTokenValid = false;

		if (!request.getMethod().equalsIgnoreCase(POST_METHOD)) {
			// Not a POST - allow the request
			return true;

		}
		// This is a POST request - need to check the CSRF token
		String sessionOrCookieToken = CookieUtil.readCookie(request, CSRFToken._CSRF);
		if (sessionOrCookieToken == null) {
			sessionOrCookieToken = (String) request.getSession().getAttribute(CSRFToken._CSRF);
		}
		String requestToken = request.getParameter(CSRFToken._CSRF);
		if (requestToken == null) {
			CSRFToken csrfTokenObject = (CSRFToken) request.getAttribute(CSRFToken._CSRF);
			if (csrfTokenObject != null) {
				requestToken = csrfTokenObject.getToken();
			}
		}
		if (sessionOrCookieToken.equals(requestToken)) {
			return true;

		}
		return false;

	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {

	}
}
