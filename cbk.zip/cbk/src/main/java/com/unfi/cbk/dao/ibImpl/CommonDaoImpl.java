package com.unfi.cbk.dao.ibImpl;

import java.util.List;

import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.dao.CommonDao;
import com.unfi.cbk.exceptions.DataAccessException;

/**
 * iBATIS SQL Maps implementation of the CommonDao.
 * 
 * @author
 * @version 3.0
 */
public class CommonDaoImpl extends SqlMapClientDaoSupport implements CommonDao {

	public CommonDaoImpl(SqlMapClientTemplate sqlMapTemplate) {
		this.setSqlMapClientTemplate(sqlMapTemplate);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.unfi.cbk.dao.CommonDao#getAssignees()
	 */
	public ResultList getAssigneesForGroupId(int groupID) throws DataAccessException {
		ResultList rL = new ResultList();

		try {
			List l = getSqlMapClientTemplate().queryForList("Common.getAssigneesForGroupId", new Integer(groupID));
			rL.setList(l);
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			} else {
				rL.setTotalCount(new Integer(10));
			}
		} catch (Exception e) {
			throw new DataAccessException(e);
		}

		checkIfNull(rL);
		return rL;
	}

	/**
	 * Check if an object is null and throw a DataAccessException if it is.
	 * 
	 * @param o the object to test
	 * @throws DataAccessException whenever the object is null
	 */
	private void checkIfNull(Object o) throws DataAccessException {
		if (o == null) {
			throw new DataAccessException("Object not found.");
		}
	}
}
