package com.unfi.cbk.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;

/**
 * The DateFunctions class is a utility class for performing date functions
 * needed by other classes. All methods are static.
 *
 * @author yhp6y2l
 * @since 1.0
 */
public class DateFunctions {

	public static final String DATE_FORMAT = "MM/dd/yyyy hh:mm:ss zzz";
	public static final String DATE_FORMAT_COMMENT = "MM/dd/yyyy hh:mm:ss z";
	public static final String DATE_FORMAT_FOR_UPDATE = "MM/dd/yyyy hh:mm:ss";

	private static final String formatsToTry[] = { "M/d/yy", "M/d/yyyy", "MM/dd/yyyy", "M-d-yy", "M-d-yyyy",
			"EEEE MMMM d h:mm:ss zzzz yyyy", "MMM d, yyyy", "d-MMM-yyyy", "yyyy-MM-dd", "M/d/yyyy h:m:s a",
			"dd MMM yyyy h:m:s a","MMddyyyy" };
	
	static Logger log = Logger.getLogger(DateFunctions.class);

	public static String chargebackDateConversion(String date) {
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat formatter1 = new SimpleDateFormat("dd-MMM-yyyy");

		Date dt;
		String newDate = null;
		try {
			dt = formatter.parse(date);
			newDate = formatter1.format(dt);
			System.out.println("newDate--" + newDate);

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return newDate;
	}

	/**
	 * Adds the given number of days to the current date. This method adds (or
	 * subtracts if negative) the number of days specified by <code>days</code> and
	 * returns a formatted string.
	 * 
	 * @return a date <code>String</code> in the format mm/dd/yyyy
	 * @param days an <code>int</code> that determines how many days to add (or
	 *             subtract)
	 * @since 1.0
	 */
	public static String adjustCurrentDate(int days) {
		DateFormat formatPreference = new SimpleDateFormat("MM/dd/yyyy");
		Calendar adjustDate = Calendar.getInstance();
		adjustDate.add(Calendar.DATE, days);

		Date newDate = adjustDate.getTime();

		// log.info("new date:" + formatPreference.format(newDate));
		return formatPreference.format(newDate);

	}

	/**
	 * Adds the given number of days to the current date. This method adds (or
	 * subtracts if negative) the number of days specified by <code>days</code> and
	 * returns a formatted string.
	 * 
	 * @return a <code>Date</code> object representing the adjusted date
	 * @param days an <code>int</code> that determines how many days to add (or
	 *             subtract)
	 * @since 1.0
	 */
	public static Date adjustCurrentDateByDaysNoFormat(int days) {
		Calendar adjustDate = Calendar.getInstance();
		adjustDate.add(Calendar.DATE, days);

		Date newDate = adjustDate.getTime();

		// log.info("new date:" + newDate);
		return newDate;

	}

	/**
	 * Adds the given number of years to the current date This method adds (or
	 * subtracts if negative) the number of years specified by <code>years</code>
	 * and returns a <code>Date</code> object.
	 * 
	 * @return a <code>Date</code> object representing the adjusted date
	 * @param years an <code>int</code> that determines how many years to add (or
	 *              subtract)
	 * @since 1.0
	 */
	public static Date adjustCurrentDateNoFormat(int years) {
		Calendar adjustDate = Calendar.getInstance();
		adjustDate.add(Calendar.YEAR, years);

		Date newDate = adjustDate.getTime();

		// log.info("new date:" + newDate);
		return newDate;

	}

	/**
	 * Compares two dates. This method takes two <code>Date</code> objects and
	 * compares them. If date1 is equal to date2, a 0 is returned. If date1 is
	 * before date2, a negative value is returned. If date1 is after date2, a
	 * positive value is returned.
	 * 
	 * @return An <code>int</code> whose sign signifies the comparison.
	 * @param date1 the first date to be compared
	 * @param date2 the second date to be compared
	 * @since 1.0
	 */
	public static int compareDates(Date date1, Date date2) {
		// This method returns the value 0 if date1 is equal to date2;
		// a value less than 0 if date1 is before date2;
		// and a value greater than 0 if date1 is after date2.

		return date1.compareTo(date2);

	}

	public static int dateDifference(Date date1, Date date2) {
		int ret = 0;
		if (date1 != null && date2 != null) {
			final long msPerDay = 1000 * 60 * 60 * 24;

			final long date1Milliseconds = date1.getTime();
			final long date2Milliseconds = date2.getTime();
			final long result = (date2Milliseconds - date1Milliseconds) / msPerDay;

			ret = Integer.parseInt(String.valueOf(result));
		}
		return ret;
	}

	public static String getDB2TimestampFormat(Date dte) {
		DateFormat fmt = null;
		String formattedDate = null;
		try {
			if (dte != null) {
				fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
				formattedDate = fmt.format(dte);
			}
		} catch (Exception e) {
			// ignore
		} finally {
			//return formattedDate;
		}
		return formattedDate;
	}

	public static String getDB2DateFormat(Date dte) {
		DateFormat fmt = null;
		String formattedDate = null;
		try {
			if (dte != null) {
				fmt = new SimpleDateFormat("yyyy-MM-dd");
				formattedDate = fmt.format(dte);
			}
		} catch (Exception e) {
			// ignore
		} finally {
			//return formattedDate;
		}
		
		return formattedDate;
	}

	public static String getFormattedTodayTime() {
		DateFormat formatPreference = new SimpleDateFormat("yyyyddMMhhmmssSSS");
		return formatPreference.format(new Date());
	}

	/**
	 * Gets today's date in the format mm/dd/yyyy.
	 * 
	 * @return a <code>String</code> of today's date in the format mm/dd/yyyy.
	 * @since 1.0
	 */
	public static String getToday() {
		DateFormat formatPreference = new SimpleDateFormat("MM/dd/yyyy");
		return formatPreference.format(new Date());
	}

	/**
	 * Gets today's date and time in the format mm/dd/yyyy hh:mm (am/pm).
	 * 
	 * @return a <code>String</code> of today's date & time in the format mm/dd/yyyy
	 *         hh:mm (am/pm).
	 * @since 1.0
	 */
	public static String getTodayTime() {
		DateFormat formatPreference = new SimpleDateFormat("MM/dd/yyyy hh:mm a");
		return formatPreference.format(new Date());
	}

	/**
	 * Reformats a date string to the format mm/dd/yyyy from the database format of
	 * yyyy-mm-dd. Dates in the database exist in the format of yyyy-mm-dd and the
	 * display pages require dates be in the format of mm/dd/yyyy. This method takes
	 * the database date string as converts it to the mm/dd/yyyy format.
	 * 
	 * @return a <code>String</code> of the formatted date
	 * @param dateText the date string to be formatted
	 * @since 1.0
	 */
	public static String formatDatabaseDate(String dateText) {
		SimpleDateFormat formatPreference = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date thisDate = new Date();

		try {
			if (dateText != null) {
				thisDate = formatPreference.parse(dateText);

			} else {
				return "";

			}

		} catch (Exception e) {
			// Invalid Date
			log.warn("invalid format: " + dateText);
			return "";

		}

		formatPreference.applyPattern("MM/dd/yyyy");
		return formatPreference.format(thisDate);

	}

	/**
	 * Reformats a date/time string to the format mm/dd/yyyy hh:mm:ss from the
	 * database format of yyyy-mm-dd. Dates in the database exist in the format of
	 * yyyy-mm-dd and the display pages require dates be in the format of
	 * mm/dd/yyyy. This method takes the database date string as converts it to the
	 * mm/dd/yyyy format.
	 * 
	 * @return a <code>String</code> of the formatted date
	 * @param dateText the date string to be formatted
	 * @since 1.0
	 */
	public static String formatDatabaseDateTime(String dateTimeText) {
		SimpleDateFormat formatPreference = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		java.util.Date thisDate = new Date();

		try {
			thisDate = formatPreference.parse(dateTimeText);

		} catch (Exception e) {
			// Invalid Date
			log.warn("invalid format: " + dateTimeText);
			return "";

		}

		formatPreference.applyPattern("MM/dd/yyyy hh:mm:ss a");
		return formatPreference.format(thisDate);

	}

	public static String formatDate(Date dte) {
		DateFormat fmt = null;
		String fmDate = null;
		try {
			if (dte != null) {
				fmt = new SimpleDateFormat("MM/dd/yyyy");
				fmDate = fmt.format(dte);
			}
		} catch (Exception e) {
			// ignore
		}
		return fmDate;
	}

	/**
	 * This Method will take date and required format and return the formatted
	 * string.
	 * 
	 * @param dte
	 * @param format
	 * @return
	 */
	public static String formatDateToThisForm(Date dte, String format) {

		DateFormat fmt = null;
		String fmDate = null;
		try {
			if (dte != null) {
				fmt = new SimpleDateFormat(format);
				fmDate = fmt.format(dte);
			}
		} catch (Exception e) {
			// ignore
		}
		return fmDate;

	}

	/**
	 * Reformats a date string to the format yyyy-mm-dd from the display format of
	 * mm/dd/yyyy. Dates on the search form are entered in the format of mm/dd/yyyy
	 * and the database requires dates be in the format of yyyy-mm-dd. This method
	 * takes the original date string as converts it to the yyyy-mm-dd format.
	 * 
	 * @return a <code>String</code> of the formatted date
	 * @param dateText the date string to be formatted
	 * @since 1.0
	 */
	public static String formatDate(String dateText) {
		String ret = null;
		if (dateText != null) {
			SimpleDateFormat formatPreference = new SimpleDateFormat("MM/dd/yyyy");
			java.util.Date thisDate = new Date();

			try {
				if (dateText != null) {
					thisDate = formatPreference.parse(dateText);

				} 

			} catch (Exception e) {
				// ignore
			}

			formatPreference.applyPattern("yyyy-MM-dd");
			ret = formatPreference.format(thisDate);
		}
		return ret;

	}

	/**
	 * Formats the year of a date string properly in the case of a 2-digit year.
	 * 
	 * @return a date <code>String</code> with a properly formatted 4 digit year
	 * @param dateText the string to format
	 * @since 1.0
	 */
	public static String formatYear(String dateText) {
		SimpleDateFormat formatPreference = new SimpleDateFormat("MM/dd/yyyy");
		java.util.Date thisDate = new Date();

		try {
			thisDate = formatPreference.parse(dateText);

		} catch (ParseException e) {
			// Invalid Date
			// log.warn(ESAPIUtil.encode("invalid format: " + dateText));

		}

		// Verify the year entered - make sure an entered '/02' is not interpreted as
		// '/0002'
		Calendar thisCal = Calendar.getInstance();
		thisCal.setTime(thisDate);
		int year = thisCal.get(Calendar.YEAR);

		if (year < 100) {
			thisCal.set(Calendar.YEAR, 2000 + year);
		}

		thisDate = thisCal.getTime();

		return formatPreference.format(thisDate);

	}

	public static Date stringToDate(String dateString) {
		Date date = null;
		if (dateString != null) {
			dateString = dateString.trim(); // remove any excess white space
			for (int i = 0; date == null && i < formatsToTry.length; i++) {
				try {
					date = stringToDate(dateString, formatsToTry[i]);
					if (date != null) {
						return date;
					}
				} catch (Exception e) {
				} // that one didn't work, try another
			}
		}
		return date;
	}

	public static String getOracleDateFormat(Date dte) {
		DateFormat fmt = null;
		String formattedDate = null;
		try {
			if (dte != null) {
				fmt = new SimpleDateFormat("MM/dd/yyyy");
				formattedDate = fmt.format(dte);
			}
		} catch (Exception e) {
			// ignore
		} finally {
			//return formattedDate;
		}
		return formattedDate;
	}

	/**
	 * Given a string and a format string, will attempt to parse a Date object out
	 * of the string, expecting the format given. If the string does not match the
	 * format string, null is returned, otherwise, a Date object matching the string
	 * is returned. The format string is somewhat reminsicent of C's printf or
	 * strftime. It uses letter codes to indicate which pieces of the date (month,
	 * day, year, etc.) should be shown and whether to use the long or short forms.
	 * See the docs for DateFormat and SimpleDateFormat to get an explanation of all
	 * the various format codes.
	 * 
	 * @param date         a string hopefully containing a date
	 * @param formatString the string specifying the desired format
	 * @return the date object matching the input string if possible, null otherwise
	 * @see java.text.SimpleDateFormat
	 * @see java.text.DateFormat
	 */
	private static Date stringToDate(String dateString, String formatString) {
		try { // will throw exception if can't parse
			return getDateFormatter(formatString).parse(dateString.trim());
		} catch (Exception e) { // if trouble pulling out Date, return null
			return null;
		}
	}

	private static SimpleDateFormat getDateFormatter(String formatString) {
		SimpleDateFormat formatter = new SimpleDateFormat(formatString);
		formatter.setTimeZone(java.util.TimeZone.getDefault()); // workaround for bug
		formatter.setLenient(false); // don't alllow things like 1/35/99
		return formatter;
	}

	public static String getSimpleDateFormat(Date date) {
		// TODO Auto-generated method stub

		DateFormat fmt = null;
		String formattedDate = null;
		try {
			if (date != null) {
				fmt = new SimpleDateFormat("yyyyMMdd");
				formattedDate = fmt.format(date);
			}

		} catch (Exception e) {

		} finally {
			//return formattedDate;
		}
		
		return formattedDate;

	}

}