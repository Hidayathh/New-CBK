package com.unfi.cbk.bo;

/**
 * The NextApproverBO class is a way of representing a single result when listing
 * locations.
 * 
 * Each field corresponds to a column in the display table.
 * 
 * @author vpil001
 * @version 1.0
 */
public class NextApproverBO {

	private String userId = null;
	private String userName = null;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

}