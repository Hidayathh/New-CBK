/**
 * 
 */
package com.unfi.cbk.config;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

/**
 * @author yhp6y2l
 *
 */
@Component
public class RequestParamFilter implements HandlerInterceptor {

	/*
	 * @Autowired private Environment environmentResources;
	 */

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {

		try {

		} catch (Exception e) {
			e.printStackTrace();
		}

		return true;

	}

}
