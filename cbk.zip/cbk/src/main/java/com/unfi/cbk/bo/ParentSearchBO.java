package com.unfi.cbk.bo;

import com.unfi.cbk.util.StringFunctions;

/**
 * The Location class is a way of representing a single result when listing
 * locations.
 * 
 * Each field corresponds to a column in the display table.
 * 
 * @author yhp6y2l
 * @version 1.0
 */
public class ParentSearchBO {

	private Integer parentNumber = null;

	private String parentName = null;
	private String formattedName;

	public Integer getParentNumber() {
		return parentNumber;
	}

	public void setParentNumber(Integer parentNumber) {
		this.parentNumber = parentNumber;
	}

	public String getParentName() {
		return parentName;
	}

	public void setParentName(String parentName) {
		this.parentName = parentName;
	}

	public void setFormattedName(String formattedName) {
		this.formattedName = formattedName;
	}

	public String getName() {
		return parentName;
	}

	public void setName(String string) {
		parentName = string;
	}

	public Integer getNumber() {
		return parentNumber;
	}

	public void setNumber(Integer i) {
		parentNumber = i;
	}

	public String getId() {
		return parentNumber.toString();
	}

	public void setId(String s) {

		if (s.trim().equals("") || s == null) {
			parentNumber = null;
		} else {
			// We need to use parseInt() here instead of decode(), because the
			// leading zero on the location number causes decode to think the
			// number is octal format. This then can cause a NumberFormatException
			// to be thrown if the location has digits other than 0-7.
			parentNumber = Integer.valueOf(Integer.parseInt(s));
			// Integer integer = Integer.valueOf(i);
		}
	}

	public String getFormattedName() {
		StringBuffer formattedParentName = new StringBuffer();
		int maxNameLength = 31;
		String insertValue = "&nbsp;";

		try {
			String parentNum = StringFunctions.zeroFillLeft(parentNumber.toString(), 5);
			formattedParentName = new StringBuffer(this.parentName);

			int numberOfInsertValuesNeeded = maxNameLength - formattedParentName.length();

			for (int i = 0; i < numberOfInsertValuesNeeded; i++) {
				formattedParentName.append(insertValue);
			}
			formattedParentName.append(parentNum);

		} catch (Exception e) {
			// Ignore

		}

		return formattedParentName.toString();
	}

	public String getFormattedNumber() {
		String formattedParentNum = "";

		try {
			formattedParentNum = StringFunctions.zeroFillLeft(parentNumber.toString(), 5);

		} catch (Exception e) {
			// Ignore

		}

		return formattedParentNum;
	}

	public void setFormattedListName() {
		parentName = formattedName;
	}

}
