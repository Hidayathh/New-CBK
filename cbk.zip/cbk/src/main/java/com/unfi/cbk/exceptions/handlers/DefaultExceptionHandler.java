/*
 * Created on Jul 19, 2006
 */
package com.unfi.cbk.exceptions.handlers;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.exceptions.ApplicationSecurityException;
import com.unfi.cbk.exceptions.CbkServiceException;
import com.unfi.cbk.exceptions.DataAccessException;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;

/**
 * The DefaultExceptionHandler class extends Struts' ExceptionHandler to provide
 * custom logging and error page redirection.
 * 
 * This class will log the exception (with a partial stack trace), and redirect
 * the user to an error page, displaying a error message specific to the
 * exception type. (As defined in struts-config.xml)
 * 
 * @author yhp6y2l
 * @version 1.1
 */
@ControllerAdvice
public class DefaultExceptionHandler implements ExceptionHandlerUtil {
	@Autowired
	ActionMessages messages;
	/** The maximum number of lines to display in a partial stack trace. */
	protected static final int STACK_TRACE_SIZE = 10;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.struts.action.ExceptionHandler#execute(java.lang.Exception,
	 * org.apache.struts.config.ExceptionConfig,
	 * org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm,
	 * javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */
	@ExceptionHandler(value = { DataAccessException.class, ApplicationSecurityException.class,
			CbkServiceException.class })
	public ModelAndView execute(Exception ex, HttpServletRequest request)
			throws ServletException {

		// log.error("Exception: " + ex.getClass().toString() + " - " + ex.getMessage()
		// + "\n" + getPartialStackTrace(ex));
		this.logException(ex);
		ModelAndView mav = new ModelAndView("errorPage");

		if (ex instanceof DataAccessException) {
			messages.add("error", "errors.database", null);
		} else if (ex instanceof ApplicationSecurityException) {
			messages.add("error", "errors.noaccess", null);
		} else {
			messages.add("error", "errors.general", null);
		}
		// ActionMessages messages = new ActionMessages();
		// messages.add("error", ex.getKey());
		// messages.add("error", ex.getMessage(),null);
		// request.setAttribute(Globals.MESSAGE_KEY, messages);
		messages.saveMessages(request);
		request.setAttribute("actionMessages", messages);
		// storeException(request, "error", new ActionMessage(exConfig.getKey()),
		// mapping.findForward("error"), "request");
		return new ModelAndView(ActionUrlMapping.GLOBAL.get("error"));
	}

	/**
	 * Given an Exception, return a partial stack trace as a String, only including
	 * STACK_TRACE_SIZE lines of the trace.
	 * 
	 * This is useful for situations where you need to display a stack trace, but
	 * don't want to print out tons of extra data you won't need.
	 * 
	 * @param ex the Exception to get the partial stack trace for
	 * @return the partial stack trace as a String
	 *//*
		 * protected String getPartialStackTrace(Exception ex) { StackTraceElement[]
		 * stack = ex.getStackTrace(); StringBuffer s = new StringBuffer();
		 * 
		 * int len = STACK_TRACE_SIZE; if ( len < STACK_TRACE_SIZE ) { len =
		 * stack.length; }
		 * 
		 * for ( int i = 0; i < len; i++ ) { s.append("    at " +
		 * stack[i].toString()+"\n"); }
		 * 
		 * s.append("    (only showing first " + STACK_TRACE_SIZE + " lines of trace)");
		 * 
		 * return s.toString(); }
		 */

}
