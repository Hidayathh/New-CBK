package com.unfi.cbk.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.beans.UserDataBean;
import com.unfi.cbk.dao.ChargebackCommonDao;
import com.unfi.cbk.forms.ChargebackLocationSelectorForm;
//import com.unfi.cbk.dao.PassCommonDao;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.Constants;

/**
 * The action method that will be called is automatically determined based upon
 * the value of the parameter (specified in struts-config.xml) that is passed
 * in.
 * <p>
 * The action method will then sets the user data in the request, sets any
 * values needed, and forwards to the appropriate action mapping.
 *
 * @author
 * @version 1.0
 */
@Controller
public class LocationSelectorController {
	static Logger log = Logger.getLogger(LocationSelectorController.class);
	private ChargebackCommonDao chargebackCommonDao;

	public LocationSelectorController(@Autowired ChargebackCommonDao dao) {
		this.chargebackCommonDao = dao;
	}

	@Autowired
	ActionMessages errors;

	/**
	 * The open() method displays the Vendor Selector pop up.
	 * 
	 * @param mapping  The ActionMapping used to select this instance
	 * @param form     The ActionForm bean for this request
	 * @param request  The HTTP request we are processing
	 * @param response The HTTP response we are creating
	 * @return an ActionForward instance describing where and how control should be
	 *         forwarded, or null if the response has already been completed.
	 * @throws Exception if an exception occurs
	 */
	@RequestMapping(value = "/chargebackLocationSelector", method = { RequestMethod.GET,
			RequestMethod.POST }, params = { "action=open" })
	public ModelAndView open(@ModelAttribute ChargebackLocationSelectorForm chargebackLocationSelectorForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		// ActionErrors errors = new ActionErrors();
		// ActionMessages errors = new ActionMessages();
		// ActionForward forward = new ActionForward(); // return value
		System.out.println("ChargebackLocationSelectorActions.java---------open()---");
		boolean exceptionOccurred = false;

		try {
			log.debug("***** CHARGEBACK LOCATION SELECTOR OPEN *****");

			// Set the UserDataBean for the request. The setUserInfo method exists in the
			// base class.
			UserDataBean userBean = new UserDataBean(request);

		} catch (Exception e) {
			exceptionOccurred = true;
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);
			// Only add the general error if no other errors are present
			if (errors.isEmpty()) {
				errors.add("error", "errors.general");
			}
		}

		if (!exceptionOccurred) {
			// forward = mapping.findForward("open");
			mav.setViewName(ActionUrlMapping.CHARGEBACKLOCATIONSELECTORACTIONS.get("open"));
		}

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			// forward = mapping.findForward("failure");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
		}

		// Finish with
		// return (forward);
		System.out.println("-----URL mapping---" + mav.getViewName());
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackLocationSelectorForm", chargebackLocationSelectorForm);
		return mav;
	}

	/**
	 * The search() method get the values from the database.
	 * 
	 * @param mapping  The ActionMapping used to select this instance
	 * @param form     The ActionForm bean for this request
	 * @param request  The HTTP request we are processing
	 * @param response The HTTP response we are creating
	 * @return an ActionForward instance describing where and how control should be
	 *         forwarded, or null if the response has already been completed.
	 * @throws Exception if an exception occurs
	 */
	@RequestMapping(value = "/chargebackLocationSelector", method = { RequestMethod.GET,
			RequestMethod.POST }, params = { "action=search" })
	public ModelAndView search(@ModelAttribute ChargebackLocationSelectorForm chargebackLocationSelectorForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		// ActionErrors errors = new ActionErrors();
		ActionMessages errors = new ActionMessages();
		// ActionForward forward = new ActionForward(); // return value
		// ChargebackLocationSelectorForm chargebackLocationSelectorForm =
		// (ChargebackLocationSelectorForm) form;

		boolean exceptionOccurred = false;

		try {
			log.debug("***** CHARGEBACK LOCATION SELECTOR SEARCH *****");

			// Get the list of vendors and put them into the bean for the JSP page
			List searchResults = chargebackCommonDao.doLocationSearch(
					chargebackLocationSelectorForm.getLocationNumber(),
					chargebackLocationSelectorForm.getLocationName());
			chargebackLocationSelectorForm.setSearchResults(searchResults);
			chargebackLocationSelectorForm.setResults(new Integer(searchResults.size()));

		} catch (Exception e) {
			// Determine the error, log it, and put an error message in ActionErrors
			exceptionOccurred = true;
			// forward = mapping.findForward("failure");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));

			log.error("Exception in execute:" + e);

			// Only add the general error if no other errors are present
			if (errors.isEmpty()) {
				errors.add("error", "errors.general");
			}
		}

		if (!exceptionOccurred) {
			// forward = mapping.findForward("open");
			mav.setViewName(ActionUrlMapping.CHARGEBACKLOCATIONSELECTORACTIONS.get("open"));
		}

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			// forward = mapping.findForward("failure");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
		}

		// Finish with
		// return (forward);
		System.out.println("URL mapping" + mav.getViewName());
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackLocationSelectorForm", chargebackLocationSelectorForm);
		return mav;
	}
	@RequestMapping(value = "/chargebackLocationSelector", method = { RequestMethod.GET,
			RequestMethod.POST }, params = { "action=openLocName" })
	public ModelAndView openLocName(@ModelAttribute ChargebackLocationSelectorForm chargebackLocationSelectorForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		// ActionErrors errors = new ActionErrors();
		// ActionMessages errors = new ActionMessages();
		// ActionForward forward = new ActionForward(); // return value
		System.out.println("ChargebackLocationSelectorActions.java---------openLocName()---");
		boolean exceptionOccurred = false;

		try {
			log.debug("***** CHARGEBACK LOCATION SELECTOR OPENLOCNAME *****");

			// Set the UserDataBean for the request. The setUserInfo method exists in the
			// base class.
			UserDataBean userBean = new UserDataBean(request);

		} catch (Exception e) {
			exceptionOccurred = true;
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);
			// Only add the general error if no other errors are present
			if (errors.isEmpty()) {
				errors.add("error", "errors.general");
			}
		}

		if (!exceptionOccurred) {
			// forward = mapping.findForward("open");
			mav.setViewName(ActionUrlMapping.CHARGEBACKLOCATIONSELECTORACTIONS.get("openLocName"));
		}

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			// forward = mapping.findForward("failure");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
		}

		// Finish with
		// return (forward);
		System.out.println("-----URL mapping---" + mav.getViewName());
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackLocationSelectorForm", chargebackLocationSelectorForm);
		return mav;
	}

	/**
	 * The search() method get the values from the database.
	 * 
	 * @param mapping  The ActionMapping used to select this instance
	 * @param form     The ActionForm bean for this request
	 * @param request  The HTTP request we are processing
	 * @param response The HTTP response we are creating
	 * @return an ActionForward instance describing where and how control should be
	 *         forwarded, or null if the response has already been completed.
	 * @throws Exception if an exception occurs
	 */
	@RequestMapping(value = "/chargebackLocationSelector", method = { RequestMethod.GET,
			RequestMethod.POST }, params = { "action=searchName" })
	public ModelAndView searchName(@ModelAttribute ChargebackLocationSelectorForm chargebackLocationSelectorForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		// ActionErrors errors = new ActionErrors();
		ActionMessages errors = new ActionMessages();
		// ActionForward forward = new ActionForward(); // return value
		// ChargebackLocationSelectorForm chargebackLocationSelectorForm =
		// (ChargebackLocationSelectorForm) form;

		boolean exceptionOccurred = false;

		try {
			log.debug("***** CHARGEBACK LOCATION SELECTOR SEARCHNAME *****");

			// Get the list of vendors and put them into the bean for the JSP page
			List searchResults = chargebackCommonDao.doLocationSearch(
					chargebackLocationSelectorForm.getLocationNumber(),
					chargebackLocationSelectorForm.getLocationName());
			chargebackLocationSelectorForm.setSearchResults(searchResults);
			chargebackLocationSelectorForm.setResults(new Integer(searchResults.size()));

		} catch (Exception e) {
			// Determine the error, log it, and put an error message in ActionErrors
			exceptionOccurred = true;
			// forward = mapping.findForward("failure");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));

			log.error("Exception in execute:" + e);

			// Only add the general error if no other errors are present
			if (errors.isEmpty()) {
				errors.add("error", "errors.general");
			}
		}

		if (!exceptionOccurred) {
			// forward = mapping.findForward("open");
			mav.setViewName(ActionUrlMapping.CHARGEBACKLOCATIONSELECTORACTIONS.get("openLocName"));
		}

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			// forward = mapping.findForward("failure");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
		}

		// Finish with
		// return (forward);
		System.out.println("URL mapping" + mav.getViewName());
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackLocationSelectorForm", chargebackLocationSelectorForm);
		return mav;
	}
}
