package com.unfi.cbk.delegates;

import java.util.List;
import java.util.Map;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.dao.ChargebackExportDao;
import com.unfi.cbk.exceptions.DataAccessException;

/**
 * @author yhp6y2l
 * @version 3.3
 */

public class ChargebackExportDelegate {

	private ChargebackExportDao chargebackExportDao;

	public ChargebackExportDelegate(ChargebackExportDao chargebackExportDao) {
		this.chargebackExportDao = chargebackExportDao;
	}

	/* For AuditDetails */

	public ResultList getTypeAmount(Map params) throws DataAccessException {
		ResultList rL = chargebackExportDao.getTypeAmount(params);
		return rL;
	}
	/* For AdminDetails */

	public ResultList previewExportResults() throws DataAccessException {
		ResultList rL = chargebackExportDao.previewExportResults();
		return rL;
	}

	public ResultList agedChargebackReportSearch(Map searchParametersFrom) throws DataAccessException {
		ResultList rL = chargebackExportDao.agedChargebackReportSearch(searchParametersFrom);
		return rL;
	}

	public ResultList updateDuedate() throws DataAccessException {
		ResultList rL = chargebackExportDao.updateDuedate();
		return rL;
	}

	public void updateChargebackDueDate(ChargebackBO chargeBack) throws DataAccessException {

		chargebackExportDao.updateChargebackDueDate(chargeBack);
	}

	public void insertExpType() throws DataAccessException {
		chargebackExportDao.insertExpType();
	}

	public void insertExpReasons() throws DataAccessException {
		chargebackExportDao.insertExpReasons();
	}

	public void insertExpAvailableExports() throws DataAccessException {
		chargebackExportDao.insertExpAvailableExports();
	}

	public void insertExpChargeback() throws DataAccessException {
		chargebackExportDao.insertExpChargeback();
	}

	public void insertExpDistribution() throws DataAccessException {
		chargebackExportDao.insertExpDistribution();
	}

	public void insertExpItem() throws DataAccessException {
		chargebackExportDao.insertExpItem();
	}

	public void insertExpApprovals() throws DataAccessException {
		chargebackExportDao.insertExpApprovals();
	}

	public void insertExpDistRecords() throws DataAccessException {
		chargebackExportDao.insertExpDistRecords();
	}

	public void insertExpDetail() throws DataAccessException {
		chargebackExportDao.insertExpDetail();
	}

	public void insertExpNotExported() throws DataAccessException {
		chargebackExportDao.insertExpNotExported();
	}
	
	public void insertCvdDistExport() throws DataAccessException {
		chargebackExportDao.insertCvdDistExport();
	}

	public void deleteExpType() throws DataAccessException {
		chargebackExportDao.deleteExpType();
	}

	public void deleteExpReasons() throws DataAccessException {
		chargebackExportDao.deleteExpReasons();
	}

	public void deleteExpAvailableExports() throws DataAccessException {
		chargebackExportDao.deleteExpAvailableExports();
	}

	public void deleteExpChargeback() throws DataAccessException {
		chargebackExportDao.deleteExpChargeback();
	}

	public void deleteExpDistribution() throws DataAccessException {
		chargebackExportDao.deleteExpDistribution();
	}

	public void deleteExpItem() throws DataAccessException {
		chargebackExportDao.deleteExpItem();
	}

	public void deleteExpApprovals() throws DataAccessException {
		chargebackExportDao.deleteExpApprovals();
	}

	public void deleteExpDistRecords() throws DataAccessException {
		chargebackExportDao.deleteExpDistRecords();
	}

	public void deleteExpDetail() throws DataAccessException {
		chargebackExportDao.deleteExpDetail();
	}

	public void deleteExpNotExported() throws DataAccessException {
		chargebackExportDao.deleteExpNotExported();
	}
	
	public void deleteExpCviInvExport() throws DataAccessException{
		chargebackExportDao.deleteExpCviInvExport();
	}
	public void deleteExpFundsRecords() throws DataAccessException{
		chargebackExportDao.deleteExpFundsRecords();
	}
	
	public void deleteExportTables() throws DataAccessException {
		chargebackExportDao.deleteExpType();
		chargebackExportDao.deleteExpReasons();
		chargebackExportDao.deleteExpAvailableExports();
		chargebackExportDao.deleteExpChargeback();
		chargebackExportDao.deleteExpDistribution();
		chargebackExportDao.deleteExpItem();
		chargebackExportDao.deleteExpApprovals();
		chargebackExportDao.deleteExpDistRecords();
		chargebackExportDao.deleteExpDetail();
		chargebackExportDao.deleteExpNotExported();
		
	}
	
	public void updateChargebackExportorNot(String exportedStatus) throws DataAccessException {
		chargebackExportDao.updateChargebackExportorNot(exportedStatus);
	}
	
public List getExportId(String date) throws DataAccessException {
		
		return chargebackExportDao.getExportId(date);
	}

}
