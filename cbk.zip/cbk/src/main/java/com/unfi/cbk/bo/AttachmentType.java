/*
 * Created on Jun 24, 2005
 */
package com.unfi.cbk.bo;

/**
 * The AttachmentType class is a way of representing a single result when
 * listing attachment types.
 * 
 * Each field corresponds to a column in the display table.
 * 
 * @author yhp6y2l
 * @version 1.0
 */
public class AttachmentType {

	private int id;
	private String description = null;
	private int sortOrder;

	/**
	 * @return
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @return
	 */
	public int getId() {
		return id;
	}

	/**
	 * @return
	 */
	public int getSortOrder() {
		return sortOrder;
	}

	/**
	 * @param string
	 */
	public void setDescription(String string) {
		description = string;
	}

	/**
	 * @param i
	 */
	public void setId(int i) {
		id = i;
	}

	/**
	 * @param i
	 */
	public void setSortOrder(int i) {
		sortOrder = i;
	}

}
